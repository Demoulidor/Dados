#!/bin/bash
echo 'No XML fotos este é o nome do Deputado Federal:|ABELARDO CAMARINHA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ABELARDO CAMARINHA|'
mv 08563fa8c8eee69a221bbf55134201564979f83b.png renomeado/category_2492_08563fa8c8eee69a221bbf55134201564979f83b.png
convert renomeado/category_2492_08563fa8c8eee69a221bbf55134201564979f83b.png -resize 16x16 renomeado/category_2492_08563fa8c8eee69a221bbf55134201564979f83b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ABELARDO LUPION|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ABELARDO LUPION|'
mv 347255032b48b2711a98573ecbdedfe2ffdf233c.png renomeado/category_2493_347255032b48b2711a98573ecbdedfe2ffdf233c.png
convert renomeado/category_2493_347255032b48b2711a98573ecbdedfe2ffdf233c.png -resize 16x16 renomeado/category_2493_347255032b48b2711a98573ecbdedfe2ffdf233c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ACELINO POPÓ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ACELINO POPÓ|'
mv 01d7d86eea770ce386d7396d2156a3d888bd262a.png renomeado/category_2494_01d7d86eea770ce386d7396d2156a3d888bd262a.png
convert renomeado/category_2494_01d7d86eea770ce386d7396d2156a3d888bd262a.png -resize 16x16 renomeado/category_2494_01d7d86eea770ce386d7396d2156a3d888bd262a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ADEMIR CAMILO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ADEMIR CAMILO|'
mv 86a0880ebd5f4d10e1a6307ede0283b40efc17fc.png renomeado/category_2495_86a0880ebd5f4d10e1a6307ede0283b40efc17fc.png
convert renomeado/category_2495_86a0880ebd5f4d10e1a6307ede0283b40efc17fc.png -resize 16x16 renomeado/category_2495_86a0880ebd5f4d10e1a6307ede0283b40efc17fc_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ADRIAN|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ADRIAN|'
mv dc21b06a46e49fb17b21d1c2b39328d76b384bae.png renomeado/category_2496_dc21b06a46e49fb17b21d1c2b39328d76b384bae.png
convert renomeado/category_2496_dc21b06a46e49fb17b21d1c2b39328d76b384bae.png -resize 16x16 renomeado/category_2496_dc21b06a46e49fb17b21d1c2b39328d76b384bae_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|AELTON FREITAS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|AELTON FREITAS|'
mv 58b15cf9345e3d4ab3ce62f623d32ee9302fdf60.png renomeado/category_2497_58b15cf9345e3d4ab3ce62f623d32ee9302fdf60.png
convert renomeado/category_2497_58b15cf9345e3d4ab3ce62f623d32ee9302fdf60.png -resize 16x16 renomeado/category_2497_58b15cf9345e3d4ab3ce62f623d32ee9302fdf60_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|AFONSO FLORENCE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|AFONSO FLORENCE|'
mv dd67c60d383c984df5740e492c399a6e8d9b385e.png renomeado/category_2498_dd67c60d383c984df5740e492c399a6e8d9b385e.png
convert renomeado/category_2498_dd67c60d383c984df5740e492c399a6e8d9b385e.png -resize 16x16 renomeado/category_2498_dd67c60d383c984df5740e492c399a6e8d9b385e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|AFONSO HAMM|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|AFONSO HAMM|'
mv 6c03707f7c7fae244b11cac234062adeecd249a9.png renomeado/category_2499_6c03707f7c7fae244b11cac234062adeecd249a9.png
convert renomeado/category_2499_6c03707f7c7fae244b11cac234062adeecd249a9.png -resize 16x16 renomeado/category_2499_6c03707f7c7fae244b11cac234062adeecd249a9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ALBERTO FILHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALBERTO FILHO|'
mv 339f91f0e688e55c2c3f59b8384212cde759d1be.png renomeado/category_2500_339f91f0e688e55c2c3f59b8384212cde759d1be.png
convert renomeado/category_2500_339f91f0e688e55c2c3f59b8384212cde759d1be.png -resize 16x16 renomeado/category_2500_339f91f0e688e55c2c3f59b8384212cde759d1be_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALBERTO MOURÃO|'

echo 'No XML fotos este é o nome do Deputado Federal:|ALCEU MOREIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALCEU MOREIRA|'
mv c495b9a567f9bd7be3a1ee7877ac1a745026587d.png renomeado/category_2502_c495b9a567f9bd7be3a1ee7877ac1a745026587d.png
convert renomeado/category_2502_c495b9a567f9bd7be3a1ee7877ac1a745026587d.png -resize 16x16 renomeado/category_2502_c495b9a567f9bd7be3a1ee7877ac1a745026587d_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ALESSANDRO MOLON|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALESSANDRO MOLON|'
mv 8bef0b4724ea86fc71f870b3beaf3abefca96380.png renomeado/category_2503_8bef0b4724ea86fc71f870b3beaf3abefca96380.png
convert renomeado/category_2503_8bef0b4724ea86fc71f870b3beaf3abefca96380.png -resize 16x16 renomeado/category_2503_8bef0b4724ea86fc71f870b3beaf3abefca96380_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ALEX CANZIANI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALEX CANZIANI|'
mv a0f4a0d33c984e23dfeb38cc9eb1c06583bcc794.png renomeado/category_2504_a0f4a0d33c984e23dfeb38cc9eb1c06583bcc794.png
convert renomeado/category_2504_a0f4a0d33c984e23dfeb38cc9eb1c06583bcc794.png -resize 16x16 renomeado/category_2504_a0f4a0d33c984e23dfeb38cc9eb1c06583bcc794_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALEXANDRE CARDOSO|'

echo 'No XML fotos este é o nome do Deputado Federal:|ALEXANDRE LEITE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALEXANDRE LEITE|'
mv 1f37a371eb2c30acc9eef322a92cea8712b3d0e9.png renomeado/category_2506_1f37a371eb2c30acc9eef322a92cea8712b3d0e9.png
convert renomeado/category_2506_1f37a371eb2c30acc9eef322a92cea8712b3d0e9.png -resize 16x16 renomeado/category_2506_1f37a371eb2c30acc9eef322a92cea8712b3d0e9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ALEXANDRE ROSO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALEXANDRE ROSO|'
mv 301db4b2594c4badb0c1b37525baa529ac02fbdf.png renomeado/category_2507_301db4b2594c4badb0c1b37525baa529ac02fbdf.png
convert renomeado/category_2507_301db4b2594c4badb0c1b37525baa529ac02fbdf.png -resize 16x16 renomeado/category_2507_301db4b2594c4badb0c1b37525baa529ac02fbdf_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ALEXANDRE SANTOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALEXANDRE SANTOS|'
mv d9aeeb655968dac8db17563ba1f799feefe65c68.png renomeado/category_2508_d9aeeb655968dac8db17563ba1f799feefe65c68.png
convert renomeado/category_2508_d9aeeb655968dac8db17563ba1f799feefe65c68.png -resize 16x16 renomeado/category_2508_d9aeeb655968dac8db17563ba1f799feefe65c68_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ALFREDO KAEFER|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALFREDO KAEFER|'
mv c7cb2f686c6eb4c3a3705bbedd22550f64221679.png renomeado/category_2509_c7cb2f686c6eb4c3a3705bbedd22550f64221679.png
convert renomeado/category_2509_c7cb2f686c6eb4c3a3705bbedd22550f64221679.png -resize 16x16 renomeado/category_2509_c7cb2f686c6eb4c3a3705bbedd22550f64221679_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ALFREDO SIRKIS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALFREDO SIRKIS|'
mv 0541dc040165dd0c91b337657728e28d6b874880.png renomeado/category_2510_0541dc040165dd0c91b337657728e28d6b874880.png
convert renomeado/category_2510_0541dc040165dd0c91b337657728e28d6b874880.png -resize 16x16 renomeado/category_2510_0541dc040165dd0c91b337657728e28d6b874880_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ALICE PORTUGAL|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALICE PORTUGAL|'
mv 6262453494e76ea083d574cb54e68483de9739c9.png renomeado/category_2511_6262453494e76ea083d574cb54e68483de9739c9.png
convert renomeado/category_2511_6262453494e76ea083d574cb54e68483de9739c9.png -resize 16x16 renomeado/category_2511_6262453494e76ea083d574cb54e68483de9739c9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ALINE CORRÊA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALINE CORRÊA|'
mv e43c49d10828b52968571d1251058d1445e046a6.png renomeado/category_2512_e43c49d10828b52968571d1251058d1445e046a6.png
convert renomeado/category_2512_e43c49d10828b52968571d1251058d1445e046a6.png -resize 16x16 renomeado/category_2512_e43c49d10828b52968571d1251058d1445e046a6_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ALMEIDA LIMA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ALMEIDA LIMA|'
mv 9239d8750d64eed8916a9b79dd8935f797c2080b.png renomeado/category_2513_9239d8750d64eed8916a9b79dd8935f797c2080b.png
convert renomeado/category_2513_9239d8750d64eed8916a9b79dd8935f797c2080b.png -resize 16x16 renomeado/category_2513_9239d8750d64eed8916a9b79dd8935f797c2080b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|AMAURI TEIXEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|AMAURI TEIXEIRA|'
mv 41ba407f59809c1f09860815c63456029af929be.png renomeado/category_2514_41ba407f59809c1f09860815c63456029af929be.png
convert renomeado/category_2514_41ba407f59809c1f09860815c63456029af929be.png -resize 16x16 renomeado/category_2514_41ba407f59809c1f09860815c63456029af929be_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ANDERSON FERREIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANDERSON FERREIRA|'
mv 6d7b99bf591c1c4b9c7f057a375df93ca89a545a.png renomeado/category_2515_6d7b99bf591c1c4b9c7f057a375df93ca89a545a.png
convert renomeado/category_2515_6d7b99bf591c1c4b9c7f057a375df93ca89a545a.png -resize 16x16 renomeado/category_2515_6d7b99bf591c1c4b9c7f057a375df93ca89a545a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANDRE  VARGAS|'

echo 'No XML fotos este é o nome do Deputado Federal:|ANDRE MOURA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANDRE MOURA|'
mv 1883361ddfec1eb3198550b23ab1e432dffcc723.png renomeado/category_2517_1883361ddfec1eb3198550b23ab1e432dffcc723.png
convert renomeado/category_2517_1883361ddfec1eb3198550b23ab1e432dffcc723.png -resize 16x16 renomeado/category_2517_1883361ddfec1eb3198550b23ab1e432dffcc723_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANDREIA  ZITO|'

echo 'No XML fotos este é o nome do Deputado Federal:|ANDRÉ FIGUEIREDO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANDRÉ FIGUEIREDO|'
mv cf616dabf71c8851ac1b5a8e7c468ad77228b591.png renomeado/category_2519_cf616dabf71c8851ac1b5a8e7c468ad77228b591.png
convert renomeado/category_2519_cf616dabf71c8851ac1b5a8e7c468ad77228b591.png -resize 16x16 renomeado/category_2519_cf616dabf71c8851ac1b5a8e7c468ad77228b591_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ANDRÉ ZACHAROW|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANDRÉ ZACHAROW|'
mv 47e8018826c30c3820ef8eb9e61f5a3cb064abc8.png renomeado/category_2520_47e8018826c30c3820ef8eb9e61f5a3cb064abc8.png
convert renomeado/category_2520_47e8018826c30c3820ef8eb9e61f5a3cb064abc8.png -resize 16x16 renomeado/category_2520_47e8018826c30c3820ef8eb9e61f5a3cb064abc8_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ANGELO VANHONI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANGELO VANHONI|'
mv 6ffdbe94339f4cfc732c9952c0117e4fd57bb4c6.png renomeado/category_2521_6ffdbe94339f4cfc732c9952c0117e4fd57bb4c6.png
convert renomeado/category_2521_6ffdbe94339f4cfc732c9952c0117e4fd57bb4c6.png -resize 16x16 renomeado/category_2521_6ffdbe94339f4cfc732c9952c0117e4fd57bb4c6_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ANTHONY GAROTINHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANTHONY GAROTINHO|'
mv 065e1113cca802b43766a6d37c5456a18beb70f4.png renomeado/category_2522_065e1113cca802b43766a6d37c5456a18beb70f4.png
convert renomeado/category_2522_065e1113cca802b43766a6d37c5456a18beb70f4.png -resize 16x16 renomeado/category_2522_065e1113cca802b43766a6d37c5456a18beb70f4_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ANTONIO BALHMANN|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANTONIO BALHMANN|'
mv e37cac6899c61fed0144deecc3f5682e1f57571c.png renomeado/category_2523_e37cac6899c61fed0144deecc3f5682e1f57571c.png
convert renomeado/category_2523_e37cac6899c61fed0144deecc3f5682e1f57571c.png -resize 16x16 renomeado/category_2523_e37cac6899c61fed0144deecc3f5682e1f57571c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ANTONIO BRITO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANTONIO BRITO|'
mv 9c5d9821707657ee0e95fcc991f77fee3da6dd2b.png renomeado/category_2524_9c5d9821707657ee0e95fcc991f77fee3da6dd2b.png
convert renomeado/category_2524_9c5d9821707657ee0e95fcc991f77fee3da6dd2b.png -resize 16x16 renomeado/category_2524_9c5d9821707657ee0e95fcc991f77fee3da6dd2b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ANTONIO BULHÕES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANTONIO BULHÕES|'
mv de21c7ff644b0b6d9140813e2de0deb50f39b801.png renomeado/category_2525_de21c7ff644b0b6d9140813e2de0deb50f39b801.png
convert renomeado/category_2525_de21c7ff644b0b6d9140813e2de0deb50f39b801.png -resize 16x16 renomeado/category_2525_de21c7ff644b0b6d9140813e2de0deb50f39b801_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANTONIO CARLOS MAGALHÃES NETO|'

echo 'No XML fotos este é o nome do Deputado Federal:|ANTONIO CARLOS MENDES THAME|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANTONIO CARLOS MENDES THAME|'
mv 1dce24a146021e5fa7d239131dd2f7f4a75213f8.png renomeado/category_2527_1dce24a146021e5fa7d239131dd2f7f4a75213f8.png
convert renomeado/category_2527_1dce24a146021e5fa7d239131dd2f7f4a75213f8.png -resize 16x16 renomeado/category_2527_1dce24a146021e5fa7d239131dd2f7f4a75213f8_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ANTONIO IMBASSAHY|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANTONIO IMBASSAHY|'
mv 6f175f96cd8a6aab94680c854545f117e5b6a7f5.png renomeado/category_2528_6f175f96cd8a6aab94680c854545f117e5b6a7f5.png
convert renomeado/category_2528_6f175f96cd8a6aab94680c854545f117e5b6a7f5.png -resize 16x16 renomeado/category_2528_6f175f96cd8a6aab94680c854545f117e5b6a7f5_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ANTÔNIA LÚCIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANTÔNIA LÚCIA|'
mv 1250055dc9e3a92beaa0f12d73241b3d5209ad72.png renomeado/category_2529_1250055dc9e3a92beaa0f12d73241b3d5209ad72.png
convert renomeado/category_2529_1250055dc9e3a92beaa0f12d73241b3d5209ad72.png -resize 16x16 renomeado/category_2529_1250055dc9e3a92beaa0f12d73241b3d5209ad72_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANTÔNIO ANDRADE|'

echo 'No XML fotos este é o nome do Deputado Federal:|ANTÔNIO ROBERTO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANTÔNIO ROBERTO|'
mv ee8232a5e85a4c163fcb5281b8e1132c2d37758a.png renomeado/category_2531_ee8232a5e85a4c163fcb5281b8e1132c2d37758a.png
convert renomeado/category_2531_ee8232a5e85a4c163fcb5281b8e1132c2d37758a.png -resize 16x16 renomeado/category_2531_ee8232a5e85a4c163fcb5281b8e1132c2d37758a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ANÍBAL GOMES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ANÍBAL GOMES|'
mv 96a30be2f5975f65281fd4ecca4cdf2c077a841d.png renomeado/category_2532_96a30be2f5975f65281fd4ecca4cdf2c077a841d.png
convert renomeado/category_2532_96a30be2f5975f65281fd4ecca4cdf2c077a841d.png -resize 16x16 renomeado/category_2532_96a30be2f5975f65281fd4ecca4cdf2c077a841d_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ARACELY DE PAULA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ARACELY DE PAULA|'
mv 04038e8d3ad876ca01033a08a5b8fbd40e3c9d06.png renomeado/category_2533_04038e8d3ad876ca01033a08a5b8fbd40e3c9d06.png
convert renomeado/category_2533_04038e8d3ad876ca01033a08a5b8fbd40e3c9d06.png -resize 16x16 renomeado/category_2533_04038e8d3ad876ca01033a08a5b8fbd40e3c9d06_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ARIOSTO HOLANDA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ARIOSTO HOLANDA|'
mv e07ce3e9538f478c4abd692673c3b308a516afff.png renomeado/category_2534_e07ce3e9538f478c4abd692673c3b308a516afff.png
convert renomeado/category_2534_e07ce3e9538f478c4abd692673c3b308a516afff.png -resize 16x16 renomeado/category_2534_e07ce3e9538f478c4abd692673c3b308a516afff_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ARLINDO CHINAGLIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ARLINDO CHINAGLIA|'
mv 1979067b46fab0fffed458866234e7eaac1f95ec.png renomeado/category_2535_1979067b46fab0fffed458866234e7eaac1f95ec.png
convert renomeado/category_2535_1979067b46fab0fffed458866234e7eaac1f95ec.png -resize 16x16 renomeado/category_2535_1979067b46fab0fffed458866234e7eaac1f95ec_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ARMANDO VERGÍLIO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ARMANDO VERGÍLIO|'
mv d00a6b462da3491055f63f57ce450ffe0fbbc707.png renomeado/category_2536_d00a6b462da3491055f63f57ce450ffe0fbbc707.png
convert renomeado/category_2536_d00a6b462da3491055f63f57ce450ffe0fbbc707.png -resize 16x16 renomeado/category_2536_d00a6b462da3491055f63f57ce450ffe0fbbc707_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ARNALDO FARIA DE SÁ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ARNALDO FARIA DE SÁ|'
mv 9638355238c7195414ff06f1ea84a5cc1f9d96d8.png renomeado/category_2537_9638355238c7195414ff06f1ea84a5cc1f9d96d8.png
convert renomeado/category_2537_9638355238c7195414ff06f1ea84a5cc1f9d96d8.png -resize 16x16 renomeado/category_2537_9638355238c7195414ff06f1ea84a5cc1f9d96d8_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ARNALDO JARDIM|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ARNALDO JARDIM|'
mv 5a7535e873bd77c721ed8500f3042305a9361dae.png renomeado/category_2538_5a7535e873bd77c721ed8500f3042305a9361dae.png
convert renomeado/category_2538_5a7535e873bd77c721ed8500f3042305a9361dae.png -resize 16x16 renomeado/category_2538_5a7535e873bd77c721ed8500f3042305a9361dae_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ARNALDO JORDY|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ARNALDO JORDY|'
mv 481f9412fb6fd9aeb3899be40514ab8e5fd8f6bf.png renomeado/category_2539_481f9412fb6fd9aeb3899be40514ab8e5fd8f6bf.png
convert renomeado/category_2539_481f9412fb6fd9aeb3899be40514ab8e5fd8f6bf.png -resize 16x16 renomeado/category_2539_481f9412fb6fd9aeb3899be40514ab8e5fd8f6bf_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ARNON BEZERRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ARNON BEZERRA|'
mv e5e354a8b3fc0562c655efd55c13227c87b13eac.png renomeado/category_2540_e5e354a8b3fc0562c655efd55c13227c87b13eac.png
convert renomeado/category_2540_e5e354a8b3fc0562c655efd55c13227c87b13eac.png -resize 16x16 renomeado/category_2540_e5e354a8b3fc0562c655efd55c13227c87b13eac_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|AROLDE DE OLIVEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|AROLDE DE OLIVEIRA|'
mv ce2f72a2b066a95ae2920cd58177edebf3812ea9.png renomeado/category_2541_ce2f72a2b066a95ae2920cd58177edebf3812ea9.png
convert renomeado/category_2541_ce2f72a2b066a95ae2920cd58177edebf3812ea9.png -resize 16x16 renomeado/category_2541_ce2f72a2b066a95ae2920cd58177edebf3812ea9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ARTHUR LIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ARTHUR LIRA|'
mv e606a82877595e1d68c90d9da408e5ba7a56c284.png renomeado/category_2542_e606a82877595e1d68c90d9da408e5ba7a56c284.png
convert renomeado/category_2542_e606a82877595e1d68c90d9da408e5ba7a56c284.png -resize 16x16 renomeado/category_2542_e606a82877595e1d68c90d9da408e5ba7a56c284_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ARTHUR OLIVEIRA MAIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ARTHUR OLIVEIRA MAIA|'
mv d64ad2b0dfa311ef2d7021d22d9ebbe92750c575.png renomeado/category_2543_d64ad2b0dfa311ef2d7021d22d9ebbe92750c575.png
convert renomeado/category_2543_d64ad2b0dfa311ef2d7021d22d9ebbe92750c575.png -resize 16x16 renomeado/category_2543_d64ad2b0dfa311ef2d7021d22d9ebbe92750c575_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ARTUR BRUNO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ARTUR BRUNO|'
mv dbda18a3be910ef35b43951e71fb85c34431760c.png renomeado/category_2544_dbda18a3be910ef35b43951e71fb85c34431760c.png
convert renomeado/category_2544_dbda18a3be910ef35b43951e71fb85c34431760c.png -resize 16x16 renomeado/category_2544_dbda18a3be910ef35b43951e71fb85c34431760c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ASDRUBAL BENTES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ASDRUBAL BENTES|'
mv 6665c60f1ddca07c40341feec95689ccb2bee1d4.png renomeado/category_2545_6665c60f1ddca07c40341feec95689ccb2bee1d4.png
convert renomeado/category_2545_6665c60f1ddca07c40341feec95689ccb2bee1d4.png -resize 16x16 renomeado/category_2545_6665c60f1ddca07c40341feec95689ccb2bee1d4_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ASSIS CARVALHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ASSIS CARVALHO|'
mv 9e1d9d7fc8a7ec913fe6ca893f5f5fdb3e248d16.png renomeado/category_2546_9e1d9d7fc8a7ec913fe6ca893f5f5fdb3e248d16.png
convert renomeado/category_2546_9e1d9d7fc8a7ec913fe6ca893f5f5fdb3e248d16.png -resize 16x16 renomeado/category_2546_9e1d9d7fc8a7ec913fe6ca893f5f5fdb3e248d16_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ASSIS DO COUTO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ASSIS DO COUTO|'
mv 9f12377aeb738845eb56b25dfd447dccf6235f74.png renomeado/category_2547_9f12377aeb738845eb56b25dfd447dccf6235f74.png
convert renomeado/category_2547_9f12377aeb738845eb56b25dfd447dccf6235f74.png -resize 16x16 renomeado/category_2547_9f12377aeb738845eb56b25dfd447dccf6235f74_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ASSIS MELO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ASSIS MELO|'
mv 8feee6d0744485f1e202ef4c05eea80e328afc31.png renomeado/category_2548_8feee6d0744485f1e202ef4c05eea80e328afc31.png
convert renomeado/category_2548_8feee6d0744485f1e202ef4c05eea80e328afc31.png -resize 16x16 renomeado/category_2548_8feee6d0744485f1e202ef4c05eea80e328afc31_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|AUDIFAX|'

echo 'No XML fotos este é o nome do Deputado Federal:|AUGUSTO COUTINHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|AUGUSTO COUTINHO|'
mv e7bc50d28e2ffa59949a48c5218b88c055555380.png renomeado/category_2550_e7bc50d28e2ffa59949a48c5218b88c055555380.png
convert renomeado/category_2550_e7bc50d28e2ffa59949a48c5218b88c055555380.png -resize 16x16 renomeado/category_2550_e7bc50d28e2ffa59949a48c5218b88c055555380_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|AUREO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|AUREO|'
mv e425aebff19a0fbe662f735c4d3a4b62dfb9d2a7.png renomeado/category_2551_e425aebff19a0fbe662f735c4d3a4b62dfb9d2a7.png
convert renomeado/category_2551_e425aebff19a0fbe662f735c4d3a4b62dfb9d2a7.png -resize 16x16 renomeado/category_2551_e425aebff19a0fbe662f735c4d3a4b62dfb9d2a7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|BENEDITA DA SILVA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BENEDITA DA SILVA|'
mv 1dec2ca51ce1c34f64d1b080da87e4abb41ab02f.png renomeado/category_2552_1dec2ca51ce1c34f64d1b080da87e4abb41ab02f.png
convert renomeado/category_2552_1dec2ca51ce1c34f64d1b080da87e4abb41ab02f.png -resize 16x16 renomeado/category_2552_1dec2ca51ce1c34f64d1b080da87e4abb41ab02f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|BENJAMIN MARANHÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BENJAMIN MARANHÃO|'
mv 6bad3792152bde88e8978484ef226d8d64878b81.png renomeado/category_2553_6bad3792152bde88e8978484ef226d8d64878b81.png
convert renomeado/category_2553_6bad3792152bde88e8978484ef226d8d64878b81.png -resize 16x16 renomeado/category_2553_6bad3792152bde88e8978484ef226d8d64878b81_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BERINHO BANTIM|'

echo 'No XML fotos este é o nome do Deputado Federal:|BERNARDO SANTANA DE VASCONCELLOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BERNARDO SANTANA DE VASCONCELLOS|'
mv 95c95cf608a0c71ef5b9504c190573d95888aa86.png renomeado/category_2555_95c95cf608a0c71ef5b9504c190573d95888aa86.png
convert renomeado/category_2555_95c95cf608a0c71ef5b9504c190573d95888aa86.png -resize 16x16 renomeado/category_2555_95c95cf608a0c71ef5b9504c190573d95888aa86_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|BETINHO ROSADO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BETINHO ROSADO|'
mv 0ef28595a3fa3b23ea130f58cc1d9fa46552cbcd.png renomeado/category_2556_0ef28595a3fa3b23ea130f58cc1d9fa46552cbcd.png
convert renomeado/category_2556_0ef28595a3fa3b23ea130f58cc1d9fa46552cbcd.png -resize 16x16 renomeado/category_2556_0ef28595a3fa3b23ea130f58cc1d9fa46552cbcd_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|BETO ALBUQUERQUE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BETO ALBUQUERQUE|'
mv 114c65d57b79d07294e5d9770b64c606a22a002e.png renomeado/category_2557_114c65d57b79d07294e5d9770b64c606a22a002e.png
convert renomeado/category_2557_114c65d57b79d07294e5d9770b64c606a22a002e.png -resize 16x16 renomeado/category_2557_114c65d57b79d07294e5d9770b64c606a22a002e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|BETO FARO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BETO FARO|'
mv 2eaa4ed4c1fce54c62053c481980abbae494f8ef.png renomeado/category_2558_2eaa4ed4c1fce54c62053c481980abbae494f8ef.png
convert renomeado/category_2558_2eaa4ed4c1fce54c62053c481980abbae494f8ef.png -resize 16x16 renomeado/category_2558_2eaa4ed4c1fce54c62053c481980abbae494f8ef_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|BETO MANSUR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BETO MANSUR|'
mv e1d6b67c04a55e0ed8a3d316b1671d665af5ee93.png renomeado/category_2559_e1d6b67c04a55e0ed8a3d316b1671d665af5ee93.png
convert renomeado/category_2559_e1d6b67c04a55e0ed8a3d316b1671d665af5ee93.png -resize 16x16 renomeado/category_2559_e1d6b67c04a55e0ed8a3d316b1671d665af5ee93_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|BIFFI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BIFFI|'
mv 22c1bc2d47536c1333e2f4e1cd43fcbd8c909714.png renomeado/category_2560_22c1bc2d47536c1333e2f4e1cd43fcbd8c909714.png
convert renomeado/category_2560_22c1bc2d47536c1333e2f4e1cd43fcbd8c909714.png -resize 16x16 renomeado/category_2560_22c1bc2d47536c1333e2f4e1cd43fcbd8c909714_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|BOHN GASS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BOHN GASS|'
mv 6a0891ab0479bd4cc976b0ba404bd2219e9bd4ed.png renomeado/category_2561_6a0891ab0479bd4cc976b0ba404bd2219e9bd4ed.png
convert renomeado/category_2561_6a0891ab0479bd4cc976b0ba404bd2219e9bd4ed.png -resize 16x16 renomeado/category_2561_6a0891ab0479bd4cc976b0ba404bd2219e9bd4ed_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|BONIFÁCIO DE ANDRADA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BONIFÁCIO DE ANDRADA|'
mv 2f2c9647a9bdf929dbee50f00e23efc428255aa8.png renomeado/category_2562_2f2c9647a9bdf929dbee50f00e23efc428255aa8.png
convert renomeado/category_2562_2f2c9647a9bdf929dbee50f00e23efc428255aa8.png -resize 16x16 renomeado/category_2562_2f2c9647a9bdf929dbee50f00e23efc428255aa8_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|BRUNA FURLAN|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BRUNA FURLAN|'
mv 931bdedb84b436f2540bfb2327f484fa880df058.png renomeado/category_2563_931bdedb84b436f2540bfb2327f484fa880df058.png
convert renomeado/category_2563_931bdedb84b436f2540bfb2327f484fa880df058.png -resize 16x16 renomeado/category_2563_931bdedb84b436f2540bfb2327f484fa880df058_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|BRUNO ARAÚJO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|BRUNO ARAÚJO|'
mv dad1c56cc642f37ad4ddde1147a8db6554a0e6f1.png renomeado/category_2564_dad1c56cc642f37ad4ddde1147a8db6554a0e6f1.png
convert renomeado/category_2564_dad1c56cc642f37ad4ddde1147a8db6554a0e6f1.png -resize 16x16 renomeado/category_2564_dad1c56cc642f37ad4ddde1147a8db6554a0e6f1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CARLAILE PEDROSA|'

echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CARLINHOS ALMEIDA|'

echo 'No XML fotos este é o nome do Deputado Federal:|CARLOS ALBERTO LERÉIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CARLOS ALBERTO LERÉIA|'
mv 6ba455be66b6ac9fc5fdba878d2a77fd83b9e468.png renomeado/category_2567_6ba455be66b6ac9fc5fdba878d2a77fd83b9e468.png
convert renomeado/category_2567_6ba455be66b6ac9fc5fdba878d2a77fd83b9e468.png -resize 16x16 renomeado/category_2567_6ba455be66b6ac9fc5fdba878d2a77fd83b9e468_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CARLOS BEZERRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CARLOS BEZERRA|'
mv a7c3e805f95b268aab471cb8597904fce37b8b84.png renomeado/category_2568_a7c3e805f95b268aab471cb8597904fce37b8b84.png
convert renomeado/category_2568_a7c3e805f95b268aab471cb8597904fce37b8b84.png -resize 16x16 renomeado/category_2568_a7c3e805f95b268aab471cb8597904fce37b8b84_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CARLOS BRANDÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CARLOS BRANDÃO|'
mv ae960bda9d65262448cfcb5f620e224326122e61.png renomeado/category_2569_ae960bda9d65262448cfcb5f620e224326122e61.png
convert renomeado/category_2569_ae960bda9d65262448cfcb5f620e224326122e61.png -resize 16x16 renomeado/category_2569_ae960bda9d65262448cfcb5f620e224326122e61_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CARLOS EDUARDO CADOCA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CARLOS EDUARDO CADOCA|'
mv 5f7281200e8f492eef359297e9dce005602b5273.png renomeado/category_2570_5f7281200e8f492eef359297e9dce005602b5273.png
convert renomeado/category_2570_5f7281200e8f492eef359297e9dce005602b5273.png -resize 16x16 renomeado/category_2570_5f7281200e8f492eef359297e9dce005602b5273_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CARLOS MAGNO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CARLOS MAGNO|'
mv d7b72a53079054f2c2d2074319ee632a0a08336a.png renomeado/category_2571_d7b72a53079054f2c2d2074319ee632a0a08336a.png
convert renomeado/category_2571_d7b72a53079054f2c2d2074319ee632a0a08336a.png -resize 16x16 renomeado/category_2571_d7b72a53079054f2c2d2074319ee632a0a08336a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CARLOS SAMPAIO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CARLOS SAMPAIO|'
mv 6e6114d8506f9526989ba3d3918eb74ce1d26a7d.png renomeado/category_2572_6e6114d8506f9526989ba3d3918eb74ce1d26a7d.png
convert renomeado/category_2572_6e6114d8506f9526989ba3d3918eb74ce1d26a7d.png -resize 16x16 renomeado/category_2572_6e6114d8506f9526989ba3d3918eb74ce1d26a7d_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CARLOS SOUZA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CARLOS SOUZA|'
mv b41d99b036eac8d97422259ae8ce4c359de3175e.png renomeado/category_2573_b41d99b036eac8d97422259ae8ce4c359de3175e.png
convert renomeado/category_2573_b41d99b036eac8d97422259ae8ce4c359de3175e.png -resize 16x16 renomeado/category_2573_b41d99b036eac8d97422259ae8ce4c359de3175e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CARLOS ZARATTINI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CARLOS ZARATTINI|'
mv 87f941dde065f898936e7aeecb87a62870a61f34.png renomeado/category_2574_87f941dde065f898936e7aeecb87a62870a61f34.png
convert renomeado/category_2574_87f941dde065f898936e7aeecb87a62870a61f34.png -resize 16x16 renomeado/category_2574_87f941dde065f898936e7aeecb87a62870a61f34_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CELIA ROCHA|'

echo 'No XML fotos este é o nome do Deputado Federal:|CELSO MALDANER|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CELSO MALDANER|'
mv ab5047b259176dae2fba715546a1684f8ee1a737.png renomeado/category_2576_ab5047b259176dae2fba715546a1684f8ee1a737.png
convert renomeado/category_2576_ab5047b259176dae2fba715546a1684f8ee1a737.png -resize 16x16 renomeado/category_2576_ab5047b259176dae2fba715546a1684f8ee1a737_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CESAR COLNAGO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CESAR COLNAGO|'
mv 4bf7f49c763796a9ea08059849122c5e87f17add.png renomeado/category_2577_4bf7f49c763796a9ea08059849122c5e87f17add.png
convert renomeado/category_2577_4bf7f49c763796a9ea08059849122c5e87f17add.png -resize 16x16 renomeado/category_2577_4bf7f49c763796a9ea08059849122c5e87f17add_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CHICO LOPES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CHICO LOPES|'
mv 1c55194e8da256756b8d789a2f197b4d3956900a.png renomeado/category_2578_1c55194e8da256756b8d789a2f197b4d3956900a.png
convert renomeado/category_2578_1c55194e8da256756b8d789a2f197b4d3956900a.png -resize 16x16 renomeado/category_2578_1c55194e8da256756b8d789a2f197b4d3956900a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CIDA BORGHETTI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CIDA BORGHETTI|'
mv 10b8e50cc7ed4d3a59558cf16d19f70e0202af24.png renomeado/category_2579_10b8e50cc7ed4d3a59558cf16d19f70e0202af24.png
convert renomeado/category_2579_10b8e50cc7ed4d3a59558cf16d19f70e0202af24.png -resize 16x16 renomeado/category_2579_10b8e50cc7ed4d3a59558cf16d19f70e0202af24_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CLAUDIO CAJADO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CLAUDIO CAJADO|'
mv 9dd1d56cde49e2352dfe5797a1b8c1efe5846644.png renomeado/category_2580_9dd1d56cde49e2352dfe5797a1b8c1efe5846644.png
convert renomeado/category_2580_9dd1d56cde49e2352dfe5797a1b8c1efe5846644.png -resize 16x16 renomeado/category_2580_9dd1d56cde49e2352dfe5797a1b8c1efe5846644_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CLEBER VERDE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CLEBER VERDE|'
mv 11537445852d578faaf3fdb148974a1dea13c8a7.png renomeado/category_2581_11537445852d578faaf3fdb148974a1dea13c8a7.png
convert renomeado/category_2581_11537445852d578faaf3fdb148974a1dea13c8a7.png -resize 16x16 renomeado/category_2581_11537445852d578faaf3fdb148974a1dea13c8a7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CLÁUDIO PUTY|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CLÁUDIO PUTY|'
mv 85b637f2e01be810d270b91b18a7f145fc253220.png renomeado/category_2582_85b637f2e01be810d270b91b18a7f145fc253220.png
convert renomeado/category_2582_85b637f2e01be810d270b91b18a7f145fc253220.png -resize 16x16 renomeado/category_2582_85b637f2e01be810d270b91b18a7f145fc253220_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|COSTA FERREIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|COSTA FERREIRA|'
mv 496a28d035cdc39e91f7e7995661e4e9c179a6de.png renomeado/category_2583_496a28d035cdc39e91f7e7995661e4e9c179a6de.png
convert renomeado/category_2583_496a28d035cdc39e91f7e7995661e4e9c179a6de.png -resize 16x16 renomeado/category_2583_496a28d035cdc39e91f7e7995661e4e9c179a6de_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CÂNDIDO VACCAREZZA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CÂNDIDO VACCAREZZA|'
mv 714537474636d28b536052040775be1d580a95ee.png renomeado/category_2584_714537474636d28b536052040775be1d580a95ee.png
convert renomeado/category_2584_714537474636d28b536052040775be1d580a95ee.png -resize 16x16 renomeado/category_2584_714537474636d28b536052040775be1d580a95ee_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|CÉSAR HALUM|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|CÉSAR HALUM|'
mv 6b7b633531fe072d93e34911def4f335f36cf350.png renomeado/category_2585_6b7b633531fe072d93e34911def4f335f36cf350.png
convert renomeado/category_2585_6b7b633531fe072d93e34911def4f335f36cf350.png -resize 16x16 renomeado/category_2585_6b7b633531fe072d93e34911def4f335f36cf350_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DALVA FIGUEIREDO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DALVA FIGUEIREDO|'
mv 22d7f245aad99f7d5e019d5618365ec3e5aa76e4.png renomeado/category_2586_22d7f245aad99f7d5e019d5618365ec3e5aa76e4.png
convert renomeado/category_2586_22d7f245aad99f7d5e019d5618365ec3e5aa76e4.png -resize 16x16 renomeado/category_2586_22d7f245aad99f7d5e019d5618365ec3e5aa76e4_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DAMIÃO FELICIANO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DAMIÃO FELICIANO|'
mv ea4f9ba3f4284649168500a3450ec510aa9a2046.png renomeado/category_2587_ea4f9ba3f4284649168500a3450ec510aa9a2046.png
convert renomeado/category_2587_ea4f9ba3f4284649168500a3450ec510aa9a2046.png -resize 16x16 renomeado/category_2587_ea4f9ba3f4284649168500a3450ec510aa9a2046_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DANIEL ALMEIDA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DANIEL ALMEIDA|'
mv 0cfb87e8187874f694ead2fa4ac6e17416121798.png renomeado/category_2588_0cfb87e8187874f694ead2fa4ac6e17416121798.png
convert renomeado/category_2588_0cfb87e8187874f694ead2fa4ac6e17416121798.png -resize 16x16 renomeado/category_2588_0cfb87e8187874f694ead2fa4ac6e17416121798_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DANILO FORTE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DANILO FORTE|'
mv 5dd2196dc4010a2bbeb81be12ae838cbd40897b8.png renomeado/category_2589_5dd2196dc4010a2bbeb81be12ae838cbd40897b8.png
convert renomeado/category_2589_5dd2196dc4010a2bbeb81be12ae838cbd40897b8.png -resize 16x16 renomeado/category_2589_5dd2196dc4010a2bbeb81be12ae838cbd40897b8_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DANRLEI DE DEUS HINTERHOLZ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DANRLEI DE DEUS HINTERHOLZ|'
mv 68d0b5e9924c157dadd887cf9fa954a80c07bb64.png renomeado/category_2590_68d0b5e9924c157dadd887cf9fa954a80c07bb64.png
convert renomeado/category_2590_68d0b5e9924c157dadd887cf9fa954a80c07bb64.png -resize 16x16 renomeado/category_2590_68d0b5e9924c157dadd887cf9fa954a80c07bb64_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DARCÍSIO PERONDI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DARCÍSIO PERONDI|'
mv 182f9fa25f7b6c0464f856631f2f4d728245f94c.png renomeado/category_2591_182f9fa25f7b6c0464f856631f2f4d728245f94c.png
convert renomeado/category_2591_182f9fa25f7b6c0464f856631f2f4d728245f94c.png -resize 16x16 renomeado/category_2591_182f9fa25f7b6c0464f856631f2f4d728245f94c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DAVI ALCOLUMBRE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DAVI ALCOLUMBRE|'
mv 6d443dcd7c252cefbbf0f65ff959667c5fb84ad5.png renomeado/category_2592_6d443dcd7c252cefbbf0f65ff959667c5fb84ad5.png
convert renomeado/category_2592_6d443dcd7c252cefbbf0f65ff959667c5fb84ad5.png -resize 16x16 renomeado/category_2592_6d443dcd7c252cefbbf0f65ff959667c5fb84ad5_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DAVI ALVES SILVA JÚNIOR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DAVI ALVES SILVA JÚNIOR|'
mv b3a736aa55aa5dbfba4e6511917dcc5ec4a70dd1.png renomeado/category_2593_b3a736aa55aa5dbfba4e6511917dcc5ec4a70dd1.png
convert renomeado/category_2593_b3a736aa55aa5dbfba4e6511917dcc5ec4a70dd1.png -resize 16x16 renomeado/category_2593_b3a736aa55aa5dbfba4e6511917dcc5ec4a70dd1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DELEGADO PROTÓGENES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DELEGADO PROTÓGENES|'
mv 99794da1d16fb4d5cb07f30399955a04e88b4570.png renomeado/category_2594_99794da1d16fb4d5cb07f30399955a04e88b4570.png
convert renomeado/category_2594_99794da1d16fb4d5cb07f30399955a04e88b4570.png -resize 16x16 renomeado/category_2594_99794da1d16fb4d5cb07f30399955a04e88b4570_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DEVANIR RIBEIRO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DEVANIR RIBEIRO|'
mv 958827f0154c634d9c14eb99b13ec78022b04f1a.png renomeado/category_2595_958827f0154c634d9c14eb99b13ec78022b04f1a.png
convert renomeado/category_2595_958827f0154c634d9c14eb99b13ec78022b04f1a.png -resize 16x16 renomeado/category_2595_958827f0154c634d9c14eb99b13ec78022b04f1a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DIEGO ANDRADE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DIEGO ANDRADE|'
mv 2f95c7a9fa8aaf804147b8870539aae3126d9436.png renomeado/category_2596_2f95c7a9fa8aaf804147b8870539aae3126d9436.png
convert renomeado/category_2596_2f95c7a9fa8aaf804147b8870539aae3126d9436.png -resize 16x16 renomeado/category_2596_2f95c7a9fa8aaf804147b8870539aae3126d9436_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DILCEU SPERAFICO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DILCEU SPERAFICO|'
mv a31b542830827710a0337e13991128fc50e514cd.png renomeado/category_2597_a31b542830827710a0337e13991128fc50e514cd.png
convert renomeado/category_2597_a31b542830827710a0337e13991128fc50e514cd.png -resize 16x16 renomeado/category_2597_a31b542830827710a0337e13991128fc50e514cd_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DIMAS FABIANO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DIMAS FABIANO|'
mv af739e198e1531fe907cdfea1dd6e829c8cc13e0.png renomeado/category_2598_af739e198e1531fe907cdfea1dd6e829c8cc13e0.png
convert renomeado/category_2598_af739e198e1531fe907cdfea1dd6e829c8cc13e0.png -resize 16x16 renomeado/category_2598_af739e198e1531fe907cdfea1dd6e829c8cc13e0_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DOMINGOS DUTRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DOMINGOS DUTRA|'
mv 7ba3a8d49fcae9f7b9c2c359135089aa0da334ef.png renomeado/category_2599_7ba3a8d49fcae9f7b9c2c359135089aa0da334ef.png
convert renomeado/category_2599_7ba3a8d49fcae9f7b9c2c359135089aa0da334ef.png -resize 16x16 renomeado/category_2599_7ba3a8d49fcae9f7b9c2c359135089aa0da334ef_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DOMINGOS NETO|'

echo 'No XML fotos este é o nome do Deputado Federal:|DOMINGOS SÁVIO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DOMINGOS SÁVIO|'
mv 74315a3c7fdc74a061e6eaf7a40e6568603d6c14.png renomeado/category_2601_74315a3c7fdc74a061e6eaf7a40e6568603d6c14.png
convert renomeado/category_2601_74315a3c7fdc74a061e6eaf7a40e6568603d6c14.png -resize 16x16 renomeado/category_2601_74315a3c7fdc74a061e6eaf7a40e6568603d6c14_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DR. ADILSON SOARES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DR. ADILSON SOARES|'
mv e58e73cad40afaca8ebee880730012f0cd618c2b.png renomeado/category_2602_e58e73cad40afaca8ebee880730012f0cd618c2b.png
convert renomeado/category_2602_e58e73cad40afaca8ebee880730012f0cd618c2b.png -resize 16x16 renomeado/category_2602_e58e73cad40afaca8ebee880730012f0cd618c2b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DR. ALUIZIO|'

echo 'No XML fotos este é o nome do Deputado Federal:|DR. GRILO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DR. GRILO|'
mv 19c9e4c1f0dab2e606697fa15fc076df321b9ad3.png renomeado/category_2604_19c9e4c1f0dab2e606697fa15fc076df321b9ad3.png
convert renomeado/category_2604_19c9e4c1f0dab2e606697fa15fc076df321b9ad3.png -resize 16x16 renomeado/category_2604_19c9e4c1f0dab2e606697fa15fc076df321b9ad3_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DR. JORGE SILVA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DR. JORGE SILVA|'
mv 16e29e535d360de1bce04312317a9139f9f88454.png renomeado/category_2605_16e29e535d360de1bce04312317a9139f9f88454.png
convert renomeado/category_2605_16e29e535d360de1bce04312317a9139f9f88454.png -resize 16x16 renomeado/category_2605_16e29e535d360de1bce04312317a9139f9f88454_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DR. PAULO CÉSAR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DR. PAULO CÉSAR|'
mv 9e5efe354d6353fd2d12b8a158a8f6a6af375def.png renomeado/category_2606_9e5efe354d6353fd2d12b8a158a8f6a6af375def.png
convert renomeado/category_2606_9e5efe354d6353fd2d12b8a158a8f6a6af375def.png -resize 16x16 renomeado/category_2606_9e5efe354d6353fd2d12b8a158a8f6a6af375def_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DR. ROSINHA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DR. ROSINHA|'
mv 2194890e7ef0f04bda5aabc18dfc92cc949c85d4.png renomeado/category_2607_2194890e7ef0f04bda5aabc18dfc92cc949c85d4.png
convert renomeado/category_2607_2194890e7ef0f04bda5aabc18dfc92cc949c85d4.png -resize 16x16 renomeado/category_2607_2194890e7ef0f04bda5aabc18dfc92cc949c85d4_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DUARTE NOGUEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DUARTE NOGUEIRA|'
mv a68ba30a7f9af9542d08084b31f9ae4dea27fa94.png renomeado/category_2608_a68ba30a7f9af9542d08084b31f9ae4dea27fa94.png
convert renomeado/category_2608_a68ba30a7f9af9542d08084b31f9ae4dea27fa94.png -resize 16x16 renomeado/category_2608_a68ba30a7f9af9542d08084b31f9ae4dea27fa94_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DUDIMAR PAXIUBA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DUDIMAR PAXIUBA|'
mv 973789cfc8289f7fabc74e5a5d2b784f88abaa9e.png renomeado/category_2609_973789cfc8289f7fabc74e5a5d2b784f88abaa9e.png
convert renomeado/category_2609_973789cfc8289f7fabc74e5a5d2b784f88abaa9e.png -resize 16x16 renomeado/category_2609_973789cfc8289f7fabc74e5a5d2b784f88abaa9e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|DÉCIO LIMA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|DÉCIO LIMA|'
mv e0172594db7f74009d2d7140a2f7a0727bb20f52.png renomeado/category_2610_e0172594db7f74009d2d7140a2f7a0727bb20f52.png
convert renomeado/category_2610_e0172594db7f74009d2d7140a2f7a0727bb20f52.png -resize 16x16 renomeado/category_2610_e0172594db7f74009d2d7140a2f7a0727bb20f52_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EDINHO ARAÚJO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDINHO ARAÚJO|'
mv bf8a4806a281c83b2abaff844fd8f35fa9cdc233.png renomeado/category_2611_bf8a4806a281c83b2abaff844fd8f35fa9cdc233.png
convert renomeado/category_2611_bf8a4806a281c83b2abaff844fd8f35fa9cdc233.png -resize 16x16 renomeado/category_2611_bf8a4806a281c83b2abaff844fd8f35fa9cdc233_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EDINHO BEZ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDINHO BEZ|'
mv a1aa5cab48172b3f3358495a237f9de980d380c1.png renomeado/category_2612_a1aa5cab48172b3f3358495a237f9de980d380c1.png
convert renomeado/category_2612_a1aa5cab48172b3f3358495a237f9de980d380c1.png -resize 16x16 renomeado/category_2612_a1aa5cab48172b3f3358495a237f9de980d380c1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EDIO LOPES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDIO LOPES|'
mv 056b990df5d8779be3f3561e89237b39e6b6c1d5.png renomeado/category_2613_056b990df5d8779be3f3561e89237b39e6b6c1d5.png
convert renomeado/category_2613_056b990df5d8779be3f3561e89237b39e6b6c1d5.png -resize 16x16 renomeado/category_2613_056b990df5d8779be3f3561e89237b39e6b6c1d5_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDIVALDO HOLANDA JUNIOR|'

echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDMAR ARRUDA|'

echo 'No XML fotos este é o nome do Deputado Federal:|EDSON EZEQUIEL|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDSON EZEQUIEL|'
mv b39f6be2adfb21047477607a1cfe63e4d236a00d.png renomeado/category_2616_b39f6be2adfb21047477607a1cfe63e4d236a00d.png
convert renomeado/category_2616_b39f6be2adfb21047477607a1cfe63e4d236a00d.png -resize 16x16 renomeado/category_2616_b39f6be2adfb21047477607a1cfe63e4d236a00d_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EDSON PIMENTA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDSON PIMENTA|'
mv c8161fa74accf4dfc6f488637d19d5bdcd45de36.png renomeado/category_2617_c8161fa74accf4dfc6f488637d19d5bdcd45de36.png
convert renomeado/category_2617_c8161fa74accf4dfc6f488637d19d5bdcd45de36.png -resize 16x16 renomeado/category_2617_c8161fa74accf4dfc6f488637d19d5bdcd45de36_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EDSON SANTOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDSON SANTOS|'
mv 1620dd47a3bab27670f44eb743da5f345fbf86dd.png renomeado/category_2618_1620dd47a3bab27670f44eb743da5f345fbf86dd.png
convert renomeado/category_2618_1620dd47a3bab27670f44eb743da5f345fbf86dd.png -resize 16x16 renomeado/category_2618_1620dd47a3bab27670f44eb743da5f345fbf86dd_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EDSON SILVA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDSON SILVA|'
mv 09298ad5fd5337c867cf696a5a80b920d85e3d63.png renomeado/category_2619_09298ad5fd5337c867cf696a5a80b920d85e3d63.png
convert renomeado/category_2619_09298ad5fd5337c867cf696a5a80b920d85e3d63.png -resize 16x16 renomeado/category_2619_09298ad5fd5337c867cf696a5a80b920d85e3d63_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EDUARDO AZEREDO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDUARDO AZEREDO|'
mv 2ece0cab171fb6dc114c1602bb04f0a86b4a89bd.png renomeado/category_2620_2ece0cab171fb6dc114c1602bb04f0a86b4a89bd.png
convert renomeado/category_2620_2ece0cab171fb6dc114c1602bb04f0a86b4a89bd.png -resize 16x16 renomeado/category_2620_2ece0cab171fb6dc114c1602bb04f0a86b4a89bd_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EDUARDO BARBOSA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDUARDO BARBOSA|'
mv fba5e65c3a30e59a2d30316942b2b7f62eb04f51.png renomeado/category_2621_fba5e65c3a30e59a2d30316942b2b7f62eb04f51.png
convert renomeado/category_2621_fba5e65c3a30e59a2d30316942b2b7f62eb04f51.png -resize 16x16 renomeado/category_2621_fba5e65c3a30e59a2d30316942b2b7f62eb04f51_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EDUARDO CUNHA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDUARDO CUNHA|'
mv 456c7ac4ed5e996ce2e12e357797f3612a262ef8.png renomeado/category_2622_456c7ac4ed5e996ce2e12e357797f3612a262ef8.png
convert renomeado/category_2622_456c7ac4ed5e996ce2e12e357797f3612a262ef8.png -resize 16x16 renomeado/category_2622_456c7ac4ed5e996ce2e12e357797f3612a262ef8_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EDUARDO DA FONTE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDUARDO DA FONTE|'
mv f8edd4fd519b2ff45038cd1dcb7bc8cb11122d0e.png renomeado/category_2623_f8edd4fd519b2ff45038cd1dcb7bc8cb11122d0e.png
convert renomeado/category_2623_f8edd4fd519b2ff45038cd1dcb7bc8cb11122d0e.png -resize 16x16 renomeado/category_2623_f8edd4fd519b2ff45038cd1dcb7bc8cb11122d0e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDUARDO GOMES|'

echo 'No XML fotos este é o nome do Deputado Federal:|EDUARDO SCIARRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EDUARDO SCIARRA|'
mv ab8db41b9802f6bb4806489d9e098c77651f4103.png renomeado/category_2625_ab8db41b9802f6bb4806489d9e098c77651f4103.png
convert renomeado/category_2625_ab8db41b9802f6bb4806489d9e098c77651f4103.png -resize 16x16 renomeado/category_2625_ab8db41b9802f6bb4806489d9e098c77651f4103_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EFRAIM FILHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EFRAIM FILHO|'
mv 29f3e6c437fa5e9b0aed8b1880b516546099f29e.png renomeado/category_2626_29f3e6c437fa5e9b0aed8b1880b516546099f29e.png
convert renomeado/category_2626_29f3e6c437fa5e9b0aed8b1880b516546099f29e.png -resize 16x16 renomeado/category_2626_29f3e6c437fa5e9b0aed8b1880b516546099f29e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ELCIONE BARBALHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ELCIONE BARBALHO|'
mv 7650ddad380f27623ac136b29ca7789df38c1b8a.png renomeado/category_2627_7650ddad380f27623ac136b29ca7789df38c1b8a.png
convert renomeado/category_2627_7650ddad380f27623ac136b29ca7789df38c1b8a.png -resize 16x16 renomeado/category_2627_7650ddad380f27623ac136b29ca7789df38c1b8a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ELEUSES PAIVA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ELEUSES PAIVA|'
mv 502c64fc00f14bafb75836819190e4383422b3b2.png renomeado/category_2628_502c64fc00f14bafb75836819190e4383422b3b2.png
convert renomeado/category_2628_502c64fc00f14bafb75836819190e4383422b3b2.png -resize 16x16 renomeado/category_2628_502c64fc00f14bafb75836819190e4383422b3b2_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ELI CORREA FILHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ELI CORREA FILHO|'
mv f635700230bdc19f9e50f184d7a4cc11475e2844.png renomeado/category_2629_f635700230bdc19f9e50f184d7a4cc11475e2844.png
convert renomeado/category_2629_f635700230bdc19f9e50f184d7a4cc11475e2844.png -resize 16x16 renomeado/category_2629_f635700230bdc19f9e50f184d7a4cc11475e2844_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ELIENE LIMA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ELIENE LIMA|'
mv 36ab58d5087d28c3cd3b14ec749bdc71109ad138.png renomeado/category_2630_36ab58d5087d28c3cd3b14ec749bdc71109ad138.png
convert renomeado/category_2630_36ab58d5087d28c3cd3b14ec749bdc71109ad138.png -resize 16x16 renomeado/category_2630_36ab58d5087d28c3cd3b14ec749bdc71109ad138_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ELISEU PADILHA|'

echo 'No XML fotos este é o nome do Deputado Federal:|EMANUEL FERNANDES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EMANUEL FERNANDES|'
mv a84d72420d755f0123a3614d65ca69ed24899f68.png renomeado/category_2632_a84d72420d755f0123a3614d65ca69ed24899f68.png
convert renomeado/category_2632_a84d72420d755f0123a3614d65ca69ed24899f68.png -resize 16x16 renomeado/category_2632_a84d72420d755f0123a3614d65ca69ed24899f68_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ENIO BACCI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ENIO BACCI|'
mv 57ffeb2340fc4d197b23f74ba9a159fe9515affc.png renomeado/category_2633_57ffeb2340fc4d197b23f74ba9a159fe9515affc.png
convert renomeado/category_2633_57ffeb2340fc4d197b23f74ba9a159fe9515affc.png -resize 16x16 renomeado/category_2633_57ffeb2340fc4d197b23f74ba9a159fe9515affc_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ERIKA KOKAY|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ERIKA KOKAY|'
mv aaa109b035eb59a9962ca5babff47c7d616ecfd8.png renomeado/category_2634_aaa109b035eb59a9962ca5babff47c7d616ecfd8.png
convert renomeado/category_2634_aaa109b035eb59a9962ca5babff47c7d616ecfd8.png -resize 16x16 renomeado/category_2634_aaa109b035eb59a9962ca5babff47c7d616ecfd8_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ERIVELTON SANTANA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ERIVELTON SANTANA|'
mv 94ef6690f52fce7a11a2010f100eee4903dba524.png renomeado/category_2635_94ef6690f52fce7a11a2010f100eee4903dba524.png
convert renomeado/category_2635_94ef6690f52fce7a11a2010f100eee4903dba524.png -resize 16x16 renomeado/category_2635_94ef6690f52fce7a11a2010f100eee4903dba524_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ESPERIDIÃO AMIN|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ESPERIDIÃO AMIN|'
mv 386cac0ec401f28426d9650b1e9d4b05449e3284.png renomeado/category_2636_386cac0ec401f28426d9650b1e9d4b05449e3284.png
convert renomeado/category_2636_386cac0ec401f28426d9650b1e9d4b05449e3284.png -resize 16x16 renomeado/category_2636_386cac0ec401f28426d9650b1e9d4b05449e3284_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EUDES XAVIER|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EUDES XAVIER|'
mv 5c1e953e5a672d70c191f8398f0dfc84eda94232.png renomeado/category_2637_5c1e953e5a672d70c191f8398f0dfc84eda94232.png
convert renomeado/category_2637_5c1e953e5a672d70c191f8398f0dfc84eda94232.png -resize 16x16 renomeado/category_2637_5c1e953e5a672d70c191f8398f0dfc84eda94232_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|EVANDRO MILHOMEN|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|EVANDRO MILHOMEN|'
mv 2cd8a5f12f8d3ff6eeea6bc7e5e246c1b5de7db2.png renomeado/category_2638_2cd8a5f12f8d3ff6eeea6bc7e5e246c1b5de7db2.png
convert renomeado/category_2638_2cd8a5f12f8d3ff6eeea6bc7e5e246c1b5de7db2.png -resize 16x16 renomeado/category_2638_2cd8a5f12f8d3ff6eeea6bc7e5e246c1b5de7db2_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FABIO TRAD|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FABIO TRAD|'
mv 35f67aa99654534a8f57fc9264249a9a5af682c5.png renomeado/category_2639_35f67aa99654534a8f57fc9264249a9a5af682c5.png
convert renomeado/category_2639_35f67aa99654534a8f57fc9264249a9a5af682c5.png -resize 16x16 renomeado/category_2639_35f67aa99654534a8f57fc9264249a9a5af682c5_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FELIPE BORNIER|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FELIPE BORNIER|'
mv 3c0c682614c615cbd5ea3487adaa43a21aed4b74.png renomeado/category_2640_3c0c682614c615cbd5ea3487adaa43a21aed4b74.png
convert renomeado/category_2640_3c0c682614c615cbd5ea3487adaa43a21aed4b74.png -resize 16x16 renomeado/category_2640_3c0c682614c615cbd5ea3487adaa43a21aed4b74_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FELIPE MAIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FELIPE MAIA|'
mv 33a94ca9b93a1438ac36e8a1e77154be25da5d7a.png renomeado/category_2641_33a94ca9b93a1438ac36e8a1e77154be25da5d7a.png
convert renomeado/category_2641_33a94ca9b93a1438ac36e8a1e77154be25da5d7a.png -resize 16x16 renomeado/category_2641_33a94ca9b93a1438ac36e8a1e77154be25da5d7a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FERNANDO COELHO FILHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FERNANDO COELHO FILHO|'
mv 7b40d8d55837d5f83b49fde2d07b460594edba3e.png renomeado/category_2642_7b40d8d55837d5f83b49fde2d07b460594edba3e.png
convert renomeado/category_2642_7b40d8d55837d5f83b49fde2d07b460594edba3e.png -resize 16x16 renomeado/category_2642_7b40d8d55837d5f83b49fde2d07b460594edba3e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FERNANDO FERRO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FERNANDO FERRO|'
mv f78c3136efcf8ea5b7ced14e34c2ca4ca0eb3bc6.png renomeado/category_2643_f78c3136efcf8ea5b7ced14e34c2ca4ca0eb3bc6.png
convert renomeado/category_2643_f78c3136efcf8ea5b7ced14e34c2ca4ca0eb3bc6.png -resize 16x16 renomeado/category_2643_f78c3136efcf8ea5b7ced14e34c2ca4ca0eb3bc6_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FERNANDO FRANCISCHINI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FERNANDO FRANCISCHINI|'
mv 295793f18edea82599ace07f59b5bb5938af2300.png renomeado/category_2644_295793f18edea82599ace07f59b5bb5938af2300.png
convert renomeado/category_2644_295793f18edea82599ace07f59b5bb5938af2300.png -resize 16x16 renomeado/category_2644_295793f18edea82599ace07f59b5bb5938af2300_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FERNANDO JORDÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FERNANDO JORDÃO|'
mv 34146fb6783f946f5407647d8021db083aba4edf.png renomeado/category_2645_34146fb6783f946f5407647d8021db083aba4edf.png
convert renomeado/category_2645_34146fb6783f946f5407647d8021db083aba4edf.png -resize 16x16 renomeado/category_2645_34146fb6783f946f5407647d8021db083aba4edf_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FERNANDO MARRONI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FERNANDO MARRONI|'
mv e425fcf5a7f54c544e3853d7ff1c55ca574e37d7.png renomeado/category_2646_e425fcf5a7f54c544e3853d7ff1c55ca574e37d7.png
convert renomeado/category_2646_e425fcf5a7f54c544e3853d7ff1c55ca574e37d7.png -resize 16x16 renomeado/category_2646_e425fcf5a7f54c544e3853d7ff1c55ca574e37d7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FERNANDO TORRES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FERNANDO TORRES|'
mv 725e19e3256f7576990edd3acb0cb146a3293cc7.png renomeado/category_2647_725e19e3256f7576990edd3acb0cb146a3293cc7.png
convert renomeado/category_2647_725e19e3256f7576990edd3acb0cb146a3293cc7.png -resize 16x16 renomeado/category_2647_725e19e3256f7576990edd3acb0cb146a3293cc7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FILIPE PEREIRA|'

echo 'No XML fotos este é o nome do Deputado Federal:|FLAVIANO MELO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FLAVIANO MELO|'
mv ebbcb52cdfbc43ba6bf993833545e86b0170a25c.png renomeado/category_2649_ebbcb52cdfbc43ba6bf993833545e86b0170a25c.png
convert renomeado/category_2649_ebbcb52cdfbc43ba6bf993833545e86b0170a25c.png -resize 16x16 renomeado/category_2649_ebbcb52cdfbc43ba6bf993833545e86b0170a25c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FLÁVIA MORAIS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FLÁVIA MORAIS|'
mv a208312c57eac5c977a86b54afc09c7f6b1ec5a3.png renomeado/category_2650_a208312c57eac5c977a86b54afc09c7f6b1ec5a3.png
convert renomeado/category_2650_a208312c57eac5c977a86b54afc09c7f6b1ec5a3.png -resize 16x16 renomeado/category_2650_a208312c57eac5c977a86b54afc09c7f6b1ec5a3_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FRANCISCO ARAÚJO|'

echo 'No XML fotos este é o nome do Deputado Federal:|FRANCISCO ESCÓRCIO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FRANCISCO ESCÓRCIO|'
mv 6a7f25db5f23320f18eba108df847bb65baef095.png renomeado/category_2652_6a7f25db5f23320f18eba108df847bb65baef095.png
convert renomeado/category_2652_6a7f25db5f23320f18eba108df847bb65baef095.png -resize 16x16 renomeado/category_2652_6a7f25db5f23320f18eba108df847bb65baef095_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FRANCISCO FLORIANO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FRANCISCO FLORIANO|'
mv de6aae170e1fd6893615798ec6fb6a69c90cecb4.png renomeado/category_2653_de6aae170e1fd6893615798ec6fb6a69c90cecb4.png
convert renomeado/category_2653_de6aae170e1fd6893615798ec6fb6a69c90cecb4.png -resize 16x16 renomeado/category_2653_de6aae170e1fd6893615798ec6fb6a69c90cecb4_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FRANCISCO PRACIANO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FRANCISCO PRACIANO|'
mv faf47a3b53dc995d8b4a099a91280d8729f33afb.png renomeado/category_2654_faf47a3b53dc995d8b4a099a91280d8729f33afb.png
convert renomeado/category_2654_faf47a3b53dc995d8b4a099a91280d8729f33afb.png -resize 16x16 renomeado/category_2654_faf47a3b53dc995d8b4a099a91280d8729f33afb_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FÁBIO FARIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FÁBIO FARIA|'
mv 91543a0003bbb49c111f8e1beaddbd5ebe41087e.png renomeado/category_2655_91543a0003bbb49c111f8e1beaddbd5ebe41087e.png
convert renomeado/category_2655_91543a0003bbb49c111f8e1beaddbd5ebe41087e.png -resize 16x16 renomeado/category_2655_91543a0003bbb49c111f8e1beaddbd5ebe41087e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FÁBIO RAMALHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FÁBIO RAMALHO|'
mv c765f8d692960c6f48f4ed7da1d3fe32f2077774.png renomeado/category_2656_c765f8d692960c6f48f4ed7da1d3fe32f2077774.png
convert renomeado/category_2656_c765f8d692960c6f48f4ed7da1d3fe32f2077774.png -resize 16x16 renomeado/category_2656_c765f8d692960c6f48f4ed7da1d3fe32f2077774_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FÁBIO SOUTO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FÁBIO SOUTO|'
mv 2d196aef5799168a34fc60410bd56f00a98a840a.png renomeado/category_2657_2d196aef5799168a34fc60410bd56f00a98a840a.png
convert renomeado/category_2657_2d196aef5799168a34fc60410bd56f00a98a840a.png -resize 16x16 renomeado/category_2657_2d196aef5799168a34fc60410bd56f00a98a840a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FÁTIMA BEZERRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FÁTIMA BEZERRA|'
mv 9f2a2d094d898c7df89aba127d72d9e4f51a5f8a.png renomeado/category_2658_9f2a2d094d898c7df89aba127d72d9e4f51a5f8a.png
convert renomeado/category_2658_9f2a2d094d898c7df89aba127d72d9e4f51a5f8a.png -resize 16x16 renomeado/category_2658_9f2a2d094d898c7df89aba127d72d9e4f51a5f8a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FÁTIMA PELAES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FÁTIMA PELAES|'
mv f814463b489bb3c79d7ac73842f35b041b11fa68.png renomeado/category_2659_f814463b489bb3c79d7ac73842f35b041b11fa68.png
convert renomeado/category_2659_f814463b489bb3c79d7ac73842f35b041b11fa68.png -resize 16x16 renomeado/category_2659_f814463b489bb3c79d7ac73842f35b041b11fa68_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|FÉLIX MENDONÇA JÚNIOR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|FÉLIX MENDONÇA JÚNIOR|'
mv 2855c8b7bd94f632aeb05d89796d19aad65dc0a3.png renomeado/category_2660_2855c8b7bd94f632aeb05d89796d19aad65dc0a3.png
convert renomeado/category_2660_2855c8b7bd94f632aeb05d89796d19aad65dc0a3.png -resize 16x16 renomeado/category_2660_2855c8b7bd94f632aeb05d89796d19aad65dc0a3_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GABRIEL CHALITA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GABRIEL CHALITA|'
mv e7f65ca1f9f0d9dc9d299d8efb6cbc80ee40b3c4.png renomeado/category_2661_e7f65ca1f9f0d9dc9d299d8efb6cbc80ee40b3c4.png
convert renomeado/category_2661_e7f65ca1f9f0d9dc9d299d8efb6cbc80ee40b3c4.png -resize 16x16 renomeado/category_2661_e7f65ca1f9f0d9dc9d299d8efb6cbc80ee40b3c4_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GABRIEL GUIMARÃES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GABRIEL GUIMARÃES|'
mv 20ca3311032df098b29a3c699f719c80af8f6b55.png renomeado/category_2662_20ca3311032df098b29a3c699f719c80af8f6b55.png
convert renomeado/category_2662_20ca3311032df098b29a3c699f719c80af8f6b55.png -resize 16x16 renomeado/category_2662_20ca3311032df098b29a3c699f719c80af8f6b55_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GENECIAS NORONHA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GENECIAS NORONHA|'
mv 9070dab16841f993c66099733190ac68f54f983b.png renomeado/category_2663_9070dab16841f993c66099733190ac68f54f983b.png
convert renomeado/category_2663_9070dab16841f993c66099733190ac68f54f983b.png -resize 16x16 renomeado/category_2663_9070dab16841f993c66099733190ac68f54f983b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GEORGE HILTON|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GEORGE HILTON|'
mv 0201f111b3d4a0d34b6603d3436096d9b05ecb09.png renomeado/category_2664_0201f111b3d4a0d34b6603d3436096d9b05ecb09.png
convert renomeado/category_2664_0201f111b3d4a0d34b6603d3436096d9b05ecb09.png -resize 16x16 renomeado/category_2664_0201f111b3d4a0d34b6603d3436096d9b05ecb09_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GERALDO RESENDE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GERALDO RESENDE|'
mv bb038cc3fd798d8b8b425f27ee383e78f30fd0ec.png renomeado/category_2665_bb038cc3fd798d8b8b425f27ee383e78f30fd0ec.png
convert renomeado/category_2665_bb038cc3fd798d8b8b425f27ee383e78f30fd0ec.png -resize 16x16 renomeado/category_2665_bb038cc3fd798d8b8b425f27ee383e78f30fd0ec_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GERALDO SIMÕES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GERALDO SIMÕES|'
mv 5bad754dcdb0c600a49607397a181c36c545d366.png renomeado/category_2666_5bad754dcdb0c600a49607397a181c36c545d366.png
convert renomeado/category_2666_5bad754dcdb0c600a49607397a181c36c545d366.png -resize 16x16 renomeado/category_2666_5bad754dcdb0c600a49607397a181c36c545d366_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GERALDO THADEU|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GERALDO THADEU|'
mv 28da7531b7e8c4469f8a14a7943ffb2708d6d634.png renomeado/category_2667_28da7531b7e8c4469f8a14a7943ffb2708d6d634.png
convert renomeado/category_2667_28da7531b7e8c4469f8a14a7943ffb2708d6d634.png -resize 16x16 renomeado/category_2667_28da7531b7e8c4469f8a14a7943ffb2708d6d634_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GIACOBO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GIACOBO|'
mv 28a65d7270db262c7085daace12a2a1f49e4f2a1.png renomeado/category_2668_28a65d7270db262c7085daace12a2a1f49e4f2a1.png
convert renomeado/category_2668_28a65d7270db262c7085daace12a2a1f49e4f2a1.png -resize 16x16 renomeado/category_2668_28a65d7270db262c7085daace12a2a1f49e4f2a1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GILMAR MACHADO|'

echo 'No XML fotos este é o nome do Deputado Federal:|GIOVANI CHERINI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GIOVANI CHERINI|'
mv b79674dee1a9013883acc61a85be2a1e7a454d41.png renomeado/category_2670_b79674dee1a9013883acc61a85be2a1e7a454d41.png
convert renomeado/category_2670_b79674dee1a9013883acc61a85be2a1e7a454d41.png -resize 16x16 renomeado/category_2670_b79674dee1a9013883acc61a85be2a1e7a454d41_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GIOVANNI QUEIROZ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GIOVANNI QUEIROZ|'
mv aa7d7ff59e3106b47e9a48f2643f8c4865dbce00.png renomeado/category_2671_aa7d7ff59e3106b47e9a48f2643f8c4865dbce00.png
convert renomeado/category_2671_aa7d7ff59e3106b47e9a48f2643f8c4865dbce00.png -resize 16x16 renomeado/category_2671_aa7d7ff59e3106b47e9a48f2643f8c4865dbce00_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GIROTO|'

echo 'No XML fotos este é o nome do Deputado Federal:|GIVALDO CARIMBÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GIVALDO CARIMBÃO|'
mv 6e2959f4bf603282206e8ea0f597bcc71df6762b.png renomeado/category_2673_6e2959f4bf603282206e8ea0f597bcc71df6762b.png
convert renomeado/category_2673_6e2959f4bf603282206e8ea0f597bcc71df6762b.png -resize 16x16 renomeado/category_2673_6e2959f4bf603282206e8ea0f597bcc71df6762b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GLADSON CAMELI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GLADSON CAMELI|'
mv 06323c10060d268d4408f7d8b6e926f72100b9cb.png renomeado/category_2674_06323c10060d268d4408f7d8b6e926f72100b9cb.png
convert renomeado/category_2674_06323c10060d268d4408f7d8b6e926f72100b9cb.png -resize 16x16 renomeado/category_2674_06323c10060d268d4408f7d8b6e926f72100b9cb_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GLAUBER BRAGA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GLAUBER BRAGA|'
mv c05e302aeb0c491d0fe9d2449e65a31ffbfc5ad6.png renomeado/category_2675_c05e302aeb0c491d0fe9d2449e65a31ffbfc5ad6.png
convert renomeado/category_2675_c05e302aeb0c491d0fe9d2449e65a31ffbfc5ad6.png -resize 16x16 renomeado/category_2675_c05e302aeb0c491d0fe9d2449e65a31ffbfc5ad6_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GONZAGA PATRIOTA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GONZAGA PATRIOTA|'
mv 9e4c8148eccb03f3fee3c481fed85403d8432ac6.png renomeado/category_2676_9e4c8148eccb03f3fee3c481fed85403d8432ac6.png
convert renomeado/category_2676_9e4c8148eccb03f3fee3c481fed85403d8432ac6.png -resize 16x16 renomeado/category_2676_9e4c8148eccb03f3fee3c481fed85403d8432ac6_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GORETE PEREIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GORETE PEREIRA|'
mv c0554a763df4553c2ad40abbe849f4a886db5309.png renomeado/category_2677_c0554a763df4553c2ad40abbe849f4a886db5309.png
convert renomeado/category_2677_c0554a763df4553c2ad40abbe849f4a886db5309.png -resize 16x16 renomeado/category_2677_c0554a763df4553c2ad40abbe849f4a886db5309_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GUILHERME CAMPOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GUILHERME CAMPOS|'
mv f5b43e851bdc622697855f7bb52ecece788ebea8.png renomeado/category_2678_f5b43e851bdc622697855f7bb52ecece788ebea8.png
convert renomeado/category_2678_f5b43e851bdc622697855f7bb52ecece788ebea8.png -resize 16x16 renomeado/category_2678_f5b43e851bdc622697855f7bb52ecece788ebea8_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|GUILHERME MUSSI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|GUILHERME MUSSI|'
mv d61ec94d10508cb4f5dec2335823611fe55c2255.png renomeado/category_2679_d61ec94d10508cb4f5dec2335823611fe55c2255.png
convert renomeado/category_2679_d61ec94d10508cb4f5dec2335823611fe55c2255.png -resize 16x16 renomeado/category_2679_d61ec94d10508cb4f5dec2335823611fe55c2255_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HELENO SILVA|'

echo 'No XML fotos este é o nome do Deputado Federal:|HENRIQUE AFONSO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HENRIQUE AFONSO|'
mv 9d99e9076eda9cec1522ecd41756c858a342dc9a.png renomeado/category_2681_9d99e9076eda9cec1522ecd41756c858a342dc9a.png
convert renomeado/category_2681_9d99e9076eda9cec1522ecd41756c858a342dc9a.png -resize 16x16 renomeado/category_2681_9d99e9076eda9cec1522ecd41756c858a342dc9a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|HENRIQUE EDUARDO ALVES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HENRIQUE EDUARDO ALVES|'
mv 8c52e61cf41086befef3562e9c7058dc74d3408b.png renomeado/category_2682_8c52e61cf41086befef3562e9c7058dc74d3408b.png
convert renomeado/category_2682_8c52e61cf41086befef3562e9c7058dc74d3408b.png -resize 16x16 renomeado/category_2682_8c52e61cf41086befef3562e9c7058dc74d3408b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|HENRIQUE FONTANA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HENRIQUE FONTANA|'
mv fae1d11cde3d67528c3fd5b833719ae339be2f2b.png renomeado/category_2683_fae1d11cde3d67528c3fd5b833719ae339be2f2b.png
convert renomeado/category_2683_fae1d11cde3d67528c3fd5b833719ae339be2f2b.png -resize 16x16 renomeado/category_2683_fae1d11cde3d67528c3fd5b833719ae339be2f2b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|HENRIQUE OLIVEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HENRIQUE OLIVEIRA|'
mv b29a195370c9a9c815182aa0075303b6d4d5fe1a.png renomeado/category_2684_b29a195370c9a9c815182aa0075303b6d4d5fe1a.png
convert renomeado/category_2684_b29a195370c9a9c815182aa0075303b6d4d5fe1a.png -resize 16x16 renomeado/category_2684_b29a195370c9a9c815182aa0075303b6d4d5fe1a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|HERMES PARCIANELLO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HERMES PARCIANELLO|'
mv 9a3801bddcfa0d6580564bea06ee484533c1c176.png renomeado/category_2685_9a3801bddcfa0d6580564bea06ee484533c1c176.png
convert renomeado/category_2685_9a3801bddcfa0d6580564bea06ee484533c1c176.png -resize 16x16 renomeado/category_2685_9a3801bddcfa0d6580564bea06ee484533c1c176_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|HEULER CRUVINEL|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HEULER CRUVINEL|'
mv b723cd796e2ddd7ebecfa152f0d045913df4d90d.png renomeado/category_2686_b723cd796e2ddd7ebecfa152f0d045913df4d90d.png
convert renomeado/category_2686_b723cd796e2ddd7ebecfa152f0d045913df4d90d.png -resize 16x16 renomeado/category_2686_b723cd796e2ddd7ebecfa152f0d045913df4d90d_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|HOMERO PEREIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HOMERO PEREIRA|'
mv 4a2ec80bece2f2667fd4f7c208641923fd4578e7.png renomeado/category_2687_4a2ec80bece2f2667fd4f7c208641923fd4578e7.png
convert renomeado/category_2687_4a2ec80bece2f2667fd4f7c208641923fd4578e7.png -resize 16x16 renomeado/category_2687_4a2ec80bece2f2667fd4f7c208641923fd4578e7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|HUGO LEAL|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HUGO LEAL|'
mv 533450bc9f6fe2f277fb22eceecebb0d65f974d7.png renomeado/category_2688_533450bc9f6fe2f277fb22eceecebb0d65f974d7.png
convert renomeado/category_2688_533450bc9f6fe2f277fb22eceecebb0d65f974d7.png -resize 16x16 renomeado/category_2688_533450bc9f6fe2f277fb22eceecebb0d65f974d7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|HUGO MOTTA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HUGO MOTTA|'
mv 7e5def336f77a26b7627940b1a54aefc7b71c061.png renomeado/category_2689_7e5def336f77a26b7627940b1a54aefc7b71c061.png
convert renomeado/category_2689_7e5def336f77a26b7627940b1a54aefc7b71c061.png -resize 16x16 renomeado/category_2689_7e5def336f77a26b7627940b1a54aefc7b71c061_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|HUGO NAPOLEÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HUGO NAPOLEÃO|'
mv d5b8e69763ebfac3a5ceaf704ef1d96d4de7f736.png renomeado/category_2690_d5b8e69763ebfac3a5ceaf704ef1d96d4de7f736.png
convert renomeado/category_2690_d5b8e69763ebfac3a5ceaf704ef1d96d4de7f736.png -resize 16x16 renomeado/category_2690_d5b8e69763ebfac3a5ceaf704ef1d96d4de7f736_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|HÉLIO SANTOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|HÉLIO SANTOS|'
mv 9ee9101aca5e2f306b9ba962bffd325a3e035b43.png renomeado/category_2691_9ee9101aca5e2f306b9ba962bffd325a3e035b43.png
convert renomeado/category_2691_9ee9101aca5e2f306b9ba962bffd325a3e035b43.png -resize 16x16 renomeado/category_2691_9ee9101aca5e2f306b9ba962bffd325a3e035b43_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|INOCÊNCIO OLIVEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|INOCÊNCIO OLIVEIRA|'
mv f0521408ebd5b5c27b06f915001f017dc01d1134.png renomeado/category_2692_f0521408ebd5b5c27b06f915001f017dc01d1134.png
convert renomeado/category_2692_f0521408ebd5b5c27b06f915001f017dc01d1134.png -resize 16x16 renomeado/category_2692_f0521408ebd5b5c27b06f915001f017dc01d1134_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|IRACEMA PORTELLA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|IRACEMA PORTELLA|'
mv d05a2c5a1bae4066a527fb88f86a7a66e8f8dd12.png renomeado/category_2693_d05a2c5a1bae4066a527fb88f86a7a66e8f8dd12.png
convert renomeado/category_2693_d05a2c5a1bae4066a527fb88f86a7a66e8f8dd12.png -resize 16x16 renomeado/category_2693_d05a2c5a1bae4066a527fb88f86a7a66e8f8dd12_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|IRAJÁ ABREU|'

echo 'No XML fotos este é o nome do Deputado Federal:|IRINY LOPES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|IRINY LOPES|'
mv 5433a1a3ae86af0c03a0609e186240edbc746500.png renomeado/category_2695_5433a1a3ae86af0c03a0609e186240edbc746500.png
convert renomeado/category_2695_5433a1a3ae86af0c03a0609e186240edbc746500.png -resize 16x16 renomeado/category_2695_5433a1a3ae86af0c03a0609e186240edbc746500_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ISAÍAS SILVESTRE|'

echo 'No XML fotos este é o nome do Deputado Federal:|IVAN VALENTE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|IVAN VALENTE|'
mv b3c9ef69c681a8898e903f9a0e5ad089a519f151.png renomeado/category_2697_b3c9ef69c681a8898e903f9a0e5ad089a519f151.png
convert renomeado/category_2697_b3c9ef69c681a8898e903f9a0e5ad089a519f151.png -resize 16x16 renomeado/category_2697_b3c9ef69c681a8898e903f9a0e5ad089a519f151_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|IZALCI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|IZALCI|'
mv 0f2bd32138a4b59ff497daf9a33b1009f9251a22.png renomeado/category_2698_0f2bd32138a4b59ff497daf9a33b1009f9251a22.png
convert renomeado/category_2698_0f2bd32138a4b59ff497daf9a33b1009f9251a22.png -resize 16x16 renomeado/category_2698_0f2bd32138a4b59ff497daf9a33b1009f9251a22_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JAIME MARTINS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JAIME MARTINS|'
mv 7396b2f7a76da0667bfec4d29cfa6c97ff809031.png renomeado/category_2699_7396b2f7a76da0667bfec4d29cfa6c97ff809031.png
convert renomeado/category_2699_7396b2f7a76da0667bfec4d29cfa6c97ff809031.png -resize 16x16 renomeado/category_2699_7396b2f7a76da0667bfec4d29cfa6c97ff809031_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JAIR BOLSONARO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JAIR BOLSONARO|'
mv c3215a0d7b3f467352604ee85bee745a2d73d29b.png renomeado/category_2700_c3215a0d7b3f467352604ee85bee745a2d73d29b.png
convert renomeado/category_2700_c3215a0d7b3f467352604ee85bee745a2d73d29b.png -resize 16x16 renomeado/category_2700_c3215a0d7b3f467352604ee85bee745a2d73d29b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JAIRO ATAÍDE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JAIRO ATAÍDE|'
mv c74c4a3716bc55551c07687fa51892e2fc498fd4.png renomeado/category_2701_c74c4a3716bc55551c07687fa51892e2fc498fd4.png
convert renomeado/category_2701_c74c4a3716bc55551c07687fa51892e2fc498fd4.png -resize 16x16 renomeado/category_2701_c74c4a3716bc55551c07687fa51892e2fc498fd4_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JANDIRA FEGHALI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JANDIRA FEGHALI|'
mv c0fc50bb560a34c86fc90e722b5e7a3823a37e79.png renomeado/category_2702_c0fc50bb560a34c86fc90e722b5e7a3823a37e79.png
convert renomeado/category_2702_c0fc50bb560a34c86fc90e722b5e7a3823a37e79.png -resize 16x16 renomeado/category_2702_c0fc50bb560a34c86fc90e722b5e7a3823a37e79_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JANETE CAPIBERIBE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JANETE CAPIBERIBE|'
mv 6c57794fe5045ba21d126b4f69c27ae63987322c.png renomeado/category_2703_6c57794fe5045ba21d126b4f69c27ae63987322c.png
convert renomeado/category_2703_6c57794fe5045ba21d126b4f69c27ae63987322c.png -resize 16x16 renomeado/category_2703_6c57794fe5045ba21d126b4f69c27ae63987322c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JANETE ROCHA PIETÁ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JANETE ROCHA PIETÁ|'
mv 3854244a52c29fed2ece7b5720438ffbd979cd71.png renomeado/category_2704_3854244a52c29fed2ece7b5720438ffbd979cd71.png
convert renomeado/category_2704_3854244a52c29fed2ece7b5720438ffbd979cd71.png -resize 16x16 renomeado/category_2704_3854244a52c29fed2ece7b5720438ffbd979cd71_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JAQUELINE RORIZ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JAQUELINE RORIZ|'
mv a4cdeab152f7bbc06367199527b108785d4bc75d.png renomeado/category_2705_a4cdeab152f7bbc06367199527b108785d4bc75d.png
convert renomeado/category_2705_a4cdeab152f7bbc06367199527b108785d4bc75d.png -resize 16x16 renomeado/category_2705_a4cdeab152f7bbc06367199527b108785d4bc75d_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JEAN WYLLYS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JEAN WYLLYS|'
mv a4302f37827f9e3ed418c9af1bca5b3d31a75e97.png renomeado/category_2706_a4302f37827f9e3ed418c9af1bca5b3d31a75e97.png
convert renomeado/category_2706_a4302f37827f9e3ed418c9af1bca5b3d31a75e97.png -resize 16x16 renomeado/category_2706_a4302f37827f9e3ed418c9af1bca5b3d31a75e97_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JEFFERSON CAMPOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JEFFERSON CAMPOS|'
mv 56aa5e7e813b627a9de34b4cbb022b781c3d0403.png renomeado/category_2707_56aa5e7e813b627a9de34b4cbb022b781c3d0403.png
convert renomeado/category_2707_56aa5e7e813b627a9de34b4cbb022b781c3d0403.png -resize 16x16 renomeado/category_2707_56aa5e7e813b627a9de34b4cbb022b781c3d0403_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JERÔNIMO GOERGEN|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JERÔNIMO GOERGEN|'
mv 83a9da37d2d43fe0f4d79c85adb78a779fb3cedb.png renomeado/category_2708_83a9da37d2d43fe0f4d79c85adb78a779fb3cedb.png
convert renomeado/category_2708_83a9da37d2d43fe0f4d79c85adb78a779fb3cedb.png -resize 16x16 renomeado/category_2708_83a9da37d2d43fe0f4d79c85adb78a779fb3cedb_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JESUS RODRIGUES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JESUS RODRIGUES|'
mv 933bd97d8ce5ee756e588723ac640c6974fa7708.png renomeado/category_2709_933bd97d8ce5ee756e588723ac640c6974fa7708.png
convert renomeado/category_2709_933bd97d8ce5ee756e588723ac640c6974fa7708.png -resize 16x16 renomeado/category_2709_933bd97d8ce5ee756e588723ac640c6974fa7708_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JHONATAN DE JESUS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JHONATAN DE JESUS|'
mv 5b18747906b59df53bee452aacf63adf3aa15c9f.png renomeado/category_2710_5b18747906b59df53bee452aacf63adf3aa15c9f.png
convert renomeado/category_2710_5b18747906b59df53bee452aacf63adf3aa15c9f.png -resize 16x16 renomeado/category_2710_5b18747906b59df53bee452aacf63adf3aa15c9f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JILMAR TATTO|'

echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOAQUIM BELTRÃO|'

echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JONAS DONIZETTE|'

echo 'No XML fotos este é o nome do Deputado Federal:|JORGE BITTAR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JORGE BITTAR|'
mv f5addb2631b4751f093b6bc2b410182794fc4a9a.png renomeado/category_2714_f5addb2631b4751f093b6bc2b410182794fc4a9a.png
convert renomeado/category_2714_f5addb2631b4751f093b6bc2b410182794fc4a9a.png -resize 16x16 renomeado/category_2714_f5addb2631b4751f093b6bc2b410182794fc4a9a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JORGE BOEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JORGE BOEIRA|'
mv 7cb008ac8bace83ece722c7834f98575eb4a55dc.png renomeado/category_2715_7cb008ac8bace83ece722c7834f98575eb4a55dc.png
convert renomeado/category_2715_7cb008ac8bace83ece722c7834f98575eb4a55dc.png -resize 16x16 renomeado/category_2715_7cb008ac8bace83ece722c7834f98575eb4a55dc_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JORGE CORTE REAL|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JORGE CORTE REAL|'
mv a254597b97d7f5ee1d148bc1b9cafccbfb7df661.png renomeado/category_2716_a254597b97d7f5ee1d148bc1b9cafccbfb7df661.png
convert renomeado/category_2716_a254597b97d7f5ee1d148bc1b9cafccbfb7df661.png -resize 16x16 renomeado/category_2716_a254597b97d7f5ee1d148bc1b9cafccbfb7df661_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JORGE TADEU MUDALEN|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JORGE TADEU MUDALEN|'
mv eb45f5843a206e27d71fd7e634a119dd22243d05.png renomeado/category_2717_eb45f5843a206e27d71fd7e634a119dd22243d05.png
convert renomeado/category_2717_eb45f5843a206e27d71fd7e634a119dd22243d05.png -resize 16x16 renomeado/category_2717_eb45f5843a206e27d71fd7e634a119dd22243d05_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JORGINHO MELLO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JORGINHO MELLO|'
mv 9ef9ab78716c89215434aac87a84511192fa183a.png renomeado/category_2718_9ef9ab78716c89215434aac87a84511192fa183a.png
convert renomeado/category_2718_9ef9ab78716c89215434aac87a84511192fa183a.png -resize 16x16 renomeado/category_2718_9ef9ab78716c89215434aac87a84511192fa183a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSE STÉDILE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSE STÉDILE|'
mv c493f48af63a453fc3fba4a0d2580b6b6ef72f08.png renomeado/category_2719_c493f48af63a453fc3fba4a0d2580b6b6ef72f08.png
convert renomeado/category_2719_c493f48af63a453fc3fba4a0d2580b6b6ef72f08.png -resize 16x16 renomeado/category_2719_c493f48af63a453fc3fba4a0d2580b6b6ef72f08_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSIAS GOMES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSIAS GOMES|'
mv 284ff534fe8d9534fde5c0cb3897c098b998b2a0.png renomeado/category_2720_284ff534fe8d9534fde5c0cb3897c098b998b2a0.png
convert renomeado/category_2720_284ff534fe8d9534fde5c0cb3897c098b998b2a0.png -resize 16x16 renomeado/category_2720_284ff534fe8d9534fde5c0cb3897c098b998b2a0_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSUÉ BENGTSON|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSUÉ BENGTSON|'
mv a9b3bb6eaec9dffcee76efca215096c7e08b2de0.png renomeado/category_2721_a9b3bb6eaec9dffcee76efca215096c7e08b2de0.png
convert renomeado/category_2721_a9b3bb6eaec9dffcee76efca215096c7e08b2de0.png -resize 16x16 renomeado/category_2721_a9b3bb6eaec9dffcee76efca215096c7e08b2de0_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ AIRTON|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ AIRTON|'
mv d270bdb7281bedea4ef414daef5d4ee690313f6e.png renomeado/category_2722_d270bdb7281bedea4ef414daef5d4ee690313f6e.png
convert renomeado/category_2722_d270bdb7281bedea4ef414daef5d4ee690313f6e.png -resize 16x16 renomeado/category_2722_d270bdb7281bedea4ef414daef5d4ee690313f6e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ AUGUSTO MAIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ AUGUSTO MAIA|'
mv 83b08c0bb945800ba9be14b82d295e2f8e383c83.png renomeado/category_2723_83b08c0bb945800ba9be14b82d295e2f8e383c83.png
convert renomeado/category_2723_83b08c0bb945800ba9be14b82d295e2f8e383c83.png -resize 16x16 renomeado/category_2723_83b08c0bb945800ba9be14b82d295e2f8e383c83_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ CARLOS ARAÚJO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ CARLOS ARAÚJO|'
mv 429b2a54d2ce16f27bc3f94f227324f3d0dd5029.png renomeado/category_2724_429b2a54d2ce16f27bc3f94f227324f3d0dd5029.png
convert renomeado/category_2724_429b2a54d2ce16f27bc3f94f227324f3d0dd5029.png -resize 16x16 renomeado/category_2724_429b2a54d2ce16f27bc3f94f227324f3d0dd5029_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ CHAVES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ CHAVES|'
mv 9cddf4a4e7beab798d07b635e1e702036ba1db98.png renomeado/category_2725_9cddf4a4e7beab798d07b635e1e702036ba1db98.png
convert renomeado/category_2725_9cddf4a4e7beab798d07b635e1e702036ba1db98.png -resize 16x16 renomeado/category_2725_9cddf4a4e7beab798d07b635e1e702036ba1db98_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ DE FILIPPI|'

echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ GUIMARÃES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ GUIMARÃES|'
mv c199a16e0d9653b2b9690148c46abbb6ca85d063.png renomeado/category_2727_c199a16e0d9653b2b9690148c46abbb6ca85d063.png
convert renomeado/category_2727_c199a16e0d9653b2b9690148c46abbb6ca85d063.png -resize 16x16 renomeado/category_2727_c199a16e0d9653b2b9690148c46abbb6ca85d063_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ HUMBERTO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ HUMBERTO|'
mv 1ce5fcd14ddf4d889015354b4e45fdf6308981b5.png renomeado/category_2728_1ce5fcd14ddf4d889015354b4e45fdf6308981b5.png
convert renomeado/category_2728_1ce5fcd14ddf4d889015354b4e45fdf6308981b5.png -resize 16x16 renomeado/category_2728_1ce5fcd14ddf4d889015354b4e45fdf6308981b5_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ LINHARES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ LINHARES|'
mv 646837124eb3d367cd6ea76f47a713db8e62aac9.png renomeado/category_2729_646837124eb3d367cd6ea76f47a713db8e62aac9.png
convert renomeado/category_2729_646837124eb3d367cd6ea76f47a713db8e62aac9.png -resize 16x16 renomeado/category_2729_646837124eb3d367cd6ea76f47a713db8e62aac9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ MENTOR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ MENTOR|'
mv 822922a65fdf2feb2db474a2a3ec774e623f9c8d.png renomeado/category_2730_822922a65fdf2feb2db474a2a3ec774e623f9c8d.png
convert renomeado/category_2730_822922a65fdf2feb2db474a2a3ec774e623f9c8d.png -resize 16x16 renomeado/category_2730_822922a65fdf2feb2db474a2a3ec774e623f9c8d_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ NUNES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ NUNES|'
mv 83e34dd45b97df3252e8174322025a21b4c338e0.png renomeado/category_2731_83e34dd45b97df3252e8174322025a21b4c338e0.png
convert renomeado/category_2731_83e34dd45b97df3252e8174322025a21b4c338e0.png -resize 16x16 renomeado/category_2731_83e34dd45b97df3252e8174322025a21b4c338e0_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ OTÁVIO GERMANO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ OTÁVIO GERMANO|'
mv ecebe8b9b87201f5ceb9a92766a1259f57f3f874.png renomeado/category_2732_ecebe8b9b87201f5ceb9a92766a1259f57f3f874.png
convert renomeado/category_2732_ecebe8b9b87201f5ceb9a92766a1259f57f3f874.png -resize 16x16 renomeado/category_2732_ecebe8b9b87201f5ceb9a92766a1259f57f3f874_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ PRIANTE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ PRIANTE|'
mv f06488271f93ae365365625a13bf1cba91a1ad3e.png renomeado/category_2733_f06488271f93ae365365625a13bf1cba91a1ad3e.png
convert renomeado/category_2733_f06488271f93ae365365625a13bf1cba91a1ad3e.png -resize 16x16 renomeado/category_2733_f06488271f93ae365365625a13bf1cba91a1ad3e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOSÉ ROCHA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOSÉ ROCHA|'
mv a5268b72c99f10fe37ed7c35dfc3f69534735983.png renomeado/category_2734_a5268b72c99f10fe37ed7c35dfc3f69534735983.png
convert renomeado/category_2734_a5268b72c99f10fe37ed7c35dfc3f69534735983.png -resize 16x16 renomeado/category_2734_a5268b72c99f10fe37ed7c35dfc3f69534735983_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOVAIR ARANTES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOVAIR ARANTES|'
mv afc71573681e85bddda7d38087d124c2f8c1edf7.png renomeado/category_2735_afc71573681e85bddda7d38087d124c2f8c1edf7.png
convert renomeado/category_2735_afc71573681e85bddda7d38087d124c2f8c1edf7.png -resize 16x16 renomeado/category_2735_afc71573681e85bddda7d38087d124c2f8c1edf7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO ANANIAS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO ANANIAS|'
mv 9170b7def44f7dc851f37bc23b38669ee25fe29f.png renomeado/category_2736_9170b7def44f7dc851f37bc23b38669ee25fe29f.png
convert renomeado/category_2736_9170b7def44f7dc851f37bc23b38669ee25fe29f.png -resize 16x16 renomeado/category_2736_9170b7def44f7dc851f37bc23b38669ee25fe29f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO ARRUDA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO ARRUDA|'
mv 5e5b68377877f7def25c334277ce10edb9df02e2.png renomeado/category_2737_5e5b68377877f7def25c334277ce10edb9df02e2.png
convert renomeado/category_2737_5e5b68377877f7def25c334277ce10edb9df02e2.png -resize 16x16 renomeado/category_2737_5e5b68377877f7def25c334277ce10edb9df02e2_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO BITTAR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO BITTAR|'
mv 95f84b3b97ee7692377b529e377a8c739c6b8ba5.png renomeado/category_2738_95f84b3b97ee7692377b529e377a8c739c6b8ba5.png
convert renomeado/category_2738_95f84b3b97ee7692377b529e377a8c739c6b8ba5.png -resize 16x16 renomeado/category_2738_95f84b3b97ee7692377b529e377a8c739c6b8ba5_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO CAMPOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO CAMPOS|'
mv 1fb51a178b436ca96924123f4a0d7b2983296723.png renomeado/category_2739_1fb51a178b436ca96924123f4a0d7b2983296723.png
convert renomeado/category_2739_1fb51a178b436ca96924123f4a0d7b2983296723.png -resize 16x16 renomeado/category_2739_1fb51a178b436ca96924123f4a0d7b2983296723_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO CARLOS BACELAR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO CARLOS BACELAR|'
mv eadd9244bf1ccc6e1b2a8a4b5e3c214a6422a53f.png renomeado/category_2740_eadd9244bf1ccc6e1b2a8a4b5e3c214a6422a53f.png
convert renomeado/category_2740_eadd9244bf1ccc6e1b2a8a4b5e3c214a6422a53f.png -resize 16x16 renomeado/category_2740_eadd9244bf1ccc6e1b2a8a4b5e3c214a6422a53f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO DADO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO DADO|'
mv 5f253e62e4520b8f5cf8798f7e8cc86ef55beb52.png renomeado/category_2741_5f253e62e4520b8f5cf8798f7e8cc86ef55beb52.png
convert renomeado/category_2741_5f253e62e4520b8f5cf8798f7e8cc86ef55beb52.png -resize 16x16 renomeado/category_2741_5f253e62e4520b8f5cf8798f7e8cc86ef55beb52_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO LEÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO LEÃO|'
mv f47875a8eff5e4b1658caf0f12459232efdd4127.png renomeado/category_2742_f47875a8eff5e4b1658caf0f12459232efdd4127.png
convert renomeado/category_2742_f47875a8eff5e4b1658caf0f12459232efdd4127.png -resize 16x16 renomeado/category_2742_f47875a8eff5e4b1658caf0f12459232efdd4127_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO LYRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO LYRA|'
mv 937f8033bcff5f33c0ff5f4ad63a904273ef04c2.png renomeado/category_2743_937f8033bcff5f33c0ff5f4ad63a904273ef04c2.png
convert renomeado/category_2743_937f8033bcff5f33c0ff5f4ad63a904273ef04c2.png -resize 16x16 renomeado/category_2743_937f8033bcff5f33c0ff5f4ad63a904273ef04c2_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO MAGALHÃES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO MAGALHÃES|'
mv 75a738ed7a16ecbed270f0122336793cc79c9b8f.png renomeado/category_2744_75a738ed7a16ecbed270f0122336793cc79c9b8f.png
convert renomeado/category_2744_75a738ed7a16ecbed270f0122336793cc79c9b8f.png -resize 16x16 renomeado/category_2744_75a738ed7a16ecbed270f0122336793cc79c9b8f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO MAIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO MAIA|'
mv 1a19b29c9fb78d2aea8539b598846c6f3b273174.png renomeado/category_2745_1a19b29c9fb78d2aea8539b598846c6f3b273174.png
convert renomeado/category_2745_1a19b29c9fb78d2aea8539b598846c6f3b273174.png -resize 16x16 renomeado/category_2745_1a19b29c9fb78d2aea8539b598846c6f3b273174_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO PAULO CUNHA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO PAULO CUNHA|'
mv e61474636f58c6c3ae2e5d13a4a78192e67f2a26.png renomeado/category_2746_e61474636f58c6c3ae2e5d13a4a78192e67f2a26.png
convert renomeado/category_2746_e61474636f58c6c3ae2e5d13a4a78192e67f2a26.png -resize 16x16 renomeado/category_2746_e61474636f58c6c3ae2e5d13a4a78192e67f2a26_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO PAULO LIMA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO PAULO LIMA|'
mv f3aa8ff6c766af73df0c78893003de3275f208e1.png renomeado/category_2747_f3aa8ff6c766af73df0c78893003de3275f208e1.png
convert renomeado/category_2747_f3aa8ff6c766af73df0c78893003de3275f208e1.png -resize 16x16 renomeado/category_2747_f3aa8ff6c766af73df0c78893003de3275f208e1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JOÃO PIZZOLATTI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO PIZZOLATTI|'
mv d37eae00cd7b14f045f7e3b94d258efd5328b7a1.png renomeado/category_2748_d37eae00cd7b14f045f7e3b94d258efd5328b7a1.png
convert renomeado/category_2748_d37eae00cd7b14f045f7e3b94d258efd5328b7a1.png -resize 16x16 renomeado/category_2748_d37eae00cd7b14f045f7e3b94d258efd5328b7a1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JOÃO RODRIGUES|'

echo 'No XML fotos este é o nome do Deputado Federal:|JUNJI ABE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JUNJI ABE|'
mv 55e58ae8c01955e4e196d5fdf8743ed5b6753624.png renomeado/category_2750_55e58ae8c01955e4e196d5fdf8743ed5b6753624.png
convert renomeado/category_2750_55e58ae8c01955e4e196d5fdf8743ed5b6753624.png -resize 16x16 renomeado/category_2750_55e58ae8c01955e4e196d5fdf8743ed5b6753624_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JUTAHY JUNIOR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JUTAHY JUNIOR|'
mv f5f99edc62d58a6e957544d57cef6b71ab9ab844.png renomeado/category_2751_f5f99edc62d58a6e957544d57cef6b71ab9ab844.png
convert renomeado/category_2751_f5f99edc62d58a6e957544d57cef6b71ab9ab844.png -resize 16x16 renomeado/category_2751_f5f99edc62d58a6e957544d57cef6b71ab9ab844_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JÂNIO NATAL|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JÂNIO NATAL|'
mv f03984a0dbcf42025e1904f4e17533a816cf7e8c.png renomeado/category_2752_f03984a0dbcf42025e1904f4e17533a816cf7e8c.png
convert renomeado/category_2752_f03984a0dbcf42025e1904f4e17533a816cf7e8c.png -resize 16x16 renomeado/category_2752_f03984a0dbcf42025e1904f4e17533a816cf7e8c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JÔ MORAES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JÔ MORAES|'
mv 6ceac19d56369bcc9f588baf4424b88395a76e29.png renomeado/category_2753_6ceac19d56369bcc9f588baf4424b88395a76e29.png
convert renomeado/category_2753_6ceac19d56369bcc9f588baf4424b88395a76e29.png -resize 16x16 renomeado/category_2753_6ceac19d56369bcc9f588baf4424b88395a76e29_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JÚLIO CAMPOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JÚLIO CAMPOS|'
mv d1d224854c2f07f150432e349a9272594e69f937.png renomeado/category_2754_d1d224854c2f07f150432e349a9272594e69f937.png
convert renomeado/category_2754_d1d224854c2f07f150432e349a9272594e69f937.png -resize 16x16 renomeado/category_2754_d1d224854c2f07f150432e349a9272594e69f937_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JÚLIO CESAR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JÚLIO CESAR|'
mv 653187cf4beb35ea5acf5114839d666c8c7f8915.png renomeado/category_2755_653187cf4beb35ea5acf5114839d666c8c7f8915.png
convert renomeado/category_2755_653187cf4beb35ea5acf5114839d666c8c7f8915.png -resize 16x16 renomeado/category_2755_653187cf4beb35ea5acf5114839d666c8c7f8915_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JÚLIO DELGADO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JÚLIO DELGADO|'
mv 65e871131e3b1b3ba69521c29cd8f593fccd2e2f.png renomeado/category_2756_65e871131e3b1b3ba69521c29cd8f593fccd2e2f.png
convert renomeado/category_2756_65e871131e3b1b3ba69521c29cd8f593fccd2e2f.png -resize 16x16 renomeado/category_2756_65e871131e3b1b3ba69521c29cd8f593fccd2e2f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|JÚNIOR COIMBRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|JÚNIOR COIMBRA|'
mv 7cc7e7886bf6143799959c7aafe208047015451b.png renomeado/category_2757_7cc7e7886bf6143799959c7aafe208047015451b.png
convert renomeado/category_2757_7cc7e7886bf6143799959c7aafe208047015451b.png -resize 16x16 renomeado/category_2757_7cc7e7886bf6143799959c7aafe208047015451b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|KEIKO OTA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|KEIKO OTA|'
mv 1e2aaced5830799ed57493d0c89e89f96925b8c8.png renomeado/category_2758_1e2aaced5830799ed57493d0c89e89f96925b8c8.png
convert renomeado/category_2758_1e2aaced5830799ed57493d0c89e89f96925b8c8.png -resize 16x16 renomeado/category_2758_1e2aaced5830799ed57493d0c89e89f96925b8c8_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LAEL VARELLA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LAEL VARELLA|'
mv addf9aba5a4a5a9b033ab6f242191c1179c7aca1.png renomeado/category_2759_addf9aba5a4a5a9b033ab6f242191c1179c7aca1.png
convert renomeado/category_2759_addf9aba5a4a5a9b033ab6f242191c1179c7aca1.png -resize 16x16 renomeado/category_2759_addf9aba5a4a5a9b033ab6f242191c1179c7aca1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LAERCIO OLIVEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LAERCIO OLIVEIRA|'
mv 25892abd8374ba8bf01b1e317342b3b170c00241.png renomeado/category_2760_25892abd8374ba8bf01b1e317342b3b170c00241.png
convert renomeado/category_2760_25892abd8374ba8bf01b1e317342b3b170c00241.png -resize 16x16 renomeado/category_2760_25892abd8374ba8bf01b1e317342b3b170c00241_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LAUREZ MOREIRA|'

echo 'No XML fotos este é o nome do Deputado Federal:|LAURIETE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LAURIETE|'
mv ebbc79d5f75d0e97db399531d1ee9c819b0f714f.png renomeado/category_2762_ebbc79d5f75d0e97db399531d1ee9c819b0f714f.png
convert renomeado/category_2762_ebbc79d5f75d0e97db399531d1ee9c819b0f714f.png -resize 16x16 renomeado/category_2762_ebbc79d5f75d0e97db399531d1ee9c819b0f714f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LEANDRO VILELA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LEANDRO VILELA|'
mv ff23263a1d1ac0e0e2d2fec9a02544a1bc81d24e.png renomeado/category_2763_ff23263a1d1ac0e0e2d2fec9a02544a1bc81d24e.png
convert renomeado/category_2763_ff23263a1d1ac0e0e2d2fec9a02544a1bc81d24e.png -resize 16x16 renomeado/category_2763_ff23263a1d1ac0e0e2d2fec9a02544a1bc81d24e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LELO COIMBRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LELO COIMBRA|'
mv 8db1a033207d90626f39178158043ad7e8d1fb8c.png renomeado/category_2764_8db1a033207d90626f39178158043ad7e8d1fb8c.png
convert renomeado/category_2764_8db1a033207d90626f39178158043ad7e8d1fb8c.png -resize 16x16 renomeado/category_2764_8db1a033207d90626f39178158043ad7e8d1fb8c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LEONARDO GADELHA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LEONARDO GADELHA|'
mv 3f89a4a082458faa7f42316322d7adfb1b0cc424.png renomeado/category_2765_3f89a4a082458faa7f42316322d7adfb1b0cc424.png
convert renomeado/category_2765_3f89a4a082458faa7f42316322d7adfb1b0cc424.png -resize 16x16 renomeado/category_2765_3f89a4a082458faa7f42316322d7adfb1b0cc424_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LEONARDO MONTEIRO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LEONARDO MONTEIRO|'
mv d0ada8b6ce8db79bdc043dc3d4809db46cab57e1.png renomeado/category_2766_d0ada8b6ce8db79bdc043dc3d4809db46cab57e1.png
convert renomeado/category_2766_d0ada8b6ce8db79bdc043dc3d4809db46cab57e1.png -resize 16x16 renomeado/category_2766_d0ada8b6ce8db79bdc043dc3d4809db46cab57e1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LEONARDO PICCIANI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LEONARDO PICCIANI|'
mv bfda6431623e6a7ecfdfdcb07505b2c67aa3605b.png renomeado/category_2767_bfda6431623e6a7ecfdfdcb07505b2c67aa3605b.png
convert renomeado/category_2767_bfda6431623e6a7ecfdfdcb07505b2c67aa3605b.png -resize 16x16 renomeado/category_2767_bfda6431623e6a7ecfdfdcb07505b2c67aa3605b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LEONARDO QUINTÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LEONARDO QUINTÃO|'
mv 889459d9f7344cd3b977eb9f61e3a7ae0a58e7af.png renomeado/category_2768_889459d9f7344cd3b977eb9f61e3a7ae0a58e7af.png
convert renomeado/category_2768_889459d9f7344cd3b977eb9f61e3a7ae0a58e7af.png -resize 16x16 renomeado/category_2768_889459d9f7344cd3b977eb9f61e3a7ae0a58e7af_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LEONARDO VILELA|'

echo 'No XML fotos este é o nome do Deputado Federal:|LEOPOLDO MEYER|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LEOPOLDO MEYER|'
mv f85fd7b4eb3710b956085f944960c8d48e8d6a86.png renomeado/category_2770_f85fd7b4eb3710b956085f944960c8d48e8d6a86.png
convert renomeado/category_2770_f85fd7b4eb3710b956085f944960c8d48e8d6a86.png -resize 16x16 renomeado/category_2770_f85fd7b4eb3710b956085f944960c8d48e8d6a86_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LILIAM SÁ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LILIAM SÁ|'
mv 2a0a15f92f425029f872e1df7bc32ce8b05a4aa8.png renomeado/category_2771_2a0a15f92f425029f872e1df7bc32ce8b05a4aa8.png
convert renomeado/category_2771_2a0a15f92f425029f872e1df7bc32ce8b05a4aa8.png -resize 16x16 renomeado/category_2771_2a0a15f92f425029f872e1df7bc32ce8b05a4aa8_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LINCOLN PORTELA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LINCOLN PORTELA|'
mv 650fba9465562b63d689f987476b664c57544149.png renomeado/category_2772_650fba9465562b63d689f987476b664c57544149.png
convert renomeado/category_2772_650fba9465562b63d689f987476b664c57544149.png -resize 16x16 renomeado/category_2772_650fba9465562b63d689f987476b664c57544149_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LIRA MAIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LIRA MAIA|'
mv 8255fe04b558b2740c0f32b2fe4bf249f3a9f113.png renomeado/category_2773_8255fe04b558b2740c0f32b2fe4bf249f3a9f113.png
convert renomeado/category_2773_8255fe04b558b2740c0f32b2fe4bf249f3a9f113.png -resize 16x16 renomeado/category_2773_8255fe04b558b2740c0f32b2fe4bf249f3a9f113_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LOURIVAL MENDES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LOURIVAL MENDES|'
mv 6788c4380abf0e0d67ae55ea1302ea6201716c07.png renomeado/category_2774_6788c4380abf0e0d67ae55ea1302ea6201716c07.png
convert renomeado/category_2774_6788c4380abf0e0d67ae55ea1302ea6201716c07.png -resize 16x16 renomeado/category_2774_6788c4380abf0e0d67ae55ea1302ea6201716c07_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUCI CHOINACKI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUCI CHOINACKI|'
mv 10e42af826706a9b4e1c63161fa69536d01a1501.png renomeado/category_2775_10e42af826706a9b4e1c63161fa69536d01a1501.png
convert renomeado/category_2775_10e42af826706a9b4e1c63161fa69536d01a1501.png -resize 16x16 renomeado/category_2775_10e42af826706a9b4e1c63161fa69536d01a1501_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUCIANA SANTOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUCIANA SANTOS|'
mv 22bda8d4175a9480787748bda7137f9bda842757.png renomeado/category_2776_22bda8d4175a9480787748bda7137f9bda842757.png
convert renomeado/category_2776_22bda8d4175a9480787748bda7137f9bda842757.png -resize 16x16 renomeado/category_2776_22bda8d4175a9480787748bda7137f9bda842757_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUCIANO CASTRO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUCIANO CASTRO|'
mv ea4c67dd733d8e57d3a4712082c417ac5470fa32.png renomeado/category_2777_ea4c67dd733d8e57d3a4712082c417ac5470fa32.png
convert renomeado/category_2777_ea4c67dd733d8e57d3a4712082c417ac5470fa32.png -resize 16x16 renomeado/category_2777_ea4c67dd733d8e57d3a4712082c417ac5470fa32_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUCIO VIEIRA LIMA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUCIO VIEIRA LIMA|'
mv d51a06a39d74d9137756eb42b0f0a04d1b661daf.png renomeado/category_2778_d51a06a39d74d9137756eb42b0f0a04d1b661daf.png
convert renomeado/category_2778_d51a06a39d74d9137756eb42b0f0a04d1b661daf.png -resize 16x16 renomeado/category_2778_d51a06a39d74d9137756eb42b0f0a04d1b661daf_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUIS CARLOS HEINZE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIS CARLOS HEINZE|'
mv 7dc7ff992466c1d816283f6cad821adaf7c10e0f.png renomeado/category_2779_7dc7ff992466c1d816283f6cad821adaf7c10e0f.png
convert renomeado/category_2779_7dc7ff992466c1d816283f6cad821adaf7c10e0f.png -resize 16x16 renomeado/category_2779_7dc7ff992466c1d816283f6cad821adaf7c10e0f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUIS TIBÉ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIS TIBÉ|'
mv 368db07e0d3c1681a9ae1b7489681e88e8e0d398.png renomeado/category_2780_368db07e0d3c1681a9ae1b7489681e88e8e0d398.png
convert renomeado/category_2780_368db07e0d3c1681a9ae1b7489681e88e8e0d398.png -resize 16x16 renomeado/category_2780_368db07e0d3c1681a9ae1b7489681e88e8e0d398_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUIZ ALBERTO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIZ ALBERTO|'
mv 61e6c9b79ddcfd0571792ba665498799cf4bb949.png renomeado/category_2781_61e6c9b79ddcfd0571792ba665498799cf4bb949.png
convert renomeado/category_2781_61e6c9b79ddcfd0571792ba665498799cf4bb949.png -resize 16x16 renomeado/category_2781_61e6c9b79ddcfd0571792ba665498799cf4bb949_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUIZ ARGÔLO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIZ ARGÔLO|'
mv fbe32c2d1168a76b4ba4e9eb61cdbaf7daf9caf9.png renomeado/category_2782_fbe32c2d1168a76b4ba4e9eb61cdbaf7daf9caf9.png
convert renomeado/category_2782_fbe32c2d1168a76b4ba4e9eb61cdbaf7daf9caf9.png -resize 16x16 renomeado/category_2782_fbe32c2d1168a76b4ba4e9eb61cdbaf7daf9caf9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUIZ CARLOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIZ CARLOS|'
mv 97f29b691541ba10b24fae5fac10c61394c8d608.png renomeado/category_2783_97f29b691541ba10b24fae5fac10c61394c8d608.png
convert renomeado/category_2783_97f29b691541ba10b24fae5fac10c61394c8d608.png -resize 16x16 renomeado/category_2783_97f29b691541ba10b24fae5fac10c61394c8d608_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIZ CARLOS SETIM|'

echo 'No XML fotos este é o nome do Deputado Federal:|LUIZ COUTO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIZ COUTO|'
mv 8473bc537a640b61bdb6cb505fdbd6f0bdb7c3cf.png renomeado/category_2785_8473bc537a640b61bdb6cb505fdbd6f0bdb7c3cf.png
convert renomeado/category_2785_8473bc537a640b61bdb6cb505fdbd6f0bdb7c3cf.png -resize 16x16 renomeado/category_2785_8473bc537a640b61bdb6cb505fdbd6f0bdb7c3cf_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUIZ FERNANDO FARIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIZ FERNANDO FARIA|'
mv af75a27332c63aa217de76d10d36ca813fee4e5c.png renomeado/category_2786_af75a27332c63aa217de76d10d36ca813fee4e5c.png
convert renomeado/category_2786_af75a27332c63aa217de76d10d36ca813fee4e5c.png -resize 16x16 renomeado/category_2786_af75a27332c63aa217de76d10d36ca813fee4e5c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUIZ FERNANDO MACHADO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIZ FERNANDO MACHADO|'
mv 43bc25a021e28d8cf71f6015941d5274f0da9429.png renomeado/category_2787_43bc25a021e28d8cf71f6015941d5274f0da9429.png
convert renomeado/category_2787_43bc25a021e28d8cf71f6015941d5274f0da9429.png -resize 16x16 renomeado/category_2787_43bc25a021e28d8cf71f6015941d5274f0da9429_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUIZ NISHIMORI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIZ NISHIMORI|'
mv 0723058e52f6c412949498452e6f931f0a45af5c.png renomeado/category_2788_0723058e52f6c412949498452e6f931f0a45af5c.png
convert renomeado/category_2788_0723058e52f6c412949498452e6f931f0a45af5c.png -resize 16x16 renomeado/category_2788_0723058e52f6c412949498452e6f931f0a45af5c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUIZ PITIMAN|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIZ PITIMAN|'
mv 149a5e27afbe9fbd3c03fbe25da240cf6fb47cea.png renomeado/category_2789_149a5e27afbe9fbd3c03fbe25da240cf6fb47cea.png
convert renomeado/category_2789_149a5e27afbe9fbd3c03fbe25da240cf6fb47cea.png -resize 16x16 renomeado/category_2789_149a5e27afbe9fbd3c03fbe25da240cf6fb47cea_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUIZ SÉRGIO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIZ SÉRGIO|'
mv 1ae5a0501d134aa8833b7afb87645b39d690d126.png renomeado/category_2790_1ae5a0501d134aa8833b7afb87645b39d690d126.png
convert renomeado/category_2790_1ae5a0501d134aa8833b7afb87645b39d690d126.png -resize 16x16 renomeado/category_2790_1ae5a0501d134aa8833b7afb87645b39d690d126_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LUIZA ERUNDINA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LUIZA ERUNDINA|'
mv 561b78b8502ecbb447b255e668e1283e2b25f11f.png renomeado/category_2791_561b78b8502ecbb447b255e668e1283e2b25f11f.png
convert renomeado/category_2791_561b78b8502ecbb447b255e668e1283e2b25f11f.png -resize 16x16 renomeado/category_2791_561b78b8502ecbb447b255e668e1283e2b25f11f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LÁZARO BOTELHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LÁZARO BOTELHO|'
mv 3da00f79b7ed65e973b915475b594c74d2b73d94.png renomeado/category_2792_3da00f79b7ed65e973b915475b594c74d2b73d94.png
convert renomeado/category_2792_3da00f79b7ed65e973b915475b594c74d2b73d94.png -resize 16x16 renomeado/category_2792_3da00f79b7ed65e973b915475b594c74d2b73d94_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|LÚCIO VALE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|LÚCIO VALE|'
mv 2d6221b1661cdda50f165d2d8e0ccb46cd7ed4eb.png renomeado/category_2793_2d6221b1661cdda50f165d2d8e0ccb46cd7ed4eb.png
convert renomeado/category_2793_2d6221b1661cdda50f165d2d8e0ccb46cd7ed4eb.png -resize 16x16 renomeado/category_2793_2d6221b1661cdda50f165d2d8e0ccb46cd7ed4eb_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MAGELA|'

echo 'No XML fotos este é o nome do Deputado Federal:|MANATO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MANATO|'
mv 1d41ca5464f784be0a8c0ac0d48c4a88f3ac3e1b.png renomeado/category_2795_1d41ca5464f784be0a8c0ac0d48c4a88f3ac3e1b.png
convert renomeado/category_2795_1d41ca5464f784be0a8c0ac0d48c4a88f3ac3e1b.png -resize 16x16 renomeado/category_2795_1d41ca5464f784be0a8c0ac0d48c4a88f3ac3e1b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MANDETTA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MANDETTA|'
mv 0266197ac5eec522149d0e3366db952f7f5c4454.png renomeado/category_2796_0266197ac5eec522149d0e3366db952f7f5c4454.png
convert renomeado/category_2796_0266197ac5eec522149d0e3366db952f7f5c4454.png -resize 16x16 renomeado/category_2796_0266197ac5eec522149d0e3366db952f7f5c4454_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MANOEL JUNIOR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MANOEL JUNIOR|'
mv baaa8d49e1177f400c58ef4eb47de803e53d6590.png renomeado/category_2797_baaa8d49e1177f400c58ef4eb47de803e53d6590.png
convert renomeado/category_2797_baaa8d49e1177f400c58ef4eb47de803e53d6590.png -resize 16x16 renomeado/category_2797_baaa8d49e1177f400c58ef4eb47de803e53d6590_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MANOEL SALVIANO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MANOEL SALVIANO|'
mv 6f9a34a655beeb113bc1f54cb02e4303acbcd8e9.png renomeado/category_2798_6f9a34a655beeb113bc1f54cb02e4303acbcd8e9.png
convert renomeado/category_2798_6f9a34a655beeb113bc1f54cb02e4303acbcd8e9.png -resize 16x16 renomeado/category_2798_6f9a34a655beeb113bc1f54cb02e4303acbcd8e9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MANUELA D'ÁVILA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MANUELA D'ÁVILA|'
mv 59a478ada7d6d63b35715cd49cac575ed6ee6107.png renomeado/category_2799_59a478ada7d6d63b35715cd49cac575ed6ee6107.png
convert renomeado/category_2799_59a478ada7d6d63b35715cd49cac575ed6ee6107.png -resize 16x16 renomeado/category_2799_59a478ada7d6d63b35715cd49cac575ed6ee6107_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARA GABRILLI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARA GABRILLI|'
mv 6d1ab00f7ee13c493063a091d22b12bbb3ed9725.png renomeado/category_2800_6d1ab00f7ee13c493063a091d22b12bbb3ed9725.png
convert renomeado/category_2800_6d1ab00f7ee13c493063a091d22b12bbb3ed9725.png -resize 16x16 renomeado/category_2800_6d1ab00f7ee13c493063a091d22b12bbb3ed9725_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARCELO AGUIAR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARCELO AGUIAR|'
mv e5dde2ca3e91b5a39fb9846d82ca010b6189741f.png renomeado/category_2801_e5dde2ca3e91b5a39fb9846d82ca010b6189741f.png
convert renomeado/category_2801_e5dde2ca3e91b5a39fb9846d82ca010b6189741f.png -resize 16x16 renomeado/category_2801_e5dde2ca3e91b5a39fb9846d82ca010b6189741f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARCELO CASTRO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARCELO CASTRO|'
mv b3969bb108759b73bd6bf3c727554771c2eb12d6.png renomeado/category_2802_b3969bb108759b73bd6bf3c727554771c2eb12d6.png
convert renomeado/category_2802_b3969bb108759b73bd6bf3c727554771c2eb12d6.png -resize 16x16 renomeado/category_2802_b3969bb108759b73bd6bf3c727554771c2eb12d6_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARCELO MATOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARCELO MATOS|'
mv 0e8665ef03fda45f5c52fb5ea6f946dd69c9b658.png renomeado/category_2803_0e8665ef03fda45f5c52fb5ea6f946dd69c9b658.png
convert renomeado/category_2803_0e8665ef03fda45f5c52fb5ea6f946dd69c9b658.png -resize 16x16 renomeado/category_2803_0e8665ef03fda45f5c52fb5ea6f946dd69c9b658_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARCIO BITTAR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARCIO BITTAR|'
mv 5d39b908d115d9a1c8f2a5615cfd094cb4cd4280.png renomeado/category_2804_5d39b908d115d9a1c8f2a5615cfd094cb4cd4280.png
convert renomeado/category_2804_5d39b908d115d9a1c8f2a5615cfd094cb4cd4280.png -resize 16x16 renomeado/category_2804_5d39b908d115d9a1c8f2a5615cfd094cb4cd4280_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARCO MAIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARCO MAIA|'
mv 577170c13535f435aecfa996965567525b4fde35.png renomeado/category_2805_577170c13535f435aecfa996965567525b4fde35.png
convert renomeado/category_2805_577170c13535f435aecfa996965567525b4fde35.png -resize 16x16 renomeado/category_2805_577170c13535f435aecfa996965567525b4fde35_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARCO TEBALDI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARCO TEBALDI|'
mv e16ef050f2b06bf33fdd51fb044624b698a2f14b.png renomeado/category_2806_e16ef050f2b06bf33fdd51fb044624b698a2f14b.png
convert renomeado/category_2806_e16ef050f2b06bf33fdd51fb044624b698a2f14b.png -resize 16x16 renomeado/category_2806_e16ef050f2b06bf33fdd51fb044624b698a2f14b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARCON|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARCON|'
mv 9313c2eaccfcf84e83c59dae8b4b0262b59f7bbf.png renomeado/category_2807_9313c2eaccfcf84e83c59dae8b4b0262b59f7bbf.png
convert renomeado/category_2807_9313c2eaccfcf84e83c59dae8b4b0262b59f7bbf.png -resize 16x16 renomeado/category_2807_9313c2eaccfcf84e83c59dae8b4b0262b59f7bbf_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARCOS MEDRADO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARCOS MEDRADO|'
mv d095aa041ef148b6965c1c4abade1efeb3386822.png renomeado/category_2808_d095aa041ef148b6965c1c4abade1efeb3386822.png
convert renomeado/category_2808_d095aa041ef148b6965c1c4abade1efeb3386822.png -resize 16x16 renomeado/category_2808_d095aa041ef148b6965c1c4abade1efeb3386822_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARCOS MONTES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARCOS MONTES|'
mv 3f1002b058e81a87e423cea7733a6b6eaf030578.png renomeado/category_2809_3f1002b058e81a87e423cea7733a6b6eaf030578.png
convert renomeado/category_2809_3f1002b058e81a87e423cea7733a6b6eaf030578.png -resize 16x16 renomeado/category_2809_3f1002b058e81a87e423cea7733a6b6eaf030578_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARCOS ROGÉRIO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARCOS ROGÉRIO|'
mv 0c7467e68ea6c9bf4110283e6a00b847247404f3.png renomeado/category_2810_0c7467e68ea6c9bf4110283e6a00b847247404f3.png
convert renomeado/category_2810_0c7467e68ea6c9bf4110283e6a00b847247404f3.png -resize 16x16 renomeado/category_2810_0c7467e68ea6c9bf4110283e6a00b847247404f3_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARCUS PESTANA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARCUS PESTANA|'
mv 905d49669f7abf01b16b0633107be5ef287091f9.png renomeado/category_2811_905d49669f7abf01b16b0633107be5ef287091f9.png
convert renomeado/category_2811_905d49669f7abf01b16b0633107be5ef287091f9.png -resize 16x16 renomeado/category_2811_905d49669f7abf01b16b0633107be5ef287091f9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARINHA RAUPP|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARINHA RAUPP|'
mv ad4bee0f942aeaed66778534d1d889ee23976445.png renomeado/category_2812_ad4bee0f942aeaed66778534d1d889ee23976445.png
convert renomeado/category_2812_ad4bee0f942aeaed66778534d1d889ee23976445.png -resize 16x16 renomeado/category_2812_ad4bee0f942aeaed66778534d1d889ee23976445_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARLLOS SAMPAIO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARLLOS SAMPAIO|'
mv 49cb386c2bc74de031c17d24d1618ec5a4339b4f.png renomeado/category_2813_49cb386c2bc74de031c17d24d1618ec5a4339b4f.png
convert renomeado/category_2813_49cb386c2bc74de031c17d24d1618ec5a4339b4f.png -resize 16x16 renomeado/category_2813_49cb386c2bc74de031c17d24d1618ec5a4339b4f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MARÇAL FILHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MARÇAL FILHO|'
mv d486774a7af8c6d8430002340be9128f1889efe5.png renomeado/category_2814_d486774a7af8c6d8430002340be9128f1889efe5.png
convert renomeado/category_2814_d486774a7af8c6d8430002340be9128f1889efe5.png -resize 16x16 renomeado/category_2814_d486774a7af8c6d8430002340be9128f1889efe5_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MAURO BENEVIDES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MAURO BENEVIDES|'
mv 3b90c71e0f9350db6c5638ed3b84b0aa2bcfefb9.png renomeado/category_2815_3b90c71e0f9350db6c5638ed3b84b0aa2bcfefb9.png
convert renomeado/category_2815_3b90c71e0f9350db6c5638ed3b84b0aa2bcfefb9.png -resize 16x16 renomeado/category_2815_3b90c71e0f9350db6c5638ed3b84b0aa2bcfefb9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MAURO LOPES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MAURO LOPES|'
mv 5b786274f7650e7932d45b27f67d8646a0b4ef84.png renomeado/category_2816_5b786274f7650e7932d45b27f67d8646a0b4ef84.png
convert renomeado/category_2816_5b786274f7650e7932d45b27f67d8646a0b4ef84.png -resize 16x16 renomeado/category_2816_5b786274f7650e7932d45b27f67d8646a0b4ef84_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MAURO MARIANI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MAURO MARIANI|'
mv f0bccb84ea930c5d35e9a65dd60df1295b7ee844.png renomeado/category_2817_f0bccb84ea930c5d35e9a65dd60df1295b7ee844.png
convert renomeado/category_2817_f0bccb84ea930c5d35e9a65dd60df1295b7ee844.png -resize 16x16 renomeado/category_2817_f0bccb84ea930c5d35e9a65dd60df1295b7ee844_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MAURO NAZIF|'

echo 'No XML fotos este é o nome do Deputado Federal:|MAURÍCIO QUINTELLA LESSA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MAURÍCIO QUINTELLA LESSA|'
mv 1cbe28f273780c2990066b94b473a0a2b916d7ed.png renomeado/category_2819_1cbe28f273780c2990066b94b473a0a2b916d7ed.png
convert renomeado/category_2819_1cbe28f273780c2990066b94b473a0a2b916d7ed.png -resize 16x16 renomeado/category_2819_1cbe28f273780c2990066b94b473a0a2b916d7ed_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MAURÍCIO TRINDADE|'

echo 'No XML fotos este é o nome do Deputado Federal:|MENDONÇA FILHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MENDONÇA FILHO|'
mv a5fe3d0c69d2185b4338eb9e781f42c5183dc96c.png renomeado/category_2821_a5fe3d0c69d2185b4338eb9e781f42c5183dc96c.png
convert renomeado/category_2821_a5fe3d0c69d2185b4338eb9e781f42c5183dc96c.png -resize 16x16 renomeado/category_2821_a5fe3d0c69d2185b4338eb9e781f42c5183dc96c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MENDONÇA PRADO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MENDONÇA PRADO|'
mv 0a3767662aeee29922e79f79416b5a4a807a7d69.png renomeado/category_2822_0a3767662aeee29922e79f79416b5a4a807a7d69.png
convert renomeado/category_2822_0a3767662aeee29922e79f79416b5a4a807a7d69.png -resize 16x16 renomeado/category_2822_0a3767662aeee29922e79f79416b5a4a807a7d69_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MIGUEL CORRÊA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MIGUEL CORRÊA|'
mv ad7734fdff707cc79dabc4e6bfa588ff1b41aeb2.png renomeado/category_2823_ad7734fdff707cc79dabc4e6bfa588ff1b41aeb2.png
convert renomeado/category_2823_ad7734fdff707cc79dabc4e6bfa588ff1b41aeb2.png -resize 16x16 renomeado/category_2823_ad7734fdff707cc79dabc4e6bfa588ff1b41aeb2_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MILTON MONTI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MILTON MONTI|'
mv a60047ca95bc1303623e6cf624b757f1a539e2ba.png renomeado/category_2824_a60047ca95bc1303623e6cf624b757f1a539e2ba.png
convert renomeado/category_2824_a60047ca95bc1303623e6cf624b757f1a539e2ba.png -resize 16x16 renomeado/category_2824_a60047ca95bc1303623e6cf624b757f1a539e2ba_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MIRIQUINHO BATISTA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MIRIQUINHO BATISTA|'
mv b7ca1644224fdd13436ce7733729dfc20a6c0637.png renomeado/category_2825_b7ca1644224fdd13436ce7733729dfc20a6c0637.png
convert renomeado/category_2825_b7ca1644224fdd13436ce7733729dfc20a6c0637.png -resize 16x16 renomeado/category_2825_b7ca1644224fdd13436ce7733729dfc20a6c0637_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MIRO TEIXEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MIRO TEIXEIRA|'
mv 628e79c086721104da0ef7a1fb211bf87674bd08.png renomeado/category_2826_628e79c086721104da0ef7a1fb211bf87674bd08.png
convert renomeado/category_2826_628e79c086721104da0ef7a1fb211bf87674bd08.png -resize 16x16 renomeado/category_2826_628e79c086721104da0ef7a1fb211bf87674bd08_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MISSIONÁRIO JOSÉ OLIMPIO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MISSIONÁRIO JOSÉ OLIMPIO|'
mv b35d3fa6971e702423546df840a510557da923f6.png renomeado/category_2827_b35d3fa6971e702423546df840a510557da923f6.png
convert renomeado/category_2827_b35d3fa6971e702423546df840a510557da923f6.png -resize 16x16 renomeado/category_2827_b35d3fa6971e702423546df840a510557da923f6_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MOREIRA MENDES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MOREIRA MENDES|'
mv 94696bd706300d0020cd557748df0ef4dfe7d6ba.png renomeado/category_2828_94696bd706300d0020cd557748df0ef4dfe7d6ba.png
convert renomeado/category_2828_94696bd706300d0020cd557748df0ef4dfe7d6ba.png -resize 16x16 renomeado/category_2828_94696bd706300d0020cd557748df0ef4dfe7d6ba_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MÁRCIO FRANÇA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MÁRCIO FRANÇA|'
mv 2f3a728891d48a4304dfa683ecd6b245acfbb20e.png renomeado/category_2829_2f3a728891d48a4304dfa683ecd6b245acfbb20e.png
convert renomeado/category_2829_2f3a728891d48a4304dfa683ecd6b245acfbb20e.png -resize 16x16 renomeado/category_2829_2f3a728891d48a4304dfa683ecd6b245acfbb20e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MÁRCIO MACÊDO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MÁRCIO MACÊDO|'
mv d97a4928fc951b163c0d0327a6741e8ab587ccd0.png renomeado/category_2830_d97a4928fc951b163c0d0327a6741e8ab587ccd0.png
convert renomeado/category_2830_d97a4928fc951b163c0d0327a6741e8ab587ccd0.png -resize 16x16 renomeado/category_2830_d97a4928fc951b163c0d0327a6741e8ab587ccd0_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|MÁRCIO MARINHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MÁRCIO MARINHO|'
mv 79f48f2023ede21581d617174ea97c87a8c862b9.png renomeado/category_2831_79f48f2023ede21581d617174ea97c87a8c862b9.png
convert renomeado/category_2831_79f48f2023ede21581d617174ea97c87a8c862b9.png -resize 16x16 renomeado/category_2831_79f48f2023ede21581d617174ea97c87a8c862b9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MÁRCIO REINALDO MOREIRA|'

echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MÁRIO DE OLIVEIRA|'

echo 'No XML fotos este é o nome do Deputado Federal:|MÁRIO NEGROMONTE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|MÁRIO NEGROMONTE|'
mv c9c9c30e3469306310b9ade4be6d00c453985058.png renomeado/category_2834_c9c9c30e3469306310b9ade4be6d00c453985058.png
convert renomeado/category_2834_c9c9c30e3469306310b9ade4be6d00c453985058.png -resize 16x16 renomeado/category_2834_c9c9c30e3469306310b9ade4be6d00c453985058_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NATAN DONADON|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NATAN DONADON|'
mv f3249a4ac86f90ad35aa77811dbcb495c7682ff1.png renomeado/category_2835_f3249a4ac86f90ad35aa77811dbcb495c7682ff1.png
convert renomeado/category_2835_f3249a4ac86f90ad35aa77811dbcb495c7682ff1.png -resize 16x16 renomeado/category_2835_f3249a4ac86f90ad35aa77811dbcb495c7682ff1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NAZARENO FONTELES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NAZARENO FONTELES|'
mv 3ce301e7f751a16667ef33984a04ba9611a9c612.png renomeado/category_2836_3ce301e7f751a16667ef33984a04ba9611a9c612.png
convert renomeado/category_2836_3ce301e7f751a16667ef33984a04ba9611a9c612.png -resize 16x16 renomeado/category_2836_3ce301e7f751a16667ef33984a04ba9611a9c612_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NEILTON MULIM|'

echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NELSON BORNIER|'

echo 'No XML fotos este é o nome do Deputado Federal:|NELSON MARCHEZAN JUNIOR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NELSON MARCHEZAN JUNIOR|'
mv 6710d8b101a2720f455b2ce3f746759030269f2f.png renomeado/category_2839_6710d8b101a2720f455b2ce3f746759030269f2f.png
convert renomeado/category_2839_6710d8b101a2720f455b2ce3f746759030269f2f.png -resize 16x16 renomeado/category_2839_6710d8b101a2720f455b2ce3f746759030269f2f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NELSON MARQUEZELLI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NELSON MARQUEZELLI|'
mv 4725c2054f3239295201553bbcf38ba46e97a98a.png renomeado/category_2840_4725c2054f3239295201553bbcf38ba46e97a98a.png
convert renomeado/category_2840_4725c2054f3239295201553bbcf38ba46e97a98a.png -resize 16x16 renomeado/category_2840_4725c2054f3239295201553bbcf38ba46e97a98a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NELSON MEURER|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NELSON MEURER|'
mv 8e7af9a228dec008deb667aab6f1bbc984ace57f.png renomeado/category_2841_8e7af9a228dec008deb667aab6f1bbc984ace57f.png
convert renomeado/category_2841_8e7af9a228dec008deb667aab6f1bbc984ace57f.png -resize 16x16 renomeado/category_2841_8e7af9a228dec008deb667aab6f1bbc984ace57f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NELSON PADOVANI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NELSON PADOVANI|'
mv aeb9282f8cbf8aa2230b2a784120e96ca612e4c9.png renomeado/category_2842_aeb9282f8cbf8aa2230b2a784120e96ca612e4c9.png
convert renomeado/category_2842_aeb9282f8cbf8aa2230b2a784120e96ca612e4c9.png -resize 16x16 renomeado/category_2842_aeb9282f8cbf8aa2230b2a784120e96ca612e4c9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NELSON PELLEGRINO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NELSON PELLEGRINO|'
mv a0d564bc27c8f0f9efc9462c03215131832480a2.png renomeado/category_2843_a0d564bc27c8f0f9efc9462c03215131832480a2.png
convert renomeado/category_2843_a0d564bc27c8f0f9efc9462c03215131832480a2.png -resize 16x16 renomeado/category_2843_a0d564bc27c8f0f9efc9462c03215131832480a2_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NEWTON CARDOSO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NEWTON CARDOSO|'
mv 2b15e857c4655696213c706430ffbf4f9c74e555.png renomeado/category_2844_2b15e857c4655696213c706430ffbf4f9c74e555.png
convert renomeado/category_2844_2b15e857c4655696213c706430ffbf4f9c74e555.png -resize 16x16 renomeado/category_2844_2b15e857c4655696213c706430ffbf4f9c74e555_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NEWTON LIMA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NEWTON LIMA|'
mv 208eb55419be8335678163ed55cd32fb025765bb.png renomeado/category_2845_208eb55419be8335678163ed55cd32fb025765bb.png
convert renomeado/category_2845_208eb55419be8335678163ed55cd32fb025765bb.png -resize 16x16 renomeado/category_2845_208eb55419be8335678163ed55cd32fb025765bb_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NICE LOBÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NICE LOBÃO|'
mv b33f9e7c32dbdb0eda2f6caf170ef0c038ebe715.png renomeado/category_2846_b33f9e7c32dbdb0eda2f6caf170ef0c038ebe715.png
convert renomeado/category_2846_b33f9e7c32dbdb0eda2f6caf170ef0c038ebe715.png -resize 16x16 renomeado/category_2846_b33f9e7c32dbdb0eda2f6caf170ef0c038ebe715_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NILDA GONDIM|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NILDA GONDIM|'
mv b618255a9fed88fab0dd578bfcb3d9997724542a.png renomeado/category_2847_b618255a9fed88fab0dd578bfcb3d9997724542a.png
convert renomeado/category_2847_b618255a9fed88fab0dd578bfcb3d9997724542a.png -resize 16x16 renomeado/category_2847_b618255a9fed88fab0dd578bfcb3d9997724542a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NILSON LEITÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NILSON LEITÃO|'
mv 1a3c43c4f532cab546eb4ffeb2c1a9664a245e27.png renomeado/category_2848_1a3c43c4f532cab546eb4ffeb2c1a9664a245e27.png
convert renomeado/category_2848_1a3c43c4f532cab546eb4ffeb2c1a9664a245e27.png -resize 16x16 renomeado/category_2848_1a3c43c4f532cab546eb4ffeb2c1a9664a245e27_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|NILTON CAPIXABA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|NILTON CAPIXABA|'
mv f134558d5112feb5997348a6b2704b2f99f2e3c2.png renomeado/category_2849_f134558d5112feb5997348a6b2704b2f99f2e3c2.png
convert renomeado/category_2849_f134558d5112feb5997348a6b2704b2f99f2e3c2.png -resize 16x16 renomeado/category_2849_f134558d5112feb5997348a6b2704b2f99f2e3c2_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ODAIR CUNHA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ODAIR CUNHA|'
mv 050ca924357683b613f2b8178809bf1dcdda02dc.png renomeado/category_2850_050ca924357683b613f2b8178809bf1dcdda02dc.png
convert renomeado/category_2850_050ca924357683b613f2b8178809bf1dcdda02dc.png -resize 16x16 renomeado/category_2850_050ca924357683b613f2b8178809bf1dcdda02dc_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ODÍLIO BALBINOTTI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ODÍLIO BALBINOTTI|'
mv 189e8086ab8f7e4997b31c8af807c2019c2a58e9.png renomeado/category_2851_189e8086ab8f7e4997b31c8af807c2019c2a58e9.png
convert renomeado/category_2851_189e8086ab8f7e4997b31c8af807c2019c2a58e9.png -resize 16x16 renomeado/category_2851_189e8086ab8f7e4997b31c8af807c2019c2a58e9_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ONOFRE SANTO AGOSTINI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ONOFRE SANTO AGOSTINI|'
mv 650950d2bd519cf11c25be923c932700031f65a0.png renomeado/category_2852_650950d2bd519cf11c25be923c932700031f65a0.png
convert renomeado/category_2852_650950d2bd519cf11c25be923c932700031f65a0.png -resize 16x16 renomeado/category_2852_650950d2bd519cf11c25be923c932700031f65a0_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ONYX LORENZONI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ONYX LORENZONI|'
mv 33ab9eb5262c437e0b09bdb7d43a79cbcc0c6cd1.png renomeado/category_2853_33ab9eb5262c437e0b09bdb7d43a79cbcc0c6cd1.png
convert renomeado/category_2853_33ab9eb5262c437e0b09bdb7d43a79cbcc0c6cd1.png -resize 16x16 renomeado/category_2853_33ab9eb5262c437e0b09bdb7d43a79cbcc0c6cd1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|OSMAR JÚNIOR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|OSMAR JÚNIOR|'
mv cd60429c8636f487c433d20c0c464e5877995f6a.png renomeado/category_2854_cd60429c8636f487c433d20c0c464e5877995f6a.png
convert renomeado/category_2854_cd60429c8636f487c433d20c0c464e5877995f6a.png -resize 16x16 renomeado/category_2854_cd60429c8636f487c433d20c0c464e5877995f6a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|OSMAR SERRAGLIO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|OSMAR SERRAGLIO|'
mv 8fe00eb4082ceb25ca59e45c7a2ef9fc8d110f72.png renomeado/category_2855_8fe00eb4082ceb25ca59e45c7a2ef9fc8d110f72.png
convert renomeado/category_2855_8fe00eb4082ceb25ca59e45c7a2ef9fc8d110f72.png -resize 16x16 renomeado/category_2855_8fe00eb4082ceb25ca59e45c7a2ef9fc8d110f72_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|OSMAR TERRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|OSMAR TERRA|'
mv 5a82979773245ae0a41c04ffbe6f1a851394f91c.png renomeado/category_2856_5a82979773245ae0a41c04ffbe6f1a851394f91c.png
convert renomeado/category_2856_5a82979773245ae0a41c04ffbe6f1a851394f91c.png -resize 16x16 renomeado/category_2856_5a82979773245ae0a41c04ffbe6f1a851394f91c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|OTAVIO LEITE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|OTAVIO LEITE|'
mv 0d953ba030738d6ddc7749a8231ed5a67ef51870.png renomeado/category_2857_0d953ba030738d6ddc7749a8231ed5a67ef51870.png
convert renomeado/category_2857_0d953ba030738d6ddc7749a8231ed5a67ef51870.png -resize 16x16 renomeado/category_2857_0d953ba030738d6ddc7749a8231ed5a67ef51870_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|OTONIEL LIMA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|OTONIEL LIMA|'
mv e119414b5756e454e2aad1f945fed2f2148a5345.png renomeado/category_2858_e119414b5756e454e2aad1f945fed2f2148a5345.png
convert renomeado/category_2858_e119414b5756e454e2aad1f945fed2f2148a5345.png -resize 16x16 renomeado/category_2858_e119414b5756e454e2aad1f945fed2f2148a5345_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|OZIEL OLIVEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|OZIEL OLIVEIRA|'
mv f7533eab38dceda1b9fafd2826fdb5a0cc50911e.png renomeado/category_2859_f7533eab38dceda1b9fafd2826fdb5a0cc50911e.png
convert renomeado/category_2859_f7533eab38dceda1b9fafd2826fdb5a0cc50911e.png -resize 16x16 renomeado/category_2859_f7533eab38dceda1b9fafd2826fdb5a0cc50911e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PADRE JOÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PADRE JOÃO|'
mv 79d771b5a9994d19cb2ecde2aa79836b6c43eba7.png renomeado/category_2860_79d771b5a9994d19cb2ecde2aa79836b6c43eba7.png
convert renomeado/category_2860_79d771b5a9994d19cb2ecde2aa79836b6c43eba7.png -resize 16x16 renomeado/category_2860_79d771b5a9994d19cb2ecde2aa79836b6c43eba7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PADRE TON|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PADRE TON|'
mv d5a89f1d1ce4c0f0eda257a51911d8e7ce79a864.png renomeado/category_2861_d5a89f1d1ce4c0f0eda257a51911d8e7ce79a864.png
convert renomeado/category_2861_d5a89f1d1ce4c0f0eda257a51911d8e7ce79a864.png -resize 16x16 renomeado/category_2861_d5a89f1d1ce4c0f0eda257a51911d8e7ce79a864_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAES LANDIM|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAES LANDIM|'
mv 7371504159b8c18bb9c025c33cfcb2aa82f4bee5.png renomeado/category_2862_7371504159b8c18bb9c025c33cfcb2aa82f4bee5.png
convert renomeado/category_2862_7371504159b8c18bb9c025c33cfcb2aa82f4bee5.png -resize 16x16 renomeado/category_2862_7371504159b8c18bb9c025c33cfcb2aa82f4bee5_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PASTOR EURICO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PASTOR EURICO|'
mv 0ed79e5bb237f58d3c084b3aa8eb5b7be66c0ed7.png renomeado/category_2863_0ed79e5bb237f58d3c084b3aa8eb5b7be66c0ed7.png
convert renomeado/category_2863_0ed79e5bb237f58d3c084b3aa8eb5b7be66c0ed7.png -resize 16x16 renomeado/category_2863_0ed79e5bb237f58d3c084b3aa8eb5b7be66c0ed7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PASTOR MARCO FELICIANO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PASTOR MARCO FELICIANO|'
mv 1a874afc01f95876e56197781b882f732128031e.png renomeado/category_2864_1a874afc01f95876e56197781b882f732128031e.png
convert renomeado/category_2864_1a874afc01f95876e56197781b882f732128031e.png -resize 16x16 renomeado/category_2864_1a874afc01f95876e56197781b882f732128031e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAUDERNEY AVELINO|'

echo 'No XML fotos este é o nome do Deputado Federal:|PAULO ABI-ACKEL|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO ABI-ACKEL|'
mv a3668718d991afd29b738aeaf17eec9da5686c95.png renomeado/category_2866_a3668718d991afd29b738aeaf17eec9da5686c95.png
convert renomeado/category_2866_a3668718d991afd29b738aeaf17eec9da5686c95.png -resize 16x16 renomeado/category_2866_a3668718d991afd29b738aeaf17eec9da5686c95_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAULO CESAR QUARTIERO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO CESAR QUARTIERO|'
mv d20264a6d466115e6897094e2f79140478703b64.png renomeado/category_2867_d20264a6d466115e6897094e2f79140478703b64.png
convert renomeado/category_2867_d20264a6d466115e6897094e2f79140478703b64.png -resize 16x16 renomeado/category_2867_d20264a6d466115e6897094e2f79140478703b64_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAULO FEIJÓ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO FEIJÓ|'
mv 29ef320b8478b0f8f39f06f9b1fc58652c7e9f32.png renomeado/category_2868_29ef320b8478b0f8f39f06f9b1fc58652c7e9f32.png
convert renomeado/category_2868_29ef320b8478b0f8f39f06f9b1fc58652c7e9f32.png -resize 16x16 renomeado/category_2868_29ef320b8478b0f8f39f06f9b1fc58652c7e9f32_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAULO FERREIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO FERREIRA|'
mv 8c23fcfd26d895330ce477172fb4d719d2a02ae7.png renomeado/category_2869_8c23fcfd26d895330ce477172fb4d719d2a02ae7.png
convert renomeado/category_2869_8c23fcfd26d895330ce477172fb4d719d2a02ae7.png -resize 16x16 renomeado/category_2869_8c23fcfd26d895330ce477172fb4d719d2a02ae7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAULO FOLETTO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO FOLETTO|'
mv 8bfcb2558ab5e8280491f65f86c6f86c636a8973.png renomeado/category_2870_8bfcb2558ab5e8280491f65f86c6f86c636a8973.png
convert renomeado/category_2870_8bfcb2558ab5e8280491f65f86c6f86c636a8973.png -resize 16x16 renomeado/category_2870_8bfcb2558ab5e8280491f65f86c6f86c636a8973_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAULO FREIRE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO FREIRE|'
mv 56f82fe9331f0108ff2094b6d9afe9ecd98e1360.png renomeado/category_2871_56f82fe9331f0108ff2094b6d9afe9ecd98e1360.png
convert renomeado/category_2871_56f82fe9331f0108ff2094b6d9afe9ecd98e1360.png -resize 16x16 renomeado/category_2871_56f82fe9331f0108ff2094b6d9afe9ecd98e1360_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAULO MAGALHÃES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO MAGALHÃES|'
mv b7b0bdcf7f65ca717eb98a8d83ca2bd6d667798b.png renomeado/category_2872_b7b0bdcf7f65ca717eb98a8d83ca2bd6d667798b.png
convert renomeado/category_2872_b7b0bdcf7f65ca717eb98a8d83ca2bd6d667798b.png -resize 16x16 renomeado/category_2872_b7b0bdcf7f65ca717eb98a8d83ca2bd6d667798b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAULO MALUF|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO MALUF|'
mv d33b290e2b288532b64acde36d7b130837a2edd6.png renomeado/category_2873_d33b290e2b288532b64acde36d7b130837a2edd6.png
convert renomeado/category_2873_d33b290e2b288532b64acde36d7b130837a2edd6.png -resize 16x16 renomeado/category_2873_d33b290e2b288532b64acde36d7b130837a2edd6_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAULO PEREIRA DA SILVA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO PEREIRA DA SILVA|'
mv 9587c3222913dab46c4521a758ac799d18e53fd4.png renomeado/category_2874_9587c3222913dab46c4521a758ac799d18e53fd4.png
convert renomeado/category_2874_9587c3222913dab46c4521a758ac799d18e53fd4.png -resize 16x16 renomeado/category_2874_9587c3222913dab46c4521a758ac799d18e53fd4_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO PIAU|'

echo 'No XML fotos este é o nome do Deputado Federal:|PAULO PIMENTA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO PIMENTA|'
mv ec5e0941802291670e37285b3d9ab70957336fec.png renomeado/category_2876_ec5e0941802291670e37285b3d9ab70957336fec.png
convert renomeado/category_2876_ec5e0941802291670e37285b3d9ab70957336fec.png -resize 16x16 renomeado/category_2876_ec5e0941802291670e37285b3d9ab70957336fec_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAULO RUBEM SANTIAGO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO RUBEM SANTIAGO|'
mv b846c11b619946ab7555d474e80df124160ab763.png renomeado/category_2877_b846c11b619946ab7555d474e80df124160ab763.png
convert renomeado/category_2877_b846c11b619946ab7555d474e80df124160ab763.png -resize 16x16 renomeado/category_2877_b846c11b619946ab7555d474e80df124160ab763_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAULO TEIXEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO TEIXEIRA|'
mv e252a5024ded92f099ab1923d523bcf8ba80da03.png renomeado/category_2878_e252a5024ded92f099ab1923d523bcf8ba80da03.png
convert renomeado/category_2878_e252a5024ded92f099ab1923d523bcf8ba80da03.png -resize 16x16 renomeado/category_2878_e252a5024ded92f099ab1923d523bcf8ba80da03_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PAULO WAGNER|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PAULO WAGNER|'
mv e398ff56835a8075b1c0909bb0c15e982181384f.png renomeado/category_2879_e398ff56835a8075b1c0909bb0c15e982181384f.png
convert renomeado/category_2879_e398ff56835a8075b1c0909bb0c15e982181384f.png -resize 16x16 renomeado/category_2879_e398ff56835a8075b1c0909bb0c15e982181384f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PEDRO CHAVES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PEDRO CHAVES|'
mv 4379cd62c7e7f0f0d7ee7b5a9dc0802e81666140.png renomeado/category_2880_4379cd62c7e7f0f0d7ee7b5a9dc0802e81666140.png
convert renomeado/category_2880_4379cd62c7e7f0f0d7ee7b5a9dc0802e81666140.png -resize 16x16 renomeado/category_2880_4379cd62c7e7f0f0d7ee7b5a9dc0802e81666140_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PEDRO EUGÊNIO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PEDRO EUGÊNIO|'
mv ac581520c59f1c0bd5a1033ad93c926d3feb0e8a.png renomeado/category_2881_ac581520c59f1c0bd5a1033ad93c926d3feb0e8a.png
convert renomeado/category_2881_ac581520c59f1c0bd5a1033ad93c926d3feb0e8a.png -resize 16x16 renomeado/category_2881_ac581520c59f1c0bd5a1033ad93c926d3feb0e8a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PEDRO HENRY|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PEDRO HENRY|'
mv 2968af0b6317ab3217ca3484d83a4f34418f158c.png renomeado/category_2882_2968af0b6317ab3217ca3484d83a4f34418f158c.png
convert renomeado/category_2882_2968af0b6317ab3217ca3484d83a4f34418f158c.png -resize 16x16 renomeado/category_2882_2968af0b6317ab3217ca3484d83a4f34418f158c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PEDRO NOVAIS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PEDRO NOVAIS|'
mv fd0ac0f6a61f63e8f50789d3b6d16417d90c30b1.png renomeado/category_2883_fd0ac0f6a61f63e8f50789d3b6d16417d90c30b1.png
convert renomeado/category_2883_fd0ac0f6a61f63e8f50789d3b6d16417d90c30b1.png -resize 16x16 renomeado/category_2883_fd0ac0f6a61f63e8f50789d3b6d16417d90c30b1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PEDRO UCZAI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PEDRO UCZAI|'
mv 2dd69c892e302af6100777fc8716c0113b798044.png renomeado/category_2884_2dd69c892e302af6100777fc8716c0113b798044.png
convert renomeado/category_2884_2dd69c892e302af6100777fc8716c0113b798044.png -resize 16x16 renomeado/category_2884_2dd69c892e302af6100777fc8716c0113b798044_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PENNA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PENNA|'
mv 2c78bc44d5990d6cc48c4f8b7c1bd0c136493d26.png renomeado/category_2885_2c78bc44d5990d6cc48c4f8b7c1bd0c136493d26.png
convert renomeado/category_2885_2c78bc44d5990d6cc48c4f8b7c1bd0c136493d26.png -resize 16x16 renomeado/category_2885_2c78bc44d5990d6cc48c4f8b7c1bd0c136493d26_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PERPÉTUA ALMEIDA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PERPÉTUA ALMEIDA|'
mv 2e07e3364241164059ebe0d8bbf09feace44795e.png renomeado/category_2886_2e07e3364241164059ebe0d8bbf09feace44795e.png
convert renomeado/category_2886_2e07e3364241164059ebe0d8bbf09feace44795e.png -resize 16x16 renomeado/category_2886_2e07e3364241164059ebe0d8bbf09feace44795e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PINTO ITAMARATY|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PINTO ITAMARATY|'
mv 107a1eb5301c0a7fe09744c01e7dd6760e1190c1.png renomeado/category_2887_107a1eb5301c0a7fe09744c01e7dd6760e1190c1.png
convert renomeado/category_2887_107a1eb5301c0a7fe09744c01e7dd6760e1190c1.png -resize 16x16 renomeado/category_2887_107a1eb5301c0a7fe09744c01e7dd6760e1190c1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|POLICARPO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|POLICARPO|'
mv 70ef0390f6b6ee42387b0b753f778dd8e471a124.png renomeado/category_2888_70ef0390f6b6ee42387b0b753f778dd8e471a124.png
convert renomeado/category_2888_70ef0390f6b6ee42387b0b753f778dd8e471a124.png -resize 16x16 renomeado/category_2888_70ef0390f6b6ee42387b0b753f778dd8e471a124_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PROFESSOR SETIMO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PROFESSOR SETIMO|'
mv 307f84454ab77c0a4498fdbbe5d7578cf1310b7e.png renomeado/category_2889_307f84454ab77c0a4498fdbbe5d7578cf1310b7e.png
convert renomeado/category_2889_307f84454ab77c0a4498fdbbe5d7578cf1310b7e.png -resize 16x16 renomeado/category_2889_307f84454ab77c0a4498fdbbe5d7578cf1310b7e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PROFESSOR SÉRGIO DE OLIVEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PROFESSOR SÉRGIO DE OLIVEIRA|'
mv ce7b176d1114299fcad629809ea125667f993a81.png renomeado/category_2890_ce7b176d1114299fcad629809ea125667f993a81.png
convert renomeado/category_2890_ce7b176d1114299fcad629809ea125667f993a81.png -resize 16x16 renomeado/category_2890_ce7b176d1114299fcad629809ea125667f993a81_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|PROFESSORA DORINHA SEABRA REZENDE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|PROFESSORA DORINHA SEABRA REZENDE|'
mv ecda6de11a2a1b96d85775f110d119697eb7c50b.png renomeado/category_2891_ecda6de11a2a1b96d85775f110d119697eb7c50b.png
convert renomeado/category_2891_ecda6de11a2a1b96d85775f110d119697eb7c50b.png -resize 16x16 renomeado/category_2891_ecda6de11a2a1b96d85775f110d119697eb7c50b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RAIMUNDO GOMES DE MATOS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RAIMUNDO GOMES DE MATOS|'
mv 0de500807b10b3bd4b1f579d422562ee51d82ce7.png renomeado/category_2892_0de500807b10b3bd4b1f579d422562ee51d82ce7.png
convert renomeado/category_2892_0de500807b10b3bd4b1f579d422562ee51d82ce7.png -resize 16x16 renomeado/category_2892_0de500807b10b3bd4b1f579d422562ee51d82ce7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RAIMUNDÃO|'

echo 'No XML fotos este é o nome do Deputado Federal:|RAUL HENRY|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RAUL HENRY|'
mv 643f6fed47e91b1233f89c5c17a0d44044011197.png renomeado/category_2894_643f6fed47e91b1233f89c5c17a0d44044011197.png
convert renomeado/category_2894_643f6fed47e91b1233f89c5c17a0d44044011197.png -resize 16x16 renomeado/category_2894_643f6fed47e91b1233f89c5c17a0d44044011197_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RAUL LIMA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RAUL LIMA|'
mv ffe50623630750981b5b382887072b211c7c4e85.png renomeado/category_2895_ffe50623630750981b5b382887072b211c7c4e85.png
convert renomeado/category_2895_ffe50623630750981b5b382887072b211c7c4e85.png -resize 16x16 renomeado/category_2895_ffe50623630750981b5b382887072b211c7c4e85_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|REBECCA GARCIA|'

echo 'No XML fotos este é o nome do Deputado Federal:|REGINALDO LOPES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|REGINALDO LOPES|'
mv 47340ba7519b9689531f573326267f372fe6dd3e.png renomeado/category_2897_47340ba7519b9689531f573326267f372fe6dd3e.png
convert renomeado/category_2897_47340ba7519b9689531f573326267f372fe6dd3e.png -resize 16x16 renomeado/category_2897_47340ba7519b9689531f573326267f372fe6dd3e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|REGUFFE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|REGUFFE|'
mv 7b1410600d158248f8be2c6661fe410dd390384d.png renomeado/category_2898_7b1410600d158248f8be2c6661fe410dd390384d.png
convert renomeado/category_2898_7b1410600d158248f8be2c6661fe410dd390384d.png -resize 16x16 renomeado/category_2898_7b1410600d158248f8be2c6661fe410dd390384d_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|REINALDO AZAMBUJA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|REINALDO AZAMBUJA|'
mv da3c448a181dfffa201bf8a22a931f19c89edc7a.png renomeado/category_2899_da3c448a181dfffa201bf8a22a931f19c89edc7a.png
convert renomeado/category_2899_da3c448a181dfffa201bf8a22a931f19c89edc7a.png -resize 16x16 renomeado/category_2899_da3c448a181dfffa201bf8a22a931f19c89edc7a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|REINHOLD STEPHANES|'

echo 'No XML fotos este é o nome do Deputado Federal:|RENAN FILHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RENAN FILHO|'
mv d16e9dd12c02e65213511b5ab181ed3ef810307c.png renomeado/category_2901_d16e9dd12c02e65213511b5ab181ed3ef810307c.png
convert renomeado/category_2901_d16e9dd12c02e65213511b5ab181ed3ef810307c.png -resize 16x16 renomeado/category_2901_d16e9dd12c02e65213511b5ab181ed3ef810307c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RENATO MOLLING|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RENATO MOLLING|'
mv ea077666d86de8d2fcb9e073eeb040ca0a0e968e.png renomeado/category_2902_ea077666d86de8d2fcb9e073eeb040ca0a0e968e.png
convert renomeado/category_2902_ea077666d86de8d2fcb9e073eeb040ca0a0e968e.png -resize 16x16 renomeado/category_2902_ea077666d86de8d2fcb9e073eeb040ca0a0e968e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RENZO BRAZ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RENZO BRAZ|'
mv 7777241d577a733f7803ddaa1f6abe520f69fc45.png renomeado/category_2903_7777241d577a733f7803ddaa1f6abe520f69fc45.png
convert renomeado/category_2903_7777241d577a733f7803ddaa1f6abe520f69fc45.png -resize 16x16 renomeado/category_2903_7777241d577a733f7803ddaa1f6abe520f69fc45_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RIBAMAR ALVES|'

echo 'No XML fotos este é o nome do Deputado Federal:|RICARDO BERZOINI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RICARDO BERZOINI|'
mv 2a5d669ebd59e2ecbc9428cd4bbd2a8717d570dd.png renomeado/category_2905_2a5d669ebd59e2ecbc9428cd4bbd2a8717d570dd.png
convert renomeado/category_2905_2a5d669ebd59e2ecbc9428cd4bbd2a8717d570dd.png -resize 16x16 renomeado/category_2905_2a5d669ebd59e2ecbc9428cd4bbd2a8717d570dd_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RICARDO IZAR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RICARDO IZAR|'
mv ae0e7ecf5d245b25da3b355ff09432ca7383faa0.png renomeado/category_2906_ae0e7ecf5d245b25da3b355ff09432ca7383faa0.png
convert renomeado/category_2906_ae0e7ecf5d245b25da3b355ff09432ca7383faa0.png -resize 16x16 renomeado/category_2906_ae0e7ecf5d245b25da3b355ff09432ca7383faa0_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RICARDO TRIPOLI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RICARDO TRIPOLI|'
mv a6733ce05049b762f88b4ea9b99bb271c6f61ea6.png renomeado/category_2907_a6733ce05049b762f88b4ea9b99bb271c6f61ea6.png
convert renomeado/category_2907_a6733ce05049b762f88b4ea9b99bb271c6f61ea6.png -resize 16x16 renomeado/category_2907_a6733ce05049b762f88b4ea9b99bb271c6f61ea6_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ROBERTO BALESTRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROBERTO BALESTRA|'
mv 29fffab35973bd5f4d3ba327c0c0650f165a771d.png renomeado/category_2908_29fffab35973bd5f4d3ba327c0c0650f165a771d.png
convert renomeado/category_2908_29fffab35973bd5f4d3ba327c0c0650f165a771d.png -resize 16x16 renomeado/category_2908_29fffab35973bd5f4d3ba327c0c0650f165a771d_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ROBERTO BRITTO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROBERTO BRITTO|'
mv b086d3ae8ca0523490e1d5c8c9c62ff31480d193.png renomeado/category_2909_b086d3ae8ca0523490e1d5c8c9c62ff31480d193.png
convert renomeado/category_2909_b086d3ae8ca0523490e1d5c8c9c62ff31480d193.png -resize 16x16 renomeado/category_2909_b086d3ae8ca0523490e1d5c8c9c62ff31480d193_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ROBERTO DE LUCENA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROBERTO DE LUCENA|'
mv 69d9d14fbf4051cc3e8985a0d948c8db6dbbd548.png renomeado/category_2910_69d9d14fbf4051cc3e8985a0d948c8db6dbbd548.png
convert renomeado/category_2910_69d9d14fbf4051cc3e8985a0d948c8db6dbbd548.png -resize 16x16 renomeado/category_2910_69d9d14fbf4051cc3e8985a0d948c8db6dbbd548_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ROBERTO FREIRE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROBERTO FREIRE|'
mv 228fd27978139982d5f4d0421b3102c41ebef3b0.png renomeado/category_2911_228fd27978139982d5f4d0421b3102c41ebef3b0.png
convert renomeado/category_2911_228fd27978139982d5f4d0421b3102c41ebef3b0.png -resize 16x16 renomeado/category_2911_228fd27978139982d5f4d0421b3102c41ebef3b0_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ROBERTO SANTIAGO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROBERTO SANTIAGO|'
mv d82b85a355378ee7324f215113991c7b5abf06ff.png renomeado/category_2912_d82b85a355378ee7324f215113991c7b5abf06ff.png
convert renomeado/category_2912_d82b85a355378ee7324f215113991c7b5abf06ff.png -resize 16x16 renomeado/category_2912_d82b85a355378ee7324f215113991c7b5abf06ff_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ROBERTO TEIXEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROBERTO TEIXEIRA|'
mv 38a900a4384865883ab55077a73844289dc13ddd.png renomeado/category_2913_38a900a4384865883ab55077a73844289dc13ddd.png
convert renomeado/category_2913_38a900a4384865883ab55077a73844289dc13ddd.png -resize 16x16 renomeado/category_2913_38a900a4384865883ab55077a73844289dc13ddd_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RODRIGO BETHLEM|'

echo 'No XML fotos este é o nome do Deputado Federal:|RODRIGO DE CASTRO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RODRIGO DE CASTRO|'
mv b773e874819d4e0e92f29e34300da14501052783.png renomeado/category_2915_b773e874819d4e0e92f29e34300da14501052783.png
convert renomeado/category_2915_b773e874819d4e0e92f29e34300da14501052783.png -resize 16x16 renomeado/category_2915_b773e874819d4e0e92f29e34300da14501052783_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RODRIGO MAIA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RODRIGO MAIA|'
mv b726781b3925d33e4f66837789c238ad580d4417.png renomeado/category_2916_b726781b3925d33e4f66837789c238ad580d4417.png
convert renomeado/category_2916_b726781b3925d33e4f66837789c238ad580d4417.png -resize 16x16 renomeado/category_2916_b726781b3925d33e4f66837789c238ad580d4417_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ROGÉRIO CARVALHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROGÉRIO CARVALHO|'
mv 00d386ff3837804ba4014b42b11a7ccb8f0bc97b.png renomeado/category_2917_00d386ff3837804ba4014b42b11a7ccb8f0bc97b.png
convert renomeado/category_2917_00d386ff3837804ba4014b42b11a7ccb8f0bc97b.png -resize 16x16 renomeado/category_2917_00d386ff3837804ba4014b42b11a7ccb8f0bc97b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ROGÉRIO PENINHA MENDONÇA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROGÉRIO PENINHA MENDONÇA|'
mv 03866ce6855aa6698dff8b41c277c0abc943aff3.png renomeado/category_2918_03866ce6855aa6698dff8b41c277c0abc943aff3.png
convert renomeado/category_2918_03866ce6855aa6698dff8b41c277c0abc943aff3.png -resize 16x16 renomeado/category_2918_03866ce6855aa6698dff8b41c277c0abc943aff3_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROMERO RODRIGUES|'

echo 'No XML fotos este é o nome do Deputado Federal:|ROMÁRIO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROMÁRIO|'
mv 7a82172f6097e3ccbc5eadce5538c5a870954fb2.png renomeado/category_2920_7a82172f6097e3ccbc5eadce5538c5a870954fb2.png
convert renomeado/category_2920_7a82172f6097e3ccbc5eadce5538c5a870954fb2.png -resize 16x16 renomeado/category_2920_7a82172f6097e3ccbc5eadce5538c5a870954fb2_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RONALDO BENEDET|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RONALDO BENEDET|'
mv ceb1c39136efe2ee806a8bbefad0b6909250d1eb.png renomeado/category_2921_ceb1c39136efe2ee806a8bbefad0b6909250d1eb.png
convert renomeado/category_2921_ceb1c39136efe2ee806a8bbefad0b6909250d1eb.png -resize 16x16 renomeado/category_2921_ceb1c39136efe2ee806a8bbefad0b6909250d1eb_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RONALDO CAIADO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RONALDO CAIADO|'
mv 2c28fa8ecc6d9dd6d43a56372a0b35bb154cf150.png renomeado/category_2922_2c28fa8ecc6d9dd6d43a56372a0b35bb154cf150.png
convert renomeado/category_2922_2c28fa8ecc6d9dd6d43a56372a0b35bb154cf150.png -resize 16x16 renomeado/category_2922_2c28fa8ecc6d9dd6d43a56372a0b35bb154cf150_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RONALDO FONSECA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RONALDO FONSECA|'
mv f2d6122a29fcf6cbd842fc04c7213e1377fc0363.png renomeado/category_2923_f2d6122a29fcf6cbd842fc04c7213e1377fc0363.png
convert renomeado/category_2923_f2d6122a29fcf6cbd842fc04c7213e1377fc0363.png -resize 16x16 renomeado/category_2923_f2d6122a29fcf6cbd842fc04c7213e1377fc0363_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RONALDO NOGUEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RONALDO NOGUEIRA|'
mv f47000a806b563698520f39dbe1181574299ddc1.png renomeado/category_2924_f47000a806b563698520f39dbe1181574299ddc1.png
convert renomeado/category_2924_f47000a806b563698520f39dbe1181574299ddc1.png -resize 16x16 renomeado/category_2924_f47000a806b563698520f39dbe1181574299ddc1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RONALDO ZULKE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RONALDO ZULKE|'
mv e433e7c20a26ee8759592ca47d8f77d762c21a3f.png renomeado/category_2925_e433e7c20a26ee8759592ca47d8f77d762c21a3f.png
convert renomeado/category_2925_e433e7c20a26ee8759592ca47d8f77d762c21a3f.png -resize 16x16 renomeado/category_2925_e433e7c20a26ee8759592ca47d8f77d762c21a3f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ROSANE FERREIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROSANE FERREIRA|'
mv 7d8cc8bc7570d222682b6a63833cfaf10553c711.png renomeado/category_2926_7d8cc8bc7570d222682b6a63833cfaf10553c711.png
convert renomeado/category_2926_7d8cc8bc7570d222682b6a63833cfaf10553c711.png -resize 16x16 renomeado/category_2926_7d8cc8bc7570d222682b6a63833cfaf10553c711_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ROSE DE FREITAS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROSE DE FREITAS|'
mv 27a2a920fae39f703adac56cd6ceb5a7c0b37b08.png renomeado/category_2927_27a2a920fae39f703adac56cd6ceb5a7c0b37b08.png
convert renomeado/category_2927_27a2a920fae39f703adac56cd6ceb5a7c0b37b08.png -resize 16x16 renomeado/category_2927_27a2a920fae39f703adac56cd6ceb5a7c0b37b08_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ROSINHA DA ADEFAL|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ROSINHA DA ADEFAL|'
mv 4446302e24620020482e49caab3f5041977189e5.png renomeado/category_2928_4446302e24620020482e49caab3f5041977189e5.png
convert renomeado/category_2928_4446302e24620020482e49caab3f5041977189e5.png -resize 16x16 renomeado/category_2928_4446302e24620020482e49caab3f5041977189e5_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RUBENS BUENO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RUBENS BUENO|'
mv f301c519f06a8c4fd2822d32cfceda04653ac0da.png renomeado/category_2929_f301c519f06a8c4fd2822d32cfceda04653ac0da.png
convert renomeado/category_2929_f301c519f06a8c4fd2822d32cfceda04653ac0da.png -resize 16x16 renomeado/category_2929_f301c519f06a8c4fd2822d32cfceda04653ac0da_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|RUBENS OTONI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RUBENS OTONI|'
mv de231e2e4e6b509a31936ea8a9131ce946c383dd.png renomeado/category_2930_de231e2e4e6b509a31936ea8a9131ce946c383dd.png
convert renomeado/category_2930_de231e2e4e6b509a31936ea8a9131ce946c383dd.png -resize 16x16 renomeado/category_2930_de231e2e4e6b509a31936ea8a9131ce946c383dd_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RUI PALMEIRA|'

echo 'No XML fotos este é o nome do Deputado Federal:|RUY CARNEIRO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|RUY CARNEIRO|'
mv dbf8ca31247a4a9e2e6cc871ffe76126d6277e7a.png renomeado/category_2932_dbf8ca31247a4a9e2e6cc871ffe76126d6277e7a.png
convert renomeado/category_2932_dbf8ca31247a4a9e2e6cc871ffe76126d6277e7a.png -resize 16x16 renomeado/category_2932_dbf8ca31247a4a9e2e6cc871ffe76126d6277e7a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SABINO CASTELO BRANCO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SABINO CASTELO BRANCO|'
mv e1454b5ea670b69b2ad9dc66dfd9ec9bbd035ece.png renomeado/category_2933_e1454b5ea670b69b2ad9dc66dfd9ec9bbd035ece.png
convert renomeado/category_2933_e1454b5ea670b69b2ad9dc66dfd9ec9bbd035ece.png -resize 16x16 renomeado/category_2933_e1454b5ea670b69b2ad9dc66dfd9ec9bbd035ece_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SALVADOR ZIMBALDI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SALVADOR ZIMBALDI|'
mv d613dc1d05760f55c9204a5d1d56eef95882287b.png renomeado/category_2934_d613dc1d05760f55c9204a5d1d56eef95882287b.png
convert renomeado/category_2934_d613dc1d05760f55c9204a5d1d56eef95882287b.png -resize 16x16 renomeado/category_2934_d613dc1d05760f55c9204a5d1d56eef95882287b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SANDES JÚNIOR|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SANDES JÚNIOR|'
mv 1724d78a66a89c4eed0aca363a4b769f3a2e89f1.png renomeado/category_2935_1724d78a66a89c4eed0aca363a4b769f3a2e89f1.png
convert renomeado/category_2935_1724d78a66a89c4eed0aca363a4b769f3a2e89f1.png -resize 16x16 renomeado/category_2935_1724d78a66a89c4eed0aca363a4b769f3a2e89f1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SANDRA ROSADO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SANDRA ROSADO|'
mv ee30f889becf8795c9ebedafba91e662d8ab8107.png renomeado/category_2936_ee30f889becf8795c9ebedafba91e662d8ab8107.png
convert renomeado/category_2936_ee30f889becf8795c9ebedafba91e662d8ab8107.png -resize 16x16 renomeado/category_2936_ee30f889becf8795c9ebedafba91e662d8ab8107_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SANDRO ALEX|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SANDRO ALEX|'
mv a177f0c0214c1224e36c02ca5bde90e0b49aef7e.png renomeado/category_2937_a177f0c0214c1224e36c02ca5bde90e0b49aef7e.png
convert renomeado/category_2937_a177f0c0214c1224e36c02ca5bde90e0b49aef7e.png -resize 16x16 renomeado/category_2937_a177f0c0214c1224e36c02ca5bde90e0b49aef7e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SANDRO MABEL|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SANDRO MABEL|'
mv 615ed51c7b2edb04682c99369cda69fff50a164e.png renomeado/category_2938_615ed51c7b2edb04682c99369cda69fff50a164e.png
convert renomeado/category_2938_615ed51c7b2edb04682c99369cda69fff50a164e.png -resize 16x16 renomeado/category_2938_615ed51c7b2edb04682c99369cda69fff50a164e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SARAIVA FELIPE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SARAIVA FELIPE|'
mv 2c8044b8ab82820366d0060e718ff872726e9459.png renomeado/category_2939_2c8044b8ab82820366d0060e718ff872726e9459.png
convert renomeado/category_2939_2c8044b8ab82820366d0060e718ff872726e9459.png -resize 16x16 renomeado/category_2939_2c8044b8ab82820366d0060e718ff872726e9459_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SARNEY FILHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SARNEY FILHO|'
mv 1df46035fac520ff88ba94673e4eab78a5d7190b.png renomeado/category_2940_1df46035fac520ff88ba94673e4eab78a5d7190b.png
convert renomeado/category_2940_1df46035fac520ff88ba94673e4eab78a5d7190b.png -resize 16x16 renomeado/category_2940_1df46035fac520ff88ba94673e4eab78a5d7190b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SEBASTIÃO BALA ROCHA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SEBASTIÃO BALA ROCHA|'
mv 83c8b9b24e395fba77e6d8b6355e791446176059.png renomeado/category_2941_83c8b9b24e395fba77e6d8b6355e791446176059.png
convert renomeado/category_2941_83c8b9b24e395fba77e6d8b6355e791446176059.png -resize 16x16 renomeado/category_2941_83c8b9b24e395fba77e6d8b6355e791446176059_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SERGIO GUERRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SERGIO GUERRA|'
mv d5577d6259bc20e708535478338c6e39d01b41a1.png renomeado/category_2942_d5577d6259bc20e708535478338c6e39d01b41a1.png
convert renomeado/category_2942_d5577d6259bc20e708535478338c6e39d01b41a1.png -resize 16x16 renomeado/category_2942_d5577d6259bc20e708535478338c6e39d01b41a1_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SEVERINO NINHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SEVERINO NINHO|'
mv 85ca645ae001d42d9b4975289302140540824c6c.png renomeado/category_2943_85ca645ae001d42d9b4975289302140540824c6c.png
convert renomeado/category_2943_85ca645ae001d42d9b4975289302140540824c6c.png -resize 16x16 renomeado/category_2943_85ca645ae001d42d9b4975289302140540824c6c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SIBÁ MACHADO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SIBÁ MACHADO|'
mv 906a30d3e49b26efca588d6ed07bcd0c67f5895b.png renomeado/category_2944_906a30d3e49b26efca588d6ed07bcd0c67f5895b.png
convert renomeado/category_2944_906a30d3e49b26efca588d6ed07bcd0c67f5895b.png -resize 16x16 renomeado/category_2944_906a30d3e49b26efca588d6ed07bcd0c67f5895b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SILAS CÂMARA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SILAS CÂMARA|'
mv 5fcf800129de7bd6624c5b8f929b4c39a086752f.png renomeado/category_2945_5fcf800129de7bd6624c5b8f929b4c39a086752f.png
convert renomeado/category_2945_5fcf800129de7bd6624c5b8f929b4c39a086752f.png -resize 16x16 renomeado/category_2945_5fcf800129de7bd6624c5b8f929b4c39a086752f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SILVIO COSTA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SILVIO COSTA|'
mv 664414a6818a963a5fd5572c36d95a950c3c86ca.png renomeado/category_2946_664414a6818a963a5fd5572c36d95a950c3c86ca.png
convert renomeado/category_2946_664414a6818a963a5fd5572c36d95a950c3c86ca.png -resize 16x16 renomeado/category_2946_664414a6818a963a5fd5572c36d95a950c3c86ca_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SIMÃO SESSIM|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SIMÃO SESSIM|'
mv dd52b94b68c99f90fe511a230914e3d14b2d5eb4.png renomeado/category_2947_dd52b94b68c99f90fe511a230914e3d14b2d5eb4.png
convert renomeado/category_2947_dd52b94b68c99f90fe511a230914e3d14b2d5eb4.png -resize 16x16 renomeado/category_2947_dd52b94b68c99f90fe511a230914e3d14b2d5eb4_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|STEPAN NERCESSIAN|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|STEPAN NERCESSIAN|'
mv 191b24584c0511afa1c93ab006f304b998433e7c.png renomeado/category_2948_191b24584c0511afa1c93ab006f304b998433e7c.png
convert renomeado/category_2948_191b24584c0511afa1c93ab006f304b998433e7c.png -resize 16x16 renomeado/category_2948_191b24584c0511afa1c93ab006f304b998433e7c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SUELI VIDIGAL|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SUELI VIDIGAL|'
mv c463976c639110f6cf397b562c8f5d16dfa8a227.png renomeado/category_2949_c463976c639110f6cf397b562c8f5d16dfa8a227.png
convert renomeado/category_2949_c463976c639110f6cf397b562c8f5d16dfa8a227.png -resize 16x16 renomeado/category_2949_c463976c639110f6cf397b562c8f5d16dfa8a227_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SÉRGIO BRITO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SÉRGIO BRITO|'
mv f7f649c8fe3f3e5a066dc3029f970d83d6656248.png renomeado/category_2950_f7f649c8fe3f3e5a066dc3029f970d83d6656248.png
convert renomeado/category_2950_f7f649c8fe3f3e5a066dc3029f970d83d6656248.png -resize 16x16 renomeado/category_2950_f7f649c8fe3f3e5a066dc3029f970d83d6656248_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|SÉRGIO MORAES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SÉRGIO MORAES|'
mv 6eaf17594e6697e2f7f2c262fc23e28f5fae5a4b.png renomeado/category_2951_6eaf17594e6697e2f7f2c262fc23e28f5fae5a4b.png
convert renomeado/category_2951_6eaf17594e6697e2f7f2c262fc23e28f5fae5a4b.png -resize 16x16 renomeado/category_2951_6eaf17594e6697e2f7f2c262fc23e28f5fae5a4b_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|SÉRGIO ZVEITER|'

echo 'No XML fotos este é o nome do Deputado Federal:|TAKAYAMA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|TAKAYAMA|'
mv 75eb20694d0721ec8a35c03a9963fbe35a3c6b4c.png renomeado/category_2953_75eb20694d0721ec8a35c03a9963fbe35a3c6b4c.png
convert renomeado/category_2953_75eb20694d0721ec8a35c03a9963fbe35a3c6b4c.png -resize 16x16 renomeado/category_2953_75eb20694d0721ec8a35c03a9963fbe35a3c6b4c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|TAUMATURGO LIMA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|TAUMATURGO LIMA|'
mv c15b4077b3bd837c0c8d15c47fa46a4a6d7678cc.png renomeado/category_2954_c15b4077b3bd837c0c8d15c47fa46a4a6d7678cc.png
convert renomeado/category_2954_c15b4077b3bd837c0c8d15c47fa46a4a6d7678cc.png -resize 16x16 renomeado/category_2954_c15b4077b3bd837c0c8d15c47fa46a4a6d7678cc_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|TERESA SURITA|'

echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|THIAGO PEIXOTO|'

echo 'No XML fotos este é o nome do Deputado Federal:|TIRIRICA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|TIRIRICA|'
mv 9fa70ab7261687c9c5ccfe39df7b70396a8c08d7.png renomeado/category_2957_9fa70ab7261687c9c5ccfe39df7b70396a8c08d7.png
convert renomeado/category_2957_9fa70ab7261687c9c5ccfe39df7b70396a8c08d7.png -resize 16x16 renomeado/category_2957_9fa70ab7261687c9c5ccfe39df7b70396a8c08d7_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|TONINHO PINHEIRO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|TONINHO PINHEIRO|'
mv c5b929a8fab5cd12e23578becce00b59fdec5213.png renomeado/category_2958_c5b929a8fab5cd12e23578becce00b59fdec5213.png
convert renomeado/category_2958_c5b929a8fab5cd12e23578becce00b59fdec5213.png -resize 16x16 renomeado/category_2958_c5b929a8fab5cd12e23578becce00b59fdec5213_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VALADARES FILHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VALADARES FILHO|'
mv 37f459fe3205f27960111deecadb5917424084fa.png renomeado/category_2959_37f459fe3205f27960111deecadb5917424084fa.png
convert renomeado/category_2959_37f459fe3205f27960111deecadb5917424084fa.png -resize 16x16 renomeado/category_2959_37f459fe3205f27960111deecadb5917424084fa_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VALDEMAR COSTA NETO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VALDEMAR COSTA NETO|'
mv df3ab6860da8d05a0c08b91fcc09135ad64964d0.png renomeado/category_2960_df3ab6860da8d05a0c08b91fcc09135ad64964d0.png
convert renomeado/category_2960_df3ab6860da8d05a0c08b91fcc09135ad64964d0.png -resize 16x16 renomeado/category_2960_df3ab6860da8d05a0c08b91fcc09135ad64964d0_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VALDIR COLATTO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VALDIR COLATTO|'
mv 25296f3582bbfcbab380640896df42d0638ee80c.png renomeado/category_2961_25296f3582bbfcbab380640896df42d0638ee80c.png
convert renomeado/category_2961_25296f3582bbfcbab380640896df42d0638ee80c.png -resize 16x16 renomeado/category_2961_25296f3582bbfcbab380640896df42d0638ee80c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VALMIR ASSUNÇÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VALMIR ASSUNÇÃO|'
mv 7717f4a4391e9034e8a110a5ae4fcf1024040917.png renomeado/category_2962_7717f4a4391e9034e8a110a5ae4fcf1024040917.png
convert renomeado/category_2962_7717f4a4391e9034e8a110a5ae4fcf1024040917.png -resize 16x16 renomeado/category_2962_7717f4a4391e9034e8a110a5ae4fcf1024040917_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VALTENIR PEREIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VALTENIR PEREIRA|'
mv eaec0511a567328ee5f1cc7bf537c555b391e1cf.png renomeado/category_2963_eaec0511a567328ee5f1cc7bf537c555b391e1cf.png
convert renomeado/category_2963_eaec0511a567328ee5f1cc7bf537c555b391e1cf.png -resize 16x16 renomeado/category_2963_eaec0511a567328ee5f1cc7bf537c555b391e1cf_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VANDER LOUBET|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VANDER LOUBET|'
mv cd19a0677cb746f4148da68255c9eb16477024aa.png renomeado/category_2964_cd19a0677cb746f4148da68255c9eb16477024aa.png
convert renomeado/category_2964_cd19a0677cb746f4148da68255c9eb16477024aa.png -resize 16x16 renomeado/category_2964_cd19a0677cb746f4148da68255c9eb16477024aa_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VANDERLEI MACRIS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VANDERLEI MACRIS|'
mv 714b5423474209ce6e0a096628e12ee4cf887e7e.png renomeado/category_2965_714b5423474209ce6e0a096628e12ee4cf887e7e.png
convert renomeado/category_2965_714b5423474209ce6e0a096628e12ee4cf887e7e.png -resize 16x16 renomeado/category_2965_714b5423474209ce6e0a096628e12ee4cf887e7e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VANDERLEI SIRAQUE|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VANDERLEI SIRAQUE|'
mv d4c24a2209c3a6a03f239b463cb6b1ec42ead37e.png renomeado/category_2966_d4c24a2209c3a6a03f239b463cb6b1ec42ead37e.png
convert renomeado/category_2966_d4c24a2209c3a6a03f239b463cb6b1ec42ead37e.png -resize 16x16 renomeado/category_2966_d4c24a2209c3a6a03f239b463cb6b1ec42ead37e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VAZ DE LIMA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VAZ DE LIMA|'
mv fe67b7e60c0584c16c6bbc2fcde76c64559bc609.png renomeado/category_2967_fe67b7e60c0584c16c6bbc2fcde76c64559bc609.png
convert renomeado/category_2967_fe67b7e60c0584c16c6bbc2fcde76c64559bc609.png -resize 16x16 renomeado/category_2967_fe67b7e60c0584c16c6bbc2fcde76c64559bc609_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VICENTE ARRUDA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VICENTE ARRUDA|'
mv 49251a3516567e657726b47048394f0ad3ae7221.png renomeado/category_2968_49251a3516567e657726b47048394f0ad3ae7221.png
convert renomeado/category_2968_49251a3516567e657726b47048394f0ad3ae7221.png -resize 16x16 renomeado/category_2968_49251a3516567e657726b47048394f0ad3ae7221_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VICENTE CANDIDO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VICENTE CANDIDO|'
mv bb6cbce56bd1a85fe2f280e87b0b6d40327b037c.png renomeado/category_2969_bb6cbce56bd1a85fe2f280e87b0b6d40327b037c.png
convert renomeado/category_2969_bb6cbce56bd1a85fe2f280e87b0b6d40327b037c.png -resize 16x16 renomeado/category_2969_bb6cbce56bd1a85fe2f280e87b0b6d40327b037c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VICENTINHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VICENTINHO|'
mv c661f1d54e1f38308977610653663b8f2f0513e4.png renomeado/category_2970_c661f1d54e1f38308977610653663b8f2f0513e4.png
convert renomeado/category_2970_c661f1d54e1f38308977610653663b8f2f0513e4.png -resize 16x16 renomeado/category_2970_c661f1d54e1f38308977610653663b8f2f0513e4_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VIEIRA DA CUNHA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VIEIRA DA CUNHA|'
mv ef851c1a396f4062cf33144fdafce00db125a279.png renomeado/category_2971_ef851c1a396f4062cf33144fdafce00db125a279.png
convert renomeado/category_2971_ef851c1a396f4062cf33144fdafce00db125a279.png -resize 16x16 renomeado/category_2971_ef851c1a396f4062cf33144fdafce00db125a279_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VILALBA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VILALBA|'
mv 2d84c4dbc1e16f44582dbc71208f6f52d9a9118d.png renomeado/category_2972_2d84c4dbc1e16f44582dbc71208f6f52d9a9118d.png
convert renomeado/category_2972_2d84c4dbc1e16f44582dbc71208f6f52d9a9118d.png -resize 16x16 renomeado/category_2972_2d84c4dbc1e16f44582dbc71208f6f52d9a9118d_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VILMAR ROCHA|'

echo 'No XML fotos este é o nome do Deputado Federal:|VILSON COVATTI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VILSON COVATTI|'
mv 0129ff3e33f4d10f48d9f90a0af9b56847e0e7b4.png renomeado/category_2974_0129ff3e33f4d10f48d9f90a0af9b56847e0e7b4.png
convert renomeado/category_2974_0129ff3e33f4d10f48d9f90a0af9b56847e0e7b4.png -resize 16x16 renomeado/category_2974_0129ff3e33f4d10f48d9f90a0af9b56847e0e7b4_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VINICIUS GURGEL|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VINICIUS GURGEL|'
mv 5a1d46e70d8fba83262b638248c04ab6e4085cbf.png renomeado/category_2975_5a1d46e70d8fba83262b638248c04ab6e4085cbf.png
convert renomeado/category_2975_5a1d46e70d8fba83262b638248c04ab6e4085cbf.png -resize 16x16 renomeado/category_2975_5a1d46e70d8fba83262b638248c04ab6e4085cbf_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VITOR PAULO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VITOR PAULO|'
mv 85730c175a8aca3a0fb66558413c5ac73c77f7c8.png renomeado/category_2976_85730c175a8aca3a0fb66558413c5ac73c77f7c8.png
convert renomeado/category_2976_85730c175a8aca3a0fb66558413c5ac73c77f7c8.png -resize 16x16 renomeado/category_2976_85730c175a8aca3a0fb66558413c5ac73c77f7c8_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|VITOR PENIDO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|VITOR PENIDO|'
mv efdb4aa5edf9b984671007ed288eac38d0c44dd3.png renomeado/category_2977_efdb4aa5edf9b984671007ed288eac38d0c44dd3.png
convert renomeado/category_2977_efdb4aa5edf9b984671007ed288eac38d0c44dd3.png -resize 16x16 renomeado/category_2977_efdb4aa5edf9b984671007ed288eac38d0c44dd3_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WALDENOR PEREIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WALDENOR PEREIRA|'
mv ae83a5e917d3910672ee8f8639b9e7c0ed26d1ff.png renomeado/category_2978_ae83a5e917d3910672ee8f8639b9e7c0ed26d1ff.png
convert renomeado/category_2978_ae83a5e917d3910672ee8f8639b9e7c0ed26d1ff.png -resize 16x16 renomeado/category_2978_ae83a5e917d3910672ee8f8639b9e7c0ed26d1ff_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WALDIR MARANHÃO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WALDIR MARANHÃO|'
mv dbc0e3e5e6d3908aa5e501ebe12858469068b249.png renomeado/category_2979_dbc0e3e5e6d3908aa5e501ebe12858469068b249.png
convert renomeado/category_2979_dbc0e3e5e6d3908aa5e501ebe12858469068b249.png -resize 16x16 renomeado/category_2979_dbc0e3e5e6d3908aa5e501ebe12858469068b249_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WALNEY ROCHA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WALNEY ROCHA|'
mv 9e5454702486d41e2cc44bbfcccb04e334e4cd0e.png renomeado/category_2980_9e5454702486d41e2cc44bbfcccb04e334e4cd0e.png
convert renomeado/category_2980_9e5454702486d41e2cc44bbfcccb04e334e4cd0e.png -resize 16x16 renomeado/category_2980_9e5454702486d41e2cc44bbfcccb04e334e4cd0e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WALTER FELDMAN|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WALTER FELDMAN|'
mv 194df9c2bb77bb749d8abd81d8cd6781db1329c5.png renomeado/category_2981_194df9c2bb77bb749d8abd81d8cd6781db1329c5.png
convert renomeado/category_2981_194df9c2bb77bb749d8abd81d8cd6781db1329c5.png -resize 16x16 renomeado/category_2981_194df9c2bb77bb749d8abd81d8cd6781db1329c5_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WALTER IHOSHI|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WALTER IHOSHI|'
mv b3feda4692212139d553ab211c0ae0c6542d8e8c.png renomeado/category_2982_b3feda4692212139d553ab211c0ae0c6542d8e8c.png
convert renomeado/category_2982_b3feda4692212139d553ab211c0ae0c6542d8e8c.png -resize 16x16 renomeado/category_2982_b3feda4692212139d553ab211c0ae0c6542d8e8c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WALTER TOSTA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WALTER TOSTA|'
mv 2eb49dc48236b18f7045c704a5951911ff092eba.png renomeado/category_2983_2eb49dc48236b18f7045c704a5951911ff092eba.png
convert renomeado/category_2983_2eb49dc48236b18f7045c704a5951911ff092eba.png -resize 16x16 renomeado/category_2983_2eb49dc48236b18f7045c704a5951911ff092eba_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WANDENKOLK GONÇALVES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WANDENKOLK GONÇALVES|'
mv a3f15bc9ff31d99b5de8ab3ccdc283231201cb94.png renomeado/category_2984_a3f15bc9ff31d99b5de8ab3ccdc283231201cb94.png
convert renomeado/category_2984_a3f15bc9ff31d99b5de8ab3ccdc283231201cb94.png -resize 16x16 renomeado/category_2984_a3f15bc9ff31d99b5de8ab3ccdc283231201cb94_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WASHINGTON REIS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WASHINGTON REIS|'
mv 7458f22feacd8631f267a0d522837b328596de1e.png renomeado/category_2985_7458f22feacd8631f267a0d522837b328596de1e.png
convert renomeado/category_2985_7458f22feacd8631f267a0d522837b328596de1e.png -resize 16x16 renomeado/category_2985_7458f22feacd8631f267a0d522837b328596de1e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WELITON PRADO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WELITON PRADO|'
mv 590720014cb25f07f1ebfb0991a00695269c0418.png renomeado/category_2986_590720014cb25f07f1ebfb0991a00695269c0418.png
convert renomeado/category_2986_590720014cb25f07f1ebfb0991a00695269c0418.png -resize 16x16 renomeado/category_2986_590720014cb25f07f1ebfb0991a00695269c0418_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WELLINGTON FAGUNDES|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WELLINGTON FAGUNDES|'
mv 2af7fe78ce3107c6025742d013285e10fb370f03.png renomeado/category_2987_2af7fe78ce3107c6025742d013285e10fb370f03.png
convert renomeado/category_2987_2af7fe78ce3107c6025742d013285e10fb370f03.png -resize 16x16 renomeado/category_2987_2af7fe78ce3107c6025742d013285e10fb370f03_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WELLINGTON ROBERTO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WELLINGTON ROBERTO|'
mv 5ebb706b0f467e0327aa028c8495229090b7f97f.png renomeado/category_2988_5ebb706b0f467e0327aa028c8495229090b7f97f.png
convert renomeado/category_2988_5ebb706b0f467e0327aa028c8495229090b7f97f.png -resize 16x16 renomeado/category_2988_5ebb706b0f467e0327aa028c8495229090b7f97f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WILLIAM DIB|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WILLIAM DIB|'
mv 927b431224a5c85f729fe2ba3fd0ab26d1f9ed9f.png renomeado/category_2989_927b431224a5c85f729fe2ba3fd0ab26d1f9ed9f.png
convert renomeado/category_2989_927b431224a5c85f729fe2ba3fd0ab26d1f9ed9f.png -resize 16x16 renomeado/category_2989_927b431224a5c85f729fe2ba3fd0ab26d1f9ed9f_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WILSON FILHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WILSON FILHO|'
mv b38af33d926310dc9916e9f08aad2846d7e07d13.png renomeado/category_2990_b38af33d926310dc9916e9f08aad2846d7e07d13.png
convert renomeado/category_2990_b38af33d926310dc9916e9f08aad2846d7e07d13.png -resize 16x16 renomeado/category_2990_b38af33d926310dc9916e9f08aad2846d7e07d13_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WLADIMIR COSTA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WLADIMIR COSTA|'
mv 89b679e032c22f1cd9f197dd75dd6f805c59847a.png renomeado/category_2991_89b679e032c22f1cd9f197dd75dd6f805c59847a.png
convert renomeado/category_2991_89b679e032c22f1cd9f197dd75dd6f805c59847a.png -resize 16x16 renomeado/category_2991_89b679e032c22f1cd9f197dd75dd6f805c59847a_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|WOLNEY QUEIROZ|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|WOLNEY QUEIROZ|'
mv 75075b940db1f86e6744ee181203a1bb5bd5ca75.png renomeado/category_2992_75075b940db1f86e6744ee181203a1bb5bd5ca75.png
convert renomeado/category_2992_75075b940db1f86e6744ee181203a1bb5bd5ca75.png -resize 16x16 renomeado/category_2992_75075b940db1f86e6744ee181203a1bb5bd5ca75_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ZECA DIRCEU|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ZECA DIRCEU|'
mv 5fe20a1117907ebf0d2a19195a34c642d18adbbe.png renomeado/category_2993_5fe20a1117907ebf0d2a19195a34c642d18adbbe.png
convert renomeado/category_2993_5fe20a1117907ebf0d2a19195a34c642d18adbbe.png -resize 16x16 renomeado/category_2993_5fe20a1117907ebf0d2a19195a34c642d18adbbe_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ZENALDO COUTINHO|'

echo 'No XML fotos este é o nome do Deputado Federal:|ZEQUINHA MARINHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ZEQUINHA MARINHO|'
mv a6aeaacd1e1ea7dff63ce41ad0c4643f873cb5bf.png renomeado/category_2995_a6aeaacd1e1ea7dff63ce41ad0c4643f873cb5bf.png
convert renomeado/category_2995_a6aeaacd1e1ea7dff63ce41ad0c4643f873cb5bf.png -resize 16x16 renomeado/category_2995_a6aeaacd1e1ea7dff63ce41ad0c4643f873cb5bf_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ZEZÉU RIBEIRO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ZEZÉU RIBEIRO|'
mv e3d7980295ffc35e0f9b34b8e6ba3fafc2c55d55.png renomeado/category_2996_e3d7980295ffc35e0f9b34b8e6ba3fafc2c55d55.png
convert renomeado/category_2996_e3d7980295ffc35e0f9b34b8e6ba3fafc2c55d55.png -resize 16x16 renomeado/category_2996_e3d7980295ffc35e0f9b34b8e6ba3fafc2c55d55_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ZOINHO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ZOINHO|'
mv be66bb798dbce25c4e4ad57c1ef335dd1e9eeb34.png renomeado/category_2997_be66bb798dbce25c4e4ad57c1ef335dd1e9eeb34.png
convert renomeado/category_2997_be66bb798dbce25c4e4ad57c1ef335dd1e9eeb34.png -resize 16x16 renomeado/category_2997_be66bb798dbce25c4e4ad57c1ef335dd1e9eeb34_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ZÉ GERALDO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ZÉ GERALDO|'
mv d59d1ebddd5ff722ee891a3853d000ce9ae1ef26.png renomeado/category_2998_d59d1ebddd5ff722ee891a3853d000ce9ae1ef26.png
convert renomeado/category_2998_d59d1ebddd5ff722ee891a3853d000ce9ae1ef26.png -resize 16x16 renomeado/category_2998_d59d1ebddd5ff722ee891a3853d000ce9ae1ef26_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|null|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ZÉ SILVA|'

echo 'No XML fotos este é o nome do Deputado Federal:|ZÉ VIEIRA|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ZÉ VIEIRA|'
mv 59810c33d6a4bb205086b6ddc274f4816d0a0bfd.png renomeado/category_3000_59810c33d6a4bb205086b6ddc274f4816d0a0bfd.png
convert renomeado/category_3000_59810c33d6a4bb205086b6ddc274f4816d0a0bfd.png -resize 16x16 renomeado/category_3000_59810c33d6a4bb205086b6ddc274f4816d0a0bfd_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ÁTILA LINS|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ÁTILA LINS|'
mv ac7a92ade6bb560b9e11d54fd232ed078c647d7c.png renomeado/category_3001_ac7a92ade6bb560b9e11d54fd232ed078c647d7c.png
convert renomeado/category_3001_ac7a92ade6bb560b9e11d54fd232ed078c647d7c.png -resize 16x16 renomeado/category_3001_ac7a92ade6bb560b9e11d54fd232ed078c647d7c_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ÂNGELO AGNOLIN|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ÂNGELO AGNOLIN|'
mv 5902d6f593e7dc6e01e15015c9bdfede2e6cdf8e.png renomeado/category_3002_5902d6f593e7dc6e01e15015c9bdfede2e6cdf8e.png
convert renomeado/category_3002_5902d6f593e7dc6e01e15015c9bdfede2e6cdf8e.png -resize 16x16 renomeado/category_3002_5902d6f593e7dc6e01e15015c9bdfede2e6cdf8e_16x16.png
echo 'No XML fotos este é o nome do Deputado Federal:|ÍRIS DE ARAÚJO|'
echo 'No CSV de categorias ONEBrasil este é o nome do Deputado Federal:|ÍRIS DE ARAÚJO|'
mv 5cce30cecde793b13c5ef7c83a159c0e6920d7a9.png renomeado/category_3003_5cce30cecde793b13c5ef7c83a159c0e6920d7a9.png
convert renomeado/category_3003_5cce30cecde793b13c5ef7c83a159c0e6920d7a9.png -resize 16x16 renomeado/category_3003_5cce30cecde793b13c5ef7c83a159c0e6920d7a9_16x16.png
echo 'insira na 1a linha deste arquivo o comando #!/bin/bash'
